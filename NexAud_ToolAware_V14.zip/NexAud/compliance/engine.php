<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/../configurations/ingest.php';
require_once __DIR__.'/../normalization/schema.php';
require_once __DIR__.'/EvidenceLedger.php';

function dot_value($data,string $path){
    $cur=$data;
    foreach(explode('.',$path) as $p){
        if(!is_array($cur)||!array_key_exists($p,$cur)) return null;
        $cur=$cur[$p];
    }
    return is_array($cur)&&array_key_exists('value',$cur)?$cur['value']:$cur;
}

function compare_rule($actual,string $op,$expected): bool {
    $a=$actual; $e=$expected;
    switch($op){
        case 'equals':
            if(is_bool($a)) return $a === filter_var($e,FILTER_VALIDATE_BOOLEAN);
            if(is_bool($e)) return (bool)$a === $e;
            return strtolower((string)$a)===strtolower((string)$e);
        case 'not_equals': return strtolower((string)$a)!==strtolower((string)$e);
        case 'contains': return stripos((string)$a,(string)$e)!==false;
        case 'not_contains': return stripos((string)$a,(string)$e)===false;
        case 'greater_than': return is_numeric($a)&&is_numeric($e)&&$a>$e;
        case 'less_than': return is_numeric($a)&&is_numeric($e)&&$a<$e;
        case 'exists': return $actual!==null;
        case 'not_exists': return $actual===null;
        case 'enabled': return (bool)$a===true;
        case 'disabled': return (bool)$a===false;
    }
    return false;
}

function run_compliance_model(int $configurationId,array $model,array $frameworkIds=[]): array {
    $c=config_get($configurationId);
    if(!$c) throw new RuntimeException('Configuration not found.');
    $params=nscs_flatten($model); $flat=[];
    foreach($params as $x) $flat[$x['parameter']]=$x['value'];
    $w=['c.enabled=1']; $p=[];
    if($frameworkIds){
        $w[]='c.framework_id IN ('.implode(',',array_fill(0,count($frameworkIds),'?')).')';
        $p=$frameworkIds;
    }
    $controls=db_all('SELECT c.*,f.name framework_name FROM controls c JOIN frameworks f ON f.framework_id=c.framework_id WHERE '.implode(' AND ',$w).' ORDER BY f.name,c.control_code',$p);
    $results=[];
    foreach($controls as $ctrl){
        if($ctrl['vendor']!=='ANY'&&strcasecmp($ctrl['vendor']??'', $c['detected_vendor']??'')!==0) continue;
        $actual=$flat[$ctrl['parameter']]??null;
        $ok=compare_rule($actual,$ctrl['operator'],$ctrl['expected_value']);
        $status=$ok?'PASS':'FAIL';
        $results[]=[
            'control'=>$ctrl,
            'actual'=>$actual,
            'status'=>$status,
            'evidence'=>($actual===null?'Parameter not found in normalized model.':json_encode($actual,JSON_UNESCAPED_SLASHES)),
        ];
    }
    return $results;
}

function run_compliance(int $configurationId,array $frameworkIds=[]): array {
    $n=config_get_normalized($configurationId);
    $model=json_decode($n['normalized_json']??'null',true);
    if(!is_array($model)) return [];
    return run_compliance_model($configurationId,$model,$frameworkIds);
}

function expected_simulation_value(array $control){
    $op=(string)($control['operator']??'equals');
    $expected=$control['expected_value']??'';
    if($op==='disabled') return false;
    if($op==='enabled') return true;
    $s=trim((string)$expected);
    if(strtolower($s)==='true') return true;
    if(strtolower($s)==='false') return false;
    if(is_numeric($s)) return (float)$s;
    return $expected;
}

function set_normalized_value(array &$model,string $path,$value,string $vendor='SIMULATION'): void {
    $parts=explode('.',$path); $cur=&$model;
    $last=array_pop($parts);
    foreach($parts as $part){
        if(!isset($cur[$part])||!is_array($cur[$part])) $cur[$part]=[];
        $cur=&$cur[$part];
    }
    $cur[$last]=[
        'value'=>$value,
        'source'=>['line'=>0,'raw'=>'[NexAud What-If simulation]'],
        'vendor'=>$vendor,
    ];
}

function compliance_stats(array $results): array {
    $total=count($results); $pass=0; $fail=0; $manual=0;
    foreach($results as $r){
        if($r['status']==='PASS') $pass++;
        elseif($r['status']==='MANUAL_REVIEW') $manual++;
        else $fail++;
    }
    return [
        'total'=>$total,
        'pass'=>$pass,
        'fail'=>$fail,
        'manual'=>$manual,
        'compliance_pct'=>$total>0?round(($pass/$total)*100,2):0,
    ];
}

function create_audit_run(int $configurationId,string $mode,string $by,?int $remediationId=null): int {
    $pdo=getDB();
    $s=$pdo->prepare('INSERT INTO audit_runs(configuration_id,mode,remediation_request_id,status,started_at,triggered_by) VALUES(?,?,?,?,NOW(6),?)');
    $s->execute([$configurationId,$mode,$remediationId,'RUNNING',$by]);
    return (int)$pdo->lastInsertId();
}

function complete_audit_run(int $auditRunId,array $results): void {
    $s=compliance_stats($results);
    getDB()->prepare('UPDATE audit_runs SET status=?,completed_at=NOW(6),total_controls=?,pass_count=?,fail_count=?,manual_count=?,compliance_pct=? WHERE audit_run_id=?')
        ->execute(['COMPLETED',$s['total'],$s['pass'],$s['fail'],$s['manual'],$s['compliance_pct'],$auditRunId]);
}

function fail_audit_run(int $auditRunId,string $message): void {
    getDB()->prepare('UPDATE audit_runs SET status=?,completed_at=NOW(6),error_message=? WHERE audit_run_id=?')
        ->execute(['FAILED',$message,$auditRunId]);
}

function persist_findings_for_run(int $configurationId,array $results,int $auditRunId): array {
    $c=config_get($configurationId); $pdo=getDB(); $ids=[];
    foreach($results as $r){
        $ctrl=$r['control']; $actual=$r['actual'];
        $s=$pdo->prepare('INSERT INTO findings(audit_run_id,device_id,configuration_id,control_id,status,severity,actual_value,expected_value,evidence,raw_evidence,source_line,remediation,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,NOW())');
        $actualText=is_scalar($actual)||$actual===null?(string)$actual:json_encode($actual,JSON_UNESCAPED_SLASHES);
        $s->execute([$auditRunId,(string)$c['device_id'],(string)$configurationId,$ctrl['control_id'],$r['status'],$ctrl['severity'],$actualText,$ctrl['expected_value'],$r['evidence'],$r['evidence'],null,$ctrl['remediation']]);
        $fid=(int)$pdo->lastInsertId(); $ids[]=$fid;
        try {
            $ledger=new EvidenceLedger($pdo); $ledger->append('FINDING_RECORDED',[
                'finding_id'=>$fid,'control_code'=>$ctrl['control_code'],'status'=>$r['status'],'severity'=>$ctrl['severity'],
                'actual'=>$actualText,'expected'=>$ctrl['expected_value'],'audit_run_id'=>$auditRunId,
            ],(string)$c['sha256_hash'],(string)$c['device_id'],(string)$configurationId,$fid,current_user()['username']??'SYSTEM');
        } catch(Throwable $e){ error_log('[NexAud ledger] '.$e->getMessage()); }
    }
    return $ids;
}

function persist_findings(int $configurationId,array $results): array {
    $by=current_user()['username']??'SYSTEM';
    $run=create_audit_run($configurationId,'BASELINE',$by);
    $ledger=new EvidenceLedger(getDB()); $c=config_get($configurationId);
    try {
        $ledger->ensureGenesis($by);
        $ledger->append('AUDIT_STARTED',['configuration_id'=>$configurationId,'audit_run_id'=>$run],$c['sha256_hash'],(string)$c['device_id'],(string)$configurationId,null,$by);
        $ids=persist_findings_for_run($configurationId,$results,$run);
        complete_audit_run($run,$results);
        $stats=compliance_stats($results);
        $ledger->append('AUDIT_COMPLETED',['configuration_id'=>$configurationId,'audit_run_id'=>$run,'stats'=>$stats],$c['sha256_hash'],(string)$c['device_id'],(string)$configurationId,null,$by);
        audit_log(current_user_id(),'AUDIT_COMPLETED','audits',$configurationId,['findings'=>count($ids),'audit_run_id'=>$run]);
        return $ids;
    } catch(Throwable $e){
        fail_audit_run($run,$e->getMessage());
        throw $e;
    }
}
