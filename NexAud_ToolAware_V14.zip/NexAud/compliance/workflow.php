<?php
declare(strict_types=1);
require_once __DIR__.'/engine.php';
require_once __DIR__.'/EvidenceLedger.php';

function latest_remediation_for_finding(int $findingId): ?array {
    return db_one('SELECT * FROM remediation_requests WHERE finding_id=? ORDER BY remediation_request_id DESC LIMIT 1',[$findingId]);
}

function create_or_get_remediation(int $findingId): array {
    $r=latest_remediation_for_finding($findingId);
    if($r) return $r;
    $f=db_one('SELECT f.*,c.control_code,c.parameter,c.operator,c.expected_value control_expected,c.remediation control_remediation FROM findings f JOIN controls c ON c.control_id=f.control_id WHERE f.finding_id=?',[$findingId]);
    if(!$f) throw new RuntimeException('Finding not found.');
    $value=expected_simulation_value($f);
    $stmt=getDB()->prepare('INSERT INTO remediation_requests(finding_id,device_id,configuration_id,proposed_value,remediation_text,status,created_by) VALUES(?,?,?,?,?,?,?)');
    $stmt->execute([(int)$findingId,(string)$f['device_id'],(string)$f['configuration_id'],is_scalar($value)?(string)$value:json_encode($value),$f['control_remediation']??$f['remediation']??'','DRAFT',current_user()['username']??'SYSTEM']);
    $id=(int)getDB()->lastInsertId();
    $r=db_one('SELECT * FROM remediation_requests WHERE remediation_request_id=?',[$id]);
    $c=config_get((int)$f['configuration_id']);
    try{(new EvidenceLedger(getDB()))->ensureGenesis(current_user()['username']??'SYSTEM');(new EvidenceLedger(getDB()))->append('REMEDIATION_CREATED',['remediation_request_id'=>$id,'finding_id'=>$findingId,'control_code'=>$f['control_code']],$c['sha256_hash']??null,(string)$f['device_id'],(string)$f['configuration_id'],$findingId,current_user()['username']??'SYSTEM');}catch(Throwable $e){error_log('[NexAud ledger] '.$e->getMessage());}
    return $r;
}

function what_if_simulate(int $findingId): array {
    $finding=db_one('SELECT f.*,c.control_code,c.parameter,c.operator,c.expected_value control_expected,c.remediation control_remediation,c.title FROM findings f JOIN controls c ON c.control_id=f.control_id WHERE f.finding_id=?',[$findingId]);
    if(!$finding) throw new RuntimeException('Finding not found.');
    $configId=(int)$finding['configuration_id'];
    $n=config_get_normalized($configId); $model=json_decode($n['normalized_json']??'null',true);
    if(!is_array($model)) throw new RuntimeException('Normalized configuration is unavailable.');
    $expected=expected_simulation_value($finding);
    set_normalized_value($model,(string)$finding['parameter'],$expected,(string)($finding['vendor']??'SIMULATION'));
    $simResults=run_compliance_model($configId,$model);
    $stats=compliance_stats($simResults);
    $baseRun=db_one('SELECT * FROM audit_runs WHERE configuration_id=? AND mode=\'BASELINE\' AND status=\'COMPLETED\' ORDER BY audit_run_id DESC LIMIT 1',[$configId]);
    if($baseRun){$current=(float)$baseRun['compliance_pct'];}else{$current=(float)$stats['compliance_pct'];}
    // For a demo, the simulation score is the computed full-model score, not a hard-coded increase.
    $r=create_or_get_remediation($findingId);
    $pdo=getDB();
    $pdo->prepare('UPDATE remediation_requests SET status=\'SIMULATED\',current_compliance=?,projected_compliance=?,simulated_result_json=?,simulated_normalized_json=?,simulation_notes=? WHERE remediation_request_id=?')
        ->execute([$current,$stats['compliance_pct'],json_encode($simResults,JSON_UNESCAPED_SLASHES),json_encode($model,JSON_UNESCAPED_SLASHES),'What-If evaluated in memory. No live device or baseline configuration was modified.',(int)$r['remediation_request_id']]);
    $c=config_get($configId); $by=current_user()['username']??'SYSTEM';
    try{(new EvidenceLedger($pdo))->ensureGenesis($by);(new EvidenceLedger($pdo))->append('WHATIF_SIMULATED',['remediation_request_id'=>$r['remediation_request_id'],'finding_id'=>$findingId,'current_compliance'=>$current,'projected_compliance'=>$stats['compliance_pct'],'device_modified'=>false],$c['sha256_hash']??null,(string)$finding['device_id'],(string)$configId,$findingId,$by);}catch(Throwable $e){error_log('[NexAud ledger] '.$e->getMessage());}
    return db_one('SELECT * FROM remediation_requests WHERE remediation_request_id=?',[(int)$r['remediation_request_id']]);
}

function approve_and_reaudit(int $findingId): array {
    $r=latest_remediation_for_finding($findingId);
    if(!$r || !in_array($r['status'],['SIMULATED','PENDING_APPROVAL'],true)) throw new RuntimeException('Run What-If Simulation before approval.');
    $f=db_one('SELECT f.*,c.control_code FROM findings f JOIN controls c ON c.control_id=f.control_id WHERE f.finding_id=?',[$findingId]);
    if(!$f) throw new RuntimeException('Finding not found.');
    $pdo=getDB(); $by=current_user()['username']??'SYSTEM';
    $pdo->beginTransaction();
    try{
        $pdo->prepare('UPDATE remediation_requests SET status=\'APPROVED\',approved_by=?,approved_at=NOW(6),applied_at=NOW(6) WHERE remediation_request_id=?')->execute([$by,$r['remediation_request_id']]);
        $c=config_get((int)$f['configuration_id']);
        try{(new EvidenceLedger($pdo))->append('REMEDIATION_APPROVED',['remediation_request_id'=>$r['remediation_request_id'],'finding_id'=>$findingId,'approved_by'=>$by,'execution_mode'=>'SAFE_SIMULATION'],(string)$c['sha256_hash'],(string)$f['device_id'],(string)$f['configuration_id'],$findingId,$by);}catch(Throwable $e){error_log('[NexAud ledger] '.$e->getMessage());}
        $sim=json_decode($r['simulated_result_json']??'[]',true); $model=json_decode($r['simulated_normalized_json']??'null',true);
        if(!is_array($sim)||!is_array($model)) throw new RuntimeException('Simulation snapshot is missing.');
        $run=create_audit_run((int)$f['configuration_id'],'RE_AUDIT',$by,(int)$r['remediation_request_id']);
        $ids=persist_findings_for_run((int)$f['configuration_id'],$sim,$run);
        complete_audit_run($run,$sim);
        $stats=compliance_stats($sim);
        $pdo->prepare('UPDATE remediation_requests SET status=\'RE_AUDITED\',reaudited_at=NOW(6),re_audit_run_id=? WHERE remediation_request_id=?')->execute([$run,$r['remediation_request_id']]);
        try{(new EvidenceLedger($pdo))->append('RE_AUDIT_COMPLETED',['remediation_request_id'=>$r['remediation_request_id'],'finding_id'=>$findingId,'audit_run_id'=>$run,'stats'=>$stats,'device_modified'=>false],(string)$c['sha256_hash'],(string)$f['device_id'],(string)$f['configuration_id'],$findingId,$by);}catch(Throwable $e){error_log('[NexAud ledger] '.$e->getMessage());}
        $pdo->commit();
        return ['remediation_request_id'=>(int)$r['remediation_request_id'],'audit_run_id'=>$run,'finding_ids'=>$ids,'stats'=>$stats];
    }catch(Throwable $e){$pdo->rollBack();throw $e;}
}

function reject_remediation(int $findingId,string $reason='Rejected by reviewer'): void {
    $r=latest_remediation_for_finding($findingId); if(!$r) throw new RuntimeException('No remediation request exists.');
    $by=current_user()['username']??'SYSTEM';
    getDB()->prepare('UPDATE remediation_requests SET status=\'REJECTED\',rejected_by=?,rejected_at=NOW(6),simulation_notes=? WHERE remediation_request_id=?')->execute([$by,$reason,(int)$r['remediation_request_id']]);
    $f=db_one('SELECT * FROM findings WHERE finding_id=?',[$findingId]); $c=config_get((int)$f['configuration_id']);
    try{(new EvidenceLedger(getDB()))->append('REMEDIATION_REJECTED',['remediation_request_id'=>$r['remediation_request_id'],'finding_id'=>$findingId,'reason'=>$reason],(string)$c['sha256_hash'],(string)$f['device_id'],(string)$f['configuration_id'],$findingId,$by);}catch(Throwable $e){error_log('[NexAud ledger] '.$e->getMessage());}
}
