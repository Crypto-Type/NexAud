<?php
declare(strict_types=1);
header('Location: /NexAud/login.php', true, 302);
exit;
