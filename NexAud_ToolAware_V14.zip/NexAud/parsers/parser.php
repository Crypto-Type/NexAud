<?php
/**
 * NexAud Module 2 - parsers/parser.php
 *
 * Vendor detection engine + parser orchestrator. This is the single public
 * entry point other modules (compliance engine, AI module, API layer)
 * should call — they should not need to know which vendor-specific parser
 * file exists.
 *
 * Public API (contract):
 *   detectVendor(string $rawConfig): array
 *   parseConfiguration(string $rawConfig, ?string $vendorHint = null): array
 *   calculateConfigHash(string $rawConfig): string
 */

require_once __DIR__ . '/cisco.php';
require_once __DIR__ . '/fortinet.php';
require_once __DIR__ . '/paloalto.php';
require_once __DIR__ . '/unknown.php';

/** Registry mapping a vendor name to its parser function. Add new vendors here. */
const VENDOR_PARSER_MAP = [
    'Cisco'     => 'nexaud_parse_cisco',
    'Fortinet'  => 'nexaud_parse_fortinet',
    'Palo Alto' => 'nexaud_parse_paloalto',
];

/**
 * calculateConfigHash()
 * SHA-256 of the EXACT raw bytes as uploaded. Must be called before any
 * normalization/whitespace-trimming/encoding conversion is applied.
 */
function calculateConfigHash(string $rawConfig): string
{
    return hash('sha256', $rawConfig);
}

/**
 * detectVendor()
 *
 * Runs a set of weighted signature checks against the raw configuration
 * text and returns the highest-confidence vendor guess, plus the evidence
 * that supports it, plus a best-effort device_type and OS guess.
 *
 * Confidence is a simple normalized score in [0,1] based on how many
 * independent, vendor-specific syntax markers were found. This is a
 * heuristic classifier, not a guarantee — the Unknown-vendor path exists
 * specifically for when confidence is too low to trust.
 */
function detectVendor(string $rawConfig): array
{
    $signatures = [
        'Cisco' => [
            '/^\s*!\s*$/m'                                   => 'IOS "!" comment/section delimiter',
            '/^version\s+\d+\.\d+/mi'                         => 'IOS "version" header directive',
            '/^hostname\s+\S+/mi'                             => 'IOS hostname syntax',
            '/^interface\s+(GigabitEthernet|FastEthernet|Vlan|Loopback|Serial|Ethernet)\S*/mi'
                                                                => 'IOS interface naming convention',
            '/^\s*transport input\s+/mi'                       => 'IOS vty "transport input" syntax',
            '/^line (con|vty|aux)\s+/mi'                       => 'IOS "line con/vty" syntax',
            '/^\s*ip address\s+\d+\.\d+\.\d+\.\d+\s+\d+\.\d+\.\d+\.\d+/mi' => 'IOS "ip address" syntax',
            '/^access-list\s+\d+\s+(permit|deny)/mi'           => 'IOS numbered ACL syntax',
            '/^enable (secret|password)\s+/mi'                 => 'IOS "enable secret/password" syntax',
            '/^aaa new-model/mi'                               => 'IOS "aaa new-model" directive',
        ],
        'Fortinet' => [
            '/^config\s+system\s+global/mi'                    => 'FortiOS "config system global" block',
            '/^config\s+\S+\s+\S+/mi'                           => 'FortiOS "config <object>" block syntax',
            '/^\s*edit\s+"?[\w\-.\/]+"?/mi'                     => 'FortiOS "edit" sub-object syntax',
            '/^\s*next\s*$/mi'                                  => 'FortiOS "next" block terminator',
            '/^\s*end\s*$/mi'                                   => 'FortiOS "end" block terminator',
            '/^\s*set\s+\S+\s+/mi'                              => 'FortiOS "set <key> <value>" directive syntax',
            '/set allowaccess\s+/mi'                            => 'FortiOS "allowaccess" interface directive',
            '/config firewall policy/mi'                        => 'FortiOS firewall policy block',
        ],
        'Palo Alto' => [
            '/^set\s+deviceconfig\s+/mi'                        => 'PAN-OS "set deviceconfig" CLI syntax',
            '/^set\s+network\s+interface\s+/mi'                 => 'PAN-OS "set network interface" CLI syntax',
            '/^set\s+rulebase\s+security\s+rules\s+/mi'         => 'PAN-OS "set rulebase security rules" syntax',
            '/^set\s+mgt-config\s+users\s+/mi'                  => 'PAN-OS "set mgt-config users" syntax',
            '/^set\s+zone\s+/mi'                                => 'PAN-OS zone configuration syntax',
            '/^set\s+network\s+virtual-router\s+/mi'            => 'PAN-OS virtual-router routing syntax',
            '/panorama|PAN-OS|Palo Alto Networks/i'             => 'Explicit Palo Alto Networks / PAN-OS mention',
        ],
    ];

    $scores = [];
    $evidenceByVendor = [];

    foreach ($signatures as $vendor => $patterns) {
        $hits = 0;
        $evidence = [];
        foreach ($patterns as $pattern => $label) {
            if (preg_match($pattern, $rawConfig)) {
                $hits++;
                $evidence[] = $label;
            }
        }
        $scores[$vendor] = $hits / max(1, count($patterns));
        $evidenceByVendor[$vendor] = $evidence;
    }

    arsort($scores);
    $topVendor = array_key_first($scores);
    $topScore  = $scores[$topVendor];

    // Confidence floor: below this, we do not trust the classifier and
    // fall back to Unknown so the Unknown-vendor pipeline (candidate
    // mappings, unrecognized_commands) takes over instead of silently
    // mis-normalizing.
    $CONFIDENCE_FLOOR = 0.20;

    if ($topScore < $CONFIDENCE_FLOOR) {
        return [
            'vendor'            => 'Unknown',
            'confidence'        => round($topScore, 3),
            'device_type'       => 'Unknown',
            'detected_os'       => null,
            'detection_evidence'=> $evidenceByVendor[$topVendor] ?? [],
            'all_scores'        => $scores,
        ];
    }

    $deviceType = nexaud_guess_device_type($topVendor, $rawConfig);
    $detectedOs = nexaud_guess_os_version($topVendor, $rawConfig);

    return [
        'vendor'             => $topVendor,
        'confidence'         => round($topScore, 3),
        'device_type'        => $deviceType,
        'detected_os'        => $detectedOs,
        'detection_evidence' => $evidenceByVendor[$topVendor],
        'all_scores'         => $scores,
    ];
}

function nexaud_guess_device_type(string $vendor, string $rawConfig): string
{
    if ($vendor === 'Fortinet') {
        if (preg_match('/config vpn (ipsec|ssl)/mi', $rawConfig)) {
            return 'Firewall';
        }
        return 'Firewall'; // FortiGate is a firewall/UTM in virtually all cases
    }
    if ($vendor === 'Palo Alto') {
        return 'Firewall';
    }
    if ($vendor === 'Cisco') {
        if (preg_match('/^router (ospf|bgp|eigrp)/mi', $rawConfig)) {
            return 'Router';
        }
        if (preg_match('/^(vlan \d+|spanning-tree)/mi', $rawConfig) &&
            !preg_match('/^router (ospf|bgp|eigrp)/mi', $rawConfig)) {
            return 'Switch';
        }
        if (preg_match('/^access-list.*\b(deny|permit)\b.*\bany\b/mi', $rawConfig) &&
            preg_match('/^interface (Serial|GigabitEthernet0\/0)/mi', $rawConfig)) {
            return 'Router';
        }
        return 'Router';
    }
    return 'Unknown';
}

function nexaud_guess_os_version(string $vendor, string $rawConfig): ?string
{
    if ($vendor === 'Cisco' && preg_match('/^version\s+([\d.]+)/mi', $rawConfig, $m)) {
        return 'IOS ' . $m[1];
    }
    if ($vendor === 'Fortinet' && preg_match('/#config-version=\S+?-(\S+?):/i', $rawConfig, $m)) {
        return 'FortiOS ' . $m[1];
    }
    if ($vendor === 'Palo Alto' && preg_match('/panos[-_]?version[:\s]+([\d.]+)/i', $rawConfig, $m)) {
        return 'PAN-OS ' . $m[1];
    }
    return null;
}

/**
 * parseConfiguration()
 *
 * Converts raw configuration text into the vendor's Intermediate
 * Representation (IR). If $vendorHint is not supplied, detectVendor() is
 * called first. Falls through to the Unknown-vendor parser for anything
 * unsupported or low-confidence.
 *
 * This function makes NO compliance decisions. It only structures data.
 */
function parseConfiguration(string $rawConfig, ?string $vendorHint = null): array
{
    $detection = $vendorHint ? ['vendor' => $vendorHint] : detectVendor($rawConfig);
    $vendor = $detection['vendor'];

    if ($vendor !== 'Unknown' && isset(VENDOR_PARSER_MAP[$vendor])) {
        $fn = VENDOR_PARSER_MAP[$vendor];
        $ir = $fn($rawConfig);
    } else {
        $ir = nexaud_parse_unknown($rawConfig);
        $vendor = 'Unknown';
    }

    $ir['vendor'] = $vendor;
    $ir['detection'] = $vendorHint ? null : $detection;
    return $ir;
}
