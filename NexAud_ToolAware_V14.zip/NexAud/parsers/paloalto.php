<?php
/**
 * NexAud Module 2 - parsers/paloalto.php
 *
 * PAN-OS "set format" configuration exports are already fully-qualified
 * per line (each line stands alone, e.g.
 * "set network interface ethernet ethernet1/1 layer3 ip 10.0.0.1/24"),
 * so — unlike Fortinet — no context-stack tracking is required. Each line
 * is emitted both as a raw_line (for global regex rules) AND as a
 * lightweight tokenized directive (for rules that want to match on the
 * path structure rather than a single monolithic regex).
 *
 * IR shape:
 * [
 *   'raw_lines'  => [ ['line'=>n,'raw'=>...], ... ],
 *   'contexts'   => [],
 *   'directives' => [ ['line'=>n,'raw'=>...,'tokens'=>[...]], ... ],  // only "set" lines
 * ]
 */

function nexaud_parse_paloalto(string $rawConfig): array
{
    $lines = preg_split('/\r\n|\r|\n/', $rawConfig);
    $rawLines = [];
    $directives = [];

    foreach ($lines as $idx => $text) {
        $lineNum = $idx + 1;
        $rawLines[] = ['line' => $lineNum, 'raw' => $text];

        $trimmed = trim($text);
        if ($trimmed === '' || str_starts_with($trimmed, '#')) {
            continue;
        }

        if (preg_match('/^set\s+(.+)$/i', $trimmed, $m)) {
            // Naive whitespace tokenization is sufficient for the
            // regex-based mapping rules used in normalization/mappings.php;
            // values containing spaces (e.g. descriptions) are handled by
            // the specific rule's own capture group instead of generic
            // tokenization.
            $tokens = preg_split('/\s+/', trim($m[1]));
            $directives[] = [
                'line'   => $lineNum,
                'raw'    => $trimmed,
                'tokens' => $tokens,
            ];
        }
    }

    return [
        'raw_lines'  => $rawLines,
        'contexts'   => [],
        'directives' => $directives,
    ];
}
