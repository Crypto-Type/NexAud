<?php
/**
 * NexAud Module 2 - parsers/fortinet.php
 *
 * FortiOS configs are block-structured:
 *   config <object> [<object2>]
 *       edit "<name>"
 *           set <key> <value...>
 *       next
 *   end
 *
 * The same "set" key means different things depending on which config/edit
 * path it's nested under, so the parser tracks a path stack and emits each
 * "set" line as a "directive" carrying its full context path. This is what
 * lets the normalization engine tell apart, e.g., "set allowaccess" under
 * "system interface > edit port1" (which controls which management
 * protocols are allowed on that interface) from an unrelated "set" under a
 * different object.
 *
 * IR shape:
 * [
 *   'raw_lines'  => [ ['line'=>n,'raw'=>...], ... ],
 *   'contexts'   => [],  // unused for Fortinet; kept for engine symmetry
 *   'directives' => [
 *       ['line'=>n,'raw'=>'set allowaccess ping https ssh','path'=>['system','interface'],
 *        'edit'=>'port1','key'=>'allowaccess','value'=>'ping https ssh'],
 *       ...
 *   ],
 * ]
 */

function nexaud_parse_fortinet(string $rawConfig): array
{
    $lines = preg_split('/\r\n|\r|\n/', $rawConfig);
    $rawLines = [];
    $directives = [];

    // Stack of ['kind' => 'config'|'edit', 'name' => string]
    $stack = [];

    foreach ($lines as $idx => $text) {
        $lineNum = $idx + 1;
        $rawLines[] = ['line' => $lineNum, 'raw' => $text];

        $trimmed = trim($text);
        if ($trimmed === '' || str_starts_with($trimmed, '#')) {
            continue;
        }

        if (preg_match('/^config\s+(.+)$/i', $trimmed, $m)) {
            // "config system interface" -> path segments ["system","interface"]
            // Stored as ONE stack frame (so a single "end" pops all of it),
            // but "segments" keeps the words separate for path matching.
            $segments = preg_split('/\s+/', trim($m[1]));
            $stack[] = ['kind' => 'config', 'segments' => $segments];
            continue;
        }

        if (preg_match('/^edit\s+"?([^"]+)"?\s*$/i', $trimmed, $m)) {
            $stack[] = ['kind' => 'edit', 'name' => trim($m[1])];
            continue;
        }

        if (preg_match('/^next\s*$/i', $trimmed)) {
            // pop back to (but not past) the nearest enclosing "config"
            while (!empty($stack) && end($stack)['kind'] === 'edit') {
                array_pop($stack);
            }
            continue;
        }

        if (preg_match('/^end\s*$/i', $trimmed)) {
            if (!empty($stack)) {
                array_pop($stack);
            }
            continue;
        }

        if (preg_match('/^set\s+(\S+)\s*(.*)$/i', $trimmed, $m)) {
            $configPath = [];
            $editName = null;
            foreach ($stack as $frame) {
                if ($frame['kind'] === 'config') {
                    $configPath = array_merge($configPath, $frame['segments']);
                } else {
                    $editName = $frame['name']; // last edit name wins (innermost)
                }
            }
            $directives[] = [
                'line'  => $lineNum,
                'raw'   => $trimmed,
                'path'  => $configPath,        // e.g. ['system','interface']
                'edit'  => $editName,           // e.g. 'port1' or null
                'key'   => strtolower($m[1]),
                'value' => trim($m[2], " \t\"'"),
            ];
        }
        // "unset", "append" or vendor-specific extensions are intentionally
        // not modeled in v1; they fall through and are simply not normalized.
    }

    return [
        'raw_lines'  => $rawLines,
        'contexts'   => [],
        'directives' => $directives,
    ];
}
