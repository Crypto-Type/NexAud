<?php
/**
 * NexAud Module 2 - parsers/unknown.php
 *
 * Runs when detectVendor() cannot confidently classify a configuration, or
 * when a vendor hint of "Unknown" is passed explicitly. This parser MUST
 * NOT simply fail — it produces a best-effort structure that a human
 * reviewer or the (separately-owned) AI module can act on:
 *
 *   - unrecognized_commands   : every non-blank line, verbatim, with number
 *   - possible_security_categories : keyword-heuristic guesses per line
 *   - raw evidence            : line + raw text for every guess
 *   - candidate_mappings      : suggested NSCS dotted-paths per line, with
 *                               a confidence score, for a human/AI to confirm
 *
 * It performs NO normalization into normalization/schema.php itself —
 * normalizeConfiguration() special-cases 'Unknown' and passes this
 * structure straight through rather than trying to build an NSCS document
 * out of guesses.
 */

/** Keyword => [category, candidate NSCS path, confidence] heuristics. */
const NEXAUD_UNKNOWN_KEYWORD_HINTS = [
    '/telnet/i'                 => ['remote_access', 'remote_access.telnet.enabled', 0.55],
    '/\bssh\b/i'                 => ['remote_access', 'remote_access.ssh.enabled', 0.55],
    '/password/i'                 => ['password_policy', 'password_policy', 0.40],
    '/snmp/i'                     => ['snmp', 'snmp', 0.55],
    '/ntp/i'                      => ['time_sync', 'time_sync.ntp', 0.55],
    '/log(ging)?\b/i'             => ['logging', 'logging', 0.45],
    '/aaa|radius|tacacs/i'        => ['authentication', 'authentication.aaa', 0.50],
    '/access[-_ ]?list|acl\b/i'   => ['acl', 'acl', 0.45],
    '/firewall|policy|rule/i'     => ['firewall', 'firewall', 0.35],
    '/vpn|ipsec|ike/i'            => ['vpn', 'vpn', 0.50],
    '/interface/i'                => ['interfaces', 'interfaces', 0.40],
    '/route|routing|ospf|bgp|eigrp/i' => ['routing', 'routing', 0.45],
    '/admin|username|user\b/i'    => ['accounts', 'accounts', 0.35],
    '/crypto|certificate|tls|ssl/i' => ['crypto', 'crypto', 0.40],
];

function nexaud_parse_unknown(string $rawConfig): array
{
    $lines = preg_split('/\r\n|\r|\n/', $rawConfig);

    $unrecognizedCommands = [];
    $candidateMappings = [];
    $categoryHits = [];

    foreach ($lines as $idx => $text) {
        $lineNum = $idx + 1;
        $trimmed = trim($text);
        if ($trimmed === '') {
            continue;
        }

        $unrecognizedCommands[] = ['line' => $lineNum, 'raw' => $text];

        foreach (NEXAUD_UNKNOWN_KEYWORD_HINTS as $pattern => [$category, $candidatePath, $confidence]) {
            if (preg_match($pattern, $trimmed)) {
                $candidateMappings[] = [
                    'line'             => $lineNum,
                    'raw'              => $text,
                    'category'         => $category,
                    'candidate_path'   => $candidatePath,
                    'confidence'       => $confidence,
                ];
                $categoryHits[$category] = ($categoryHits[$category] ?? 0) + 1;
            }
        }
    }

    arsort($categoryHits);

    return [
        'raw_lines'  => array_map(fn($t, $i) => ['line' => $i + 1, 'raw' => $t], $lines, array_keys($lines)),
        'contexts'   => [],
        'directives' => [],
        'unknown_report' => [
            'unrecognized_commands'       => $unrecognizedCommands,
            'possible_security_categories' => array_keys($categoryHits),
            'category_hit_counts'          => $categoryHits,
            'candidate_mappings'           => $candidateMappings,
            'note' => 'Vendor could not be confidently detected. This structure is heuristic only; ' .
                      'no NexAud Security Configuration Schema fields were populated automatically. ' .
                      'Route to manual review or the AI interpretation module.',
        ],
    ];
}
