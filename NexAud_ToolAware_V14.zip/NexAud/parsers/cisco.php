<?php
/**
 * NexAud Module 2 - parsers/cisco.php
 *
 * Converts raw Cisco IOS-style configuration text into a common
 * Intermediate Representation (IR). Makes NO compliance decisions.
 *
 * IR shape:
 * [
 *   'raw_lines' => [ ['line' => int, 'raw' => string], ... ],   // every line, 1-indexed
 *   'contexts'  => [
 *        ['type' => 'line_vty', 'name' => '0 4', 'start_line' => n, 'end_line' => n,
 *         'lines' => [['line'=>n,'raw'=>...], ...]],
 *        ['type' => 'line_con', ...],
 *        ['type' => 'interface', 'name' => 'GigabitEthernet0/1', ...],
 *   ],
 * ]
 */

function nexaud_parse_cisco(string $rawConfig): array
{
    $lines = preg_split('/\r\n|\r|\n/', $rawConfig);
    $rawLines = [];
    $contexts = [];

    $currentContext = null; // ['type','name','start_line','lines']

    $openBlockPattern = '/^line (con|vty|aux)\s*(.*)$/i';
    $interfacePattern = '/^interface\s+(\S+)/i';

    foreach ($lines as $idx => $text) {
        $lineNum = $idx + 1;
        $rawLines[] = ['line' => $lineNum, 'raw' => $text];

        $trimmed = rtrim($text);

        // A bare "!" or a new top-level (non-indented) directive closes any
        // open sub-block in IOS-style configs.
        $isTopLevel = (bool)preg_match('/^\S/', $text) && trim($text) !== '';
        $isBang = trim($text) === '!';

        if ($currentContext !== null && ($isBang || ($isTopLevel && !preg_match('/^(line |interface )/i', $text)))) {
            $currentContext['end_line'] = $lineNum - 1;
            $contexts[] = $currentContext;
            $currentContext = null;
        }

        if (preg_match($openBlockPattern, $text, $m)) {
            if ($currentContext !== null) {
                $currentContext['end_line'] = $lineNum - 1;
                $contexts[] = $currentContext;
            }
            $type = strtolower($m[1]) === 'vty' ? 'line_vty' : (strtolower($m[1]) === 'con' ? 'line_con' : 'line_aux');
            $currentContext = [
                'type' => $type,
                'name' => trim($m[2]),
                'start_line' => $lineNum,
                'end_line' => $lineNum,
                'lines' => [],
            ];
            continue;
        }

        if (preg_match($interfacePattern, $text, $m)) {
            if ($currentContext !== null) {
                $currentContext['end_line'] = $lineNum - 1;
                $contexts[] = $currentContext;
            }
            $currentContext = [
                'type' => 'interface',
                'name' => trim($m[1]),
                'start_line' => $lineNum,
                'end_line' => $lineNum,
                'lines' => [],
            ];
            continue;
        }

        if ($currentContext !== null && !$isBang && trim($text) !== '') {
            $currentContext['lines'][] = ['line' => $lineNum, 'raw' => $text];
        }
    }

    if ($currentContext !== null) {
        $currentContext['end_line'] = count($lines);
        $contexts[] = $currentContext;
    }

    return [
        'raw_lines' => $rawLines,
        'contexts'  => $contexts,
        'directives' => [], // Cisco does not need the Fortinet-style directive stack
    ];
}
