<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../compliance/engine.php';

/**
 * Deterministic NexAud reasoning layer.
 * It uses the live finding/control/device/audit/configuration records to
 * produce an explainable AI-style assessment. No state-changing action is
 * performed here.
 */
final class NexAudAuditAI
{
    public function analyzeFinding(int $findingId): array
    {
        $f = db_one(
            "SELECT f.*, c.control_code, c.title AS control_title, c.description AS control_description,
                    c.category, c.parameter, c.operator, c.expected_value AS control_expected,
                    c.evidence_requirement, c.remediation AS control_remediation,
                    fw.name AS framework_name, fw.version AS framework_version,
                    d.device_name, d.vendor AS device_vendor, d.device_type, d.model, d.os_version, d.management_ip,
                    cfg.original_filename, cfg.sha256_hash, cfg.detected_vendor, cfg.detected_confidence, cfg.version AS config_version
             FROM findings f
             JOIN controls c ON c.control_id=f.control_id
             LEFT JOIN frameworks fw ON fw.framework_id=c.framework_id
             LEFT JOIN devices d ON d.id=CAST(f.device_id AS UNSIGNED)
             LEFT JOIN configurations cfg ON cfg.id=CAST(f.configuration_id AS UNSIGNED)
             WHERE f.finding_id=?
             LIMIT 1",
            [$findingId]
        );

        if (!$f) {
            return [
                'ok' => false,
                'answer' => "Finding #{$findingId} was not found in the live NexAud database.",
                'confidence' => 0,
                'finding' => null,
                'remediation' => null,
                'validation' => [],
                'risk' => [],
                'evidence' => [],
            ];
        }

        $actual = (string)($f['actual_value'] ?? '');
        $expected = (string)($f['expected_value'] ?? $f['control_expected'] ?? '');
        $severity = strtoupper((string)$f['severity']);
        $status = strtoupper((string)$f['status']);
        $param = (string)($f['parameter'] ?? '');
        $vendor = (string)($f['device_vendor'] ?? $f['detected_vendor'] ?? 'Unknown');

        $risk = $this->riskAssessment($severity, $f, $actual, $expected);
        $why = $this->whyFailed($f, $actual, $expected);
        $remediation = $this->buildRemediation($f, $vendor, $actual, $expected);
        $validation = $this->validationPlan($f, $param, $expected);
        $confidence = $this->confidence($f);

        $answer = "AI audit assessment for finding #{$findingId}: {$status} / {$severity}. ";
        $answer .= $why . ' ';
        $answer .= 'Recommended remediation: ' . $remediation['summary'] . ' ';
        $answer .= 'Validation: ' . $validation['summary'] . ' ';
        $answer .= "AI reasoning confidence: {$confidence}%.";

        return [
            'ok' => true,
            'answer' => $answer,
            'confidence' => $confidence,
            'finding' => [
                'id' => (int)$f['finding_id'],
                'device' => $f['device_name'] ?? $f['device_id'],
                'vendor' => $vendor,
                'control_code' => $f['control_code'] ?? '',
                'control_title' => $f['control_title'] ?? '',
                'framework' => $f['framework_name'] ?? '',
                'severity' => $severity,
                'status' => $status,
                'actual' => $actual,
                'expected' => $expected,
                'parameter' => $param,
                'evidence' => $f['evidence'] ?? '',
            ],
            'remediation' => $remediation,
            'risk' => $risk,
            'validation' => $validation,
            'evidence' => [
                'configuration' => $f['original_filename'] ?? '',
                'sha256' => $f['sha256_hash'] ?? '',
                'source_line' => $f['source_line'] ?? '',
                'framework' => ($f['framework_name'] ?? '') . ' ' . ($f['framework_version'] ?? ''),
            ],
        ];
    }

    public function analyzeAudit(int $configurationId): array
    {
        $cfg = config_get($configurationId);
        if (!$cfg) {
            return ['ok' => false, 'answer' => 'Configuration not found.', 'summary' => []];
        }
        $device = db_one('SELECT * FROM devices WHERE id=?', [(int)$cfg['device_id']]);
        $latestRun = db_one('SELECT * FROM audit_runs WHERE configuration_id=? ORDER BY audit_run_id DESC LIMIT 1', [$configurationId]);
        $rows = db_all(
            'SELECT f.finding_id,f.status,f.severity,f.actual_value,f.expected_value,c.control_code,c.title
               FROM findings f JOIN controls c ON c.control_id=f.control_id
              WHERE f.configuration_id=? ORDER BY FIELD(f.severity,\'CRITICAL\',\'HIGH\',\'MEDIUM\',\'LOW\',\'INFO\'), f.finding_id DESC LIMIT 20',
            [$configurationId]
        );
        $stats = [
            'evaluations' => count($rows),
            'fail' => 0,
            'critical' => 0,
            'high' => 0,
            'manual' => 0,
        ];
        foreach ($rows as $r) {
            if ($r['status'] === 'FAIL') $stats['fail']++;
            if ($r['status'] === 'MANUAL_REVIEW') $stats['manual']++;
            if ($r['status'] === 'FAIL' && $r['severity'] === 'CRITICAL') $stats['critical']++;
            if ($r['status'] === 'FAIL' && $r['severity'] === 'HIGH') $stats['high']++;
        }
        $recommendations = [];
        if ($stats['critical'] > 0) $recommendations[] = 'Review critical findings before lower-severity remediation.';
        if ($stats['fail'] > 0) $recommendations[] = 'Run What-If on the highest-impact failed control before requesting approval.';
        if ($stats['manual'] > 0) $recommendations[] = 'Resolve MANUAL_REVIEW items with evidence or approved AI training mappings.';
        if (!$recommendations) $recommendations[] = 'No immediate failed control was returned for this configuration.';

        $compliance = $latestRun['compliance_pct'] ?? null;
        $answer = 'AI audit summary: ' . ($device['device_name'] ?? 'Unknown device') . ' has ' . $stats['fail'] . ' failed control(s) in the latest recorded evaluation';
        if ($compliance !== null) $answer .= ' with ' . $compliance . '% compliance';
        $answer .= '. ' . implode(' ', $recommendations);

        return [
            'ok' => true,
            'answer' => $answer,
            'summary' => $stats,
            'audit_run' => $latestRun,
            'device' => $device,
            'findings' => $rows,
        ];
    }

    private function whyFailed(array $f, string $actual, string $expected): string
    {
        if ($actual === '' && $expected !== '') {
            return 'The normalized model did not provide the required parameter value, so the control could not be satisfied.';
        }
        $title = trim((string)($f['control_title'] ?? $f['control_code'] ?? 'control'));
        return "The control '{$title}' expected '{$expected}', but the normalized configuration produced '{$actual}'. The compliance engine therefore marked the control as {$f['status']}.";
    }

    private function buildRemediation(array $f, string $vendor, string $actual, string $expected): array
    {
        $stored = trim((string)($f['control_remediation'] ?? $f['remediation'] ?? ''));
        if ($stored !== '') {
            return [
                'summary' => $stored,
                'before' => $actual,
                'after' => $expected,
                'vendor' => $vendor,
                'source' => 'control remediation mapping',
            ];
        }
        return [
            'summary' => "Change normalized parameter {$f['parameter']} from '{$actual}' to the expected value '{$expected}' using the {$vendor} vendor adapter and then re-audit.",
            'before' => $actual,
            'after' => $expected,
            'vendor' => $vendor,
            'source' => 'AI fallback reasoning',
        ];
    }

    private function validationPlan(array $f, string $parameter, string $expected): array
    {
        return [
            'summary' => "Run a What-If evaluation with {$parameter} set to '{$expected}', obtain human approval, then run a RE_AUDIT and confirm the finding no longer fails.",
            'steps' => [
                'What-If simulation',
                'Human approval',
                'Safe simulated apply',
                'RE_AUDIT',
                'Verify evidence chain',
            ],
        ];
    }

    private function riskAssessment(string $severity, array $f, string $actual, string $expected): array
    {
        $factors = [];
        if ($severity === 'CRITICAL') $factors[] = 'Critical control severity';
        if ($severity === 'HIGH') $factors[] = 'High control severity';
        if ($actual === '') $factors[] = 'Required value is missing';
        if (stripos($actual, 'telnet') !== false || stripos($actual, 'public') !== false) $factors[] = 'Observed configuration contains a commonly unsafe management/default value';
        return [
            'level' => $severity,
            'factors' => $factors ?: ['Severity and observed/expected control state'],
            'statement' => 'Risk is derived from the recorded control severity plus the observed configuration state; it is not a prediction of a real-world attack.',
        ];
    }

    private function confidence(array $f): int
    {
        $score = 80;
        if (!empty($f['parameter'])) $score += 5;
        if (($f['expected_value'] ?? '') !== '') $score += 5;
        if (($f['evidence'] ?? '') !== '') $score += 5;
        if (($f['control_code'] ?? '') !== '') $score += 5;
        return min(98, $score);
    }
}
