<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../devices/functions.php';
require_once __DIR__ . '/../configurations/ingest.php';
require_once __DIR__ . '/../compliance/engine.php';
require_once __DIR__ . '/../compliance/EvidenceLedger.php';
require_once __DIR__ . '/AuditAI.php';
require_once __DIR__ . '/BasicKnowledge.php';
require_once __DIR__ . '/ModuleKnowledge.php';

final class NexAudCopilotService
{
    public function ask(string $question): array
    {
        $question = trim(preg_replace('/\s+/', ' ', $question) ?? '');
        if ($question === '') {
            return $this->result(
                'Please enter a question about NexAud.',
                'empty',
                [],
                [['label' => 'Dashboard', 'url' => url('dashboard.php')]],
                $this->suggestions()
            );
        }

        $q = $this->normalize($question);

        try {
            if ($this->looksLikeHelp($q)) {
                return $this->helpResult();
            }

            $basic = $this->basicKnowledgeResult($q);
            if ($basic !== null) {
                return $basic;
            }

            if (preg_match('/\b(?:finding|issue|control failure)\s*#?\s*(\d+)\b/i', $question, $m)) {
                return $this->findingResult((int)$m[1], $q);
            }

            // Curated, action-oriented NexAud module questions take precedence over generic keyword handlers.
            $moduleKnowledge = $this->moduleKnowledgeResult($q);
            if ($moduleKnowledge !== null) {
                return $moduleKnowledge;
            }

            $deviceResult = $this->deviceEntityResult($question, $q);
            if ($deviceResult !== null) {
                return $deviceResult;
            }

            if ($this->looksLikeCountOrListQuestion($q)) {
                $countResult = $this->countListResult($q);
                if ($countResult !== null) {
                    return $countResult;
                }
            }

            if ($this->mentionsEvidenceVerification($q)) {
                return $this->evidenceVerificationResult();
            }

            if ($this->mentionsEvidence($q)) {
                return $this->evidenceResult();
            }

            if ($this->mentionsRemediation($q)) {
                return $this->remediationResult($q);
            }

            if ($this->mentionsAudit($q)) {
                return $this->auditResult($q);
            }

            if ($this->mentionsConfiguration($q) || $this->mentionsHash($q)) {
                return $this->configurationResult($q);
            }

            if ($this->mentionsNormalization($q)) {
                return $this->normalizationResult($q);
            }

            if ($this->mentionsVendorOrParser($q)) {
                return $this->vendorParserResult($q);
            }

            if ($this->mentionsTraining($q)) {
                return $this->trainingResult();
            }

            if ($this->mentionsCustomPolicy($q)) {
                return $this->customPolicyResult();
            }

            if ($this->mentionsFrameworksControls($q)) {
                return $this->frameworkResult($q);
            }

            if ($this->mentionsUsersOrAdmin($q)) {
                return $this->adminResult($q);
            }

            $module = $this->moduleQuestion($q);
            if ($module !== null) {
                return $module;
            }

            return $this->generalToolResult($q);
        } catch (Throwable $e) {
            audit_log(current_user_id(), 'AI_QUERY_ERROR', 'ai', null, [
                'question' => $question,
                'error' => substr($e->getMessage(), 0, 500),
            ]);
            return $this->result(
                'I could not read the requested NexAud data. The question was received, but the related module did not return usable data. Try asking about a specific device, finding, configuration, audit, policy, training item, evidence ledger, report, or administration page.',
                'error',
                [],
                [],
                $this->suggestions()
            );
        }
    }

    private function normalize(string $q): string
    {
        $q = strtolower($q);
        return str_replace(['–', '—', '_'], ['-', '-', ' '], $q);
    }

    private function basicKnowledgeResult(string $q): ?array
    {
        $entries = NexAudBasicKnowledge::entries();
        $best = null;
        $bestScore = 0;

        foreach ($entries as $entry) {
            foreach ($entry['patterns'] as $pattern) {
                $pattern = $this->normalize((string)$pattern);
                if ($q === $pattern) {
                    $best = $entry;
                    $bestScore = 1000;
                    break 2;
                }
                if ($pattern !== '' && str_contains($q, $pattern)) {
                    $best = $entry;
                    $bestScore = max($bestScore, 100 + strlen($pattern));
                }
            }

            $hay = $this->normalize($entry['question'] . ' ' . implode(' ', $entry['patterns']));
            $tokens = array_values(array_filter(preg_split('/\W+/', $hay) ?: [], static fn($t) => strlen((string)$t) >= 4));
            $qTokens = array_values(array_filter(preg_split('/\W+/', $q) ?: [], static fn($t) => strlen((string)$t) >= 4));
            if ($tokens && $qTokens) {
                $hits = 0;
                foreach (array_unique($qTokens) as $qt) {
                    foreach ($tokens as $token) {
                        if ($qt === $token || (strlen($qt) >= 6 && str_contains($token, $qt)) || (strlen($token) >= 6 && str_contains($qt, $token))) {
                            $hits++;
                            break;
                        }
                    }
                }
                $score = $hits * 8;
                if ($hits >= 3 && $score > $bestScore) {
                    $best = $entry;
                    $bestScore = $score;
                }
            }
        }

        if ($best === null || $bestScore < 20) {
            return null;
        }

        $links = array_map(static fn(array $l): array => ['label'=>$l['label'], 'url'=>url($l['url'])], $best['links']);
        $suggestions = $best['suggestions'];
        if (!$suggestions) {
            $suggestions = [
                'Explain this with a simple example.',
                'How is this related to network security?',
                'How would NexAud audit this?',
            ];
        }
        return $this->result(
            $best['answer'],
            'basic_' . strtolower(preg_replace('/[^a-z0-9]+/i', '_', $best['category']) ?? 'security'),
            ['Basic Security Knowledge · ' . $best['category']],
            $links,
            $suggestions,
            ['question_type'=>'basic','matched_question'=>$best['question'],'category'=>$best['category']]
        );
    }

    private function basicKnowledgeCatalog(): array
    {
        return NexAudBasicKnowledge::entries();
    }

    private function result(string $answer, string $intent, array $sources = [], array $links = [], array $suggestions = [], array $data = []): array
    {
        return [
            'answer' => $answer,
            'intent' => $intent,
            'mode' => 'NexAud Tool-Aware Copilot',
            'sources' => $sources,
            'links' => $links,
            'suggestions' => $suggestions,
            'data' => $data,
        ];
    }

    private function suggestions(): array
    {
        return [
            'What is the CIA triad?',
            'What is least privilege?',
            'What is a firewall?',
            'What is an ACL?',
            'Why is Telnet risky?',
            'What is SSH?',
            'What is SNMP?',
            'What is AAA?',
            'What is MFA?',
            'What is RBAC?',
            'What is Zero Trust?',
            'What is a vulnerability?',
            'What is CVE?',
            'What is CVSS?',
            'What is SIEM?',
            'What is NTP?',
            'What is CIS?',
            'What is NIST?',
            'What is ISO 27001?',
            'What is the Evidence Ledger?',
            'Why did finding #23 fail?',
            'What happened in the latest audit?',
        ];
    }

    private function helpResult(): array
    {
        $links = [];
        foreach ($this->modules() as $key => $module) {
            $links[] = ['label' => $module['name'], 'url' => url($module['url'])];
        }
        $answer = "I am the NexAud Tool-Aware Copilot. I answer questions about the live NexAud application data and explain how its modules work. "
            . "I can read devices, configurations, audits, findings, frameworks, controls, custom policies, AI training data, evidence ledger status, reports and administration metadata. "
            . "I do not execute destructive actions from a chat question. Approval, remediation and other state-changing operations stay inside their protected workflows.";
        $data = ['modules' => array_values(array_map(static function (array $m): array {
            return ['name' => $m['name'], 'purpose' => $m['purpose'], 'url' => $m['url']];
        }, $this->modules()))];
        return $this->result($answer, 'help', ['NexAud module catalog'], $links, $this->suggestions(), $data);
    }

    private function findingResult(int $findingId, string $q = ''): array
    {
        $row = db_one(
            "SELECT f.*, c.control_code, c.title, c.description, c.category, c.parameter, c.operator,
                    c.expected_value AS control_expected, c.remediation AS control_remediation,
                    fw.name AS framework_name, d.device_name
               FROM findings f
               LEFT JOIN controls c ON c.control_id = f.control_id
               LEFT JOIN frameworks fw ON fw.framework_id = c.framework_id
               LEFT JOIN devices d ON CAST(d.id AS CHAR) = f.device_id
              WHERE f.finding_id = ?",
            [$findingId]
        );

        if (!$row) {
            return $this->result(
                "I could not find finding #{$findingId} in NexAud.",
                'finding_not_found',
                ['findings'],
                [['label' => 'Findings', 'url' => url('findings/index.php')]],
                $this->suggestions()
            );
        }

        $rem = db_one(
            'SELECT * FROM remediation_requests WHERE finding_id=? ORDER BY remediation_request_id DESC LIMIT 1',
            [$findingId]
        );
        $ai = (new NexAudAuditAI())->analyzeFinding($findingId);
        $audit = db_one(
            'SELECT * FROM audit_runs WHERE audit_run_id=?',
            [(int)($row['audit_run_id'] ?? 0)]
        );

        $status = strtoupper((string)$row['status']);
        $severity = strtoupper((string)$row['severity']);
        $observed = (string)($row['actual_value'] ?? '');
        $expected = (string)($row['expected_value'] ?? $row['control_expected'] ?? '');
        $answer = "Finding #{$findingId} is {$status} with {$severity} severity. "
            . "It affects " . ($row['device_name'] ?? ('device #' . $row['device_id'])) . " and control " . ($row['control_code'] ?? 'unknown') . ". "
            . "Observed value: {$observed}. Expected value: {$expected}.";
        if (!empty($ai['ok'])) {
            $answer .= ' AI audit reasoning: ' . $ai['answer'];
        }
        if (!empty($row['title'])) {
            $answer .= " The control is titled '{$row['title']}'.";
        }
        if (!empty($row['evidence'])) {
            $answer .= " Evidence: " . trim((string)$row['evidence']) . '.';
        }
        if (!empty($row['remediation'])) {
            $answer .= " Recommended remediation: " . trim((string)$row['remediation']) . '.';
        }
        if ($audit) {
            $answer .= " It belongs to audit run #" . (int)$audit['audit_run_id'] . " (" . $audit['mode'] . ") at " . $audit['compliance_pct'] . "% compliance.";
        }
        if ($rem) {
            $answer .= " The latest remediation request is #" . (int)$rem['remediation_request_id'] . " with status " . $rem['status'] . ".";
        }

        return $this->result(
            $answer,
            'finding',
            ['findings', 'controls', 'audit_runs', 'remediation_requests'],
            [
                ['label' => 'Open Finding', 'url' => url('findings/view.php?id=' . $findingId)],
                ['label' => 'Remediation Workflow', 'url' => url('findings/remediation.php?id=' . $findingId)],
            ],
            ['Run What-If for finding #' . $findingId, 'What is the remediation status?', 'Explain this finding in simple terms.'],
            ['finding' => $this->compactRow($row), 'remediation' => $rem, 'audit' => $audit, 'ai_analysis' => $ai]
        );
    }

    private function deviceEntityResult(string $question, string $q): ?array
    {
        $rows = db_all('SELECT id,device_name,vendor,device_type,model,os_version,status,management_ip FROM devices ORDER BY id DESC LIMIT 100');
        if (!$rows) return null;
        $match = null;
        foreach ($rows as $d) {
            $name = strtolower((string)$d['device_name']);
            if ($name !== '' && str_contains(strtolower($question), $name)) {
                $match = $d; break;
            }
        }
        if (!$match) return null;
        $latest = db_one('SELECT * FROM configurations WHERE device_id=? ORDER BY id DESC LIMIT 1', [(int)$match['id']]);
        $fail = (int)db_value('SELECT COUNT(*) FROM findings WHERE device_id=? AND status=\'FAIL\'', [(string)$match['id']], 0);
        $answer = "Device {$match['device_name']} is a {$match['vendor']} {$match['model']} ({$match['device_type']}) in {$match['status']} status. "
            . "Management host: {$match['management_ip']}. It currently has {$fail} failed finding(s).";
        if ($latest) {
            $answer .= " Latest configuration: #{$latest['id']} ({$latest['original_filename']}), vendor {$latest['detected_vendor']}, SHA-256 {$latest['sha256_hash']}.";
        }
        $links = [['label'=>'Open Device','url'=>url('devices/view.php?id='.(int)$match['id'])]];
        if ($latest) $links[]=['label'=>'Open Configuration','url'=>url('configurations/view.php?id='.(int)$latest['id'])];
        return $this->result($answer,'device',['devices','configurations','findings'],$links,['Why is this device non-compliant?','Explain the latest configuration.'],['device'=>$match,'latest_configuration'=>$latest,'failed_findings'=>$fail]);
    }

    private function evidenceVerificationResult(): array
    {
        $ledger = new EvidenceLedger(getDB());
        $check = $ledger->verify();
        $answer = $check['result'] === 'VERIFIED'
            ? "The Evidence Ledger is VERIFIED. " . (int)$check['blocks_checked'] . " block(s) were checked, including block hashes and previous-block links."
            : "The Evidence Ledger currently reports an integrity violation. " . (int)$check['blocks_checked'] . " block(s) were checked. " . implode(' ', array_slice($check['violations'] ?? [], 0, 3));
        return $this->result(
            $answer,
            'evidence_verify',
            ['evidence_ledger'],
            [['label' => 'Verify Chain', 'url' => url('evidence/verify.php')], ['label' => 'Evidence Ledger', 'url' => url('evidence/index.php')]],
            ['What events are stored in the ledger?', 'How does the hash chain work?', 'Show the latest evidence events.'],
            ['verification' => $check]
        );
    }

    private function evidenceResult(): array
    {
        $count = (int)db_value('SELECT COUNT(*) FROM evidence_ledger', [], 0);
        $latest = db_one('SELECT * FROM evidence_ledger ORDER BY sequence_number DESC LIMIT 1');
        $genesis = db_one('SELECT * FROM evidence_ledger WHERE sequence_number=0 LIMIT 1');
        $events = db_all('SELECT sequence_number,event_type,device_id,configuration_id,finding_id,created_by,timestamp FROM evidence_ledger ORDER BY sequence_number DESC LIMIT 8');
        $answer = "NexAud's Evidence Ledger is a hash-chained audit trail. It currently contains {$count} block(s). "
            . "Important lifecycle events can include configuration ingestion, audit completion, findings, remediation, re-audit and report generation. ";
        if ($latest) {
            $answer .= "The latest event is " . $latest['event_type'] . " at sequence " . (int)$latest['sequence_number'] . " created by " . $latest['created_by'] . ".";
        }
        return $this->result(
            $answer,
            'evidence',
            ['evidence_ledger'],
            [['label' => 'Evidence Ledger', 'url' => url('evidence/index.php')], ['label' => 'Verify Chain', 'url' => url('evidence/verify.php')]],
            ['Verify the evidence chain', 'What created the Genesis block?', 'Explain why an evidence hash is used.'],
            ['count' => $count, 'genesis' => $genesis, 'latest' => $latest, 'recent_events' => $events]
        );
    }

    private function remediationResult(string $q): array
    {
        $findingId = null;
        if (preg_match('/(?:finding|issue)\s*#?\s*(\d+)/', $q, $m)) {
            $findingId = (int)$m[1];
        }

        if ($findingId !== null) {
            $rem = db_one('SELECT r.*, f.status AS finding_status, f.actual_value, f.expected_value, c.control_code, c.title FROM remediation_requests r JOIN findings f ON f.finding_id=r.finding_id JOIN controls c ON c.control_id=f.control_id WHERE r.finding_id=? ORDER BY r.remediation_request_id DESC LIMIT 1', [$findingId]);
            if (!$rem) {
                return $this->result(
                    "There is no remediation request yet for finding #{$findingId}. Open the finding and run the What-If simulation to create one.",
                    'remediation_none',
                    ['findings', 'remediation_requests'],
                    [['label' => 'Open Finding', 'url' => url('findings/view.php?id=' . $findingId)]],
                    ['Run What-If for finding #' . $findingId]
                );
            }
            $answer = "Remediation request #" . (int)$rem['remediation_request_id'] . " for finding #{$findingId} is in status {$rem['status']}. ";
            if ($rem['current_compliance'] !== null || $rem['projected_compliance'] !== null) {
                $answer .= "Current compliance is " . ($rem['current_compliance'] ?? '—') . "%, projected compliance is " . ($rem['projected_compliance'] ?? '—') . "%. ";
            }
            if ($rem['remediation_text']) $answer .= 'Proposed action: ' . trim((string)$rem['remediation_text']) . '.';
            return $this->result(
                $answer,
                'remediation',
                ['remediation_requests', 'findings'],
                [['label' => 'Remediation Workflow', 'url' => url('findings/remediation.php?id=' . $findingId)]],
                ['What happens after approval?', 'Run What-If for another finding.'],
                ['remediation' => $rem]
            );
        }

        $rows = db_all('SELECT r.*, f.status AS finding_status, f.severity, c.control_code, d.device_name FROM remediation_requests r JOIN findings f ON f.finding_id=r.finding_id LEFT JOIN controls c ON c.control_id=f.control_id LEFT JOIN devices d ON CAST(d.id AS CHAR)=f.device_id ORDER BY r.created_at DESC LIMIT 10');
        $answer = 'NexAud remediation works as What-If → Pending Approval → Approved/Rejected → Safe Re-Audit. The prototype does not connect to live devices; the approval workflow uses a safe simulated configuration snapshot.';
        return $this->result(
            $answer,
            'remediation_overview',
            ['remediation_requests', 'findings'],
            [['label' => 'Findings', 'url' => url('findings/index.php')]],
            ['What-If vs actual remediation?', 'How does human approval work?', 'How does re-audit work?'],
            ['recent_remediations' => $rows]
        );
    }

    private function auditResult(string $q): array
    {
        $latest = db_one(
            "SELECT a.*, c.original_filename, c.sha256_hash, d.device_name, d.vendor
               FROM audit_runs a
               JOIN configurations c ON c.id = a.configuration_id
               LEFT JOIN devices d ON d.id = c.device_id
              ORDER BY a.audit_run_id DESC LIMIT 1"
        );
        $count = (int)db_value('SELECT COUNT(*) FROM audit_runs');
        $fail = (int)db_value("SELECT COUNT(*) FROM findings WHERE status='FAIL'");
        $manual = (int)db_value("SELECT COUNT(*) FROM findings WHERE status='MANUAL_REVIEW'");
        $answer = "NexAud has {$count} recorded audit run(s). There are currently {$fail} FAIL finding(s) and {$manual} MANUAL_REVIEW finding(s).";
        if ($latest) {
            $answer .= " The latest audit is #" . (int)$latest['audit_run_id'] . " in " . $latest['mode'] . " mode for " . ($latest['device_name'] ?? 'the device') . ", with " . $latest['compliance_pct'] . "% compliance and status " . $latest['status'] . ".";
        }
        $links = [['label' => 'Audits & Analysis', 'url' => url('analysis/index.php')]];
        if ($latest) $links[] = ['label' => 'Audit Results', 'url' => url('analysis/results.php?configuration_id=' . (int)$latest['configuration_id'])];
        return $this->result(
            $answer,
            'audit',
            ['audit_runs', 'findings', 'configurations', 'devices'],
            $links,
            ['What findings were produced by the latest audit?', 'Explain the latest audit.', 'Show audit history.'],
            ['latest_audit' => $latest, 'audit_count' => $count, 'fail_count' => $fail, 'manual_review_count' => $manual]
        );
    }

    private function configurationResult(string $q): array
    {
        $latest = db_one(
            'SELECT c.*, d.device_name, d.vendor FROM configurations c LEFT JOIN devices d ON d.id=c.device_id ORDER BY c.id DESC LIMIT 1'
        );
        $count = (int)db_value('SELECT COUNT(*) FROM configurations');
        $answer = "NexAud has {$count} configuration record(s). ";
        if ($latest) {
            $answer .= "The latest configuration is #" . (int)$latest['id'] . " (" . $latest['original_filename'] . ") for " . ($latest['device_name'] ?? 'device #' . $latest['device_id']) . ". "
                . "Vendor: " . ($latest['detected_vendor'] ?? $latest['vendor'] ?? 'Unknown') . ". SHA-256: " . $latest['sha256_hash'] . ". Ingest status: " . $latest['ingest_status'] . ".";
            if ($this->mentionsHash($q)) {
                $answer .= ' The SHA-256 value is the integrity fingerprint of that uploaded configuration; a changed file produces a different hash.';
            }
        }
        return $this->result(
            $answer,
            'configuration',
            ['configurations', 'devices'],
            [['label' => 'Configurations', 'url' => url('configurations/index.php')]],
            ['What is the latest configuration?', 'Explain SHA-256 in NexAud.', 'Explain normalized configuration.'],
            ['latest_configuration' => $latest, 'count' => $count]
        );
    }

    private function normalizationResult(string $q): array
    {
        $row = db_one(
            'SELECT n.*, c.original_filename, c.detected_vendor, c.detected_confidence, c.sha256_hash, d.device_name FROM normalized_configurations n JOIN configurations c ON c.id=n.configuration_id LEFT JOIN devices d ON d.id=c.device_id ORDER BY n.id DESC LIMIT 1'
        );
        $answer = 'Vendor-neutral normalization converts vendor-specific configuration syntax into the NexAud common security configuration schema so the same compliance logic can evaluate multiple vendors.';
        if ($row) {
            $model = json_decode((string)$row['normalized_json'], true);
            $parameterCount = is_array($model) ? $this->countNormalizedParameters($model) : 0;
            $answer .= " The latest normalized configuration is for " . ($row['device_name'] ?? 'a device') . " (" . ($row['detected_vendor'] ?? 'Unknown') . ") and contains approximately {$parameterCount} normalized leaf parameter(s).";
        }
        return $this->result(
            $answer,
            'normalization',
            ['normalized_configurations', 'configurations'],
            [['label' => 'Configurations', 'url' => url('configurations/index.php')]],
            ['Show the latest normalized values', 'How does vendor detection work?', 'Why is normalization needed?'],
            ['latest_normalization' => $row]
        );
    }

    private function vendorParserResult(string $q): array
    {
        $vendors = db_all('SELECT detected_vendor AS vendor, COUNT(*) AS configurations FROM configurations GROUP BY detected_vendor ORDER BY configurations DESC');
        $answer = 'NexAud detects the vendor from configuration syntax, then sends the configuration through the matching parser. The parser extracts security-relevant structures before normalization. The deterministic pipeline currently includes Cisco, Fortinet, Palo Alto and an Unknown path for unrecognized structures.';
        return $this->result(
            $answer,
            'vendor_parser',
            ['configuration ingestion and parser pipeline'],
            [['label' => 'Upload Configuration', 'url' => url('configurations/upload.php')], ['label' => 'Configurations', 'url' => url('configurations/index.php')]],
            ['How does unknown configuration handling work?', 'How does normalization work?'],
            ['detected_vendors' => $vendors]
        );
    }

    private function trainingResult(): array
    {
        $pending = (int)db_value("SELECT COUNT(*) FROM ai_unknown_commands WHERE status IN ('pending','analyzed')", [], 0);
        $approved = (int)db_value("SELECT COUNT(*) FROM ai_mappings WHERE status='approved'", [], 0);
        $total = (int)db_value('SELECT COUNT(*) FROM ai_unknown_commands', [], 0);
        $answer = "AI Training quarantines configuration structures the deterministic parser cannot classify. There are currently {$pending} pending/analyzed unknown command(s), {$approved} approved mapping(s), and {$total} total unknown-command record(s). Approved mappings can be reused in future processing.";
        return $this->result(
            $answer,
            'training',
            ['ai_unknown_commands', 'ai_mappings'],
            [['label' => 'AI Training', 'url' => url('training/index.php')]],
            ['How are unknown commands reviewed?', 'What is a learned mapping?', 'How does human approval work?'],
            ['pending_unknowns' => $pending, 'approved_mappings' => $approved, 'total_unknowns' => $total]
        );
    }

    private function customPolicyResult(): array
    {
        $customFrameworks = (int)db_value("SELECT COUNT(*) FROM frameworks WHERE framework_type='CUSTOM'", [], 0);
        $customControls = (int)db_value("SELECT COUNT(*) FROM controls c JOIN frameworks f ON f.framework_id=c.framework_id WHERE f.framework_type='CUSTOM'", [], 0);
        $answer = "Custom Policies lets an administrator define organization-specific controls on top of the NexAud common security baseline. There are currently {$customFrameworks} custom framework(s) and {$customControls} control(s) under them.";
        return $this->result(
            $answer,
            'custom_policy',
            ['frameworks', 'controls'],
            [['label' => 'Custom Policies', 'url' => url('compliance/custom-policies.php')], ['label' => 'Policy Builder', 'url' => url('controls/edit.php?new=1')]],
            ['How do I create a custom policy?', 'Will a custom policy be used by an audit?', 'What fields does Policy Builder require?'],
            ['custom_frameworks' => $customFrameworks, 'custom_controls' => $customControls]
        );
    }

    private function frameworkResult(string $q): array
    {
        $frameworks = db_all('SELECT f.framework_id,f.name,f.version,f.framework_type,f.status,COUNT(c.control_id) AS controls FROM frameworks f LEFT JOIN controls c ON c.framework_id=f.framework_id AND c.enabled=1 GROUP BY f.framework_id,f.name,f.version,f.framework_type,f.status ORDER BY f.name');
        $controlCount = (int)db_value('SELECT COUNT(*) FROM controls WHERE enabled=1');
        $answer = 'NexAud evaluates the normalized security model against enabled controls grouped under frameworks. The current database contains ' . count($frameworks) . ' framework(s) and ' . $controlCount . ' enabled control(s).';
        return $this->result(
            $answer,
            'frameworks_controls',
            ['frameworks', 'controls'],
            [['label' => 'Frameworks', 'url' => url('compliance/index.php')], ['label' => 'Controls', 'url' => url('controls/index.php')]],
            ['How many controls are enabled?', 'What is a custom policy?', 'Explain a failed control.'],
            ['frameworks' => $frameworks, 'enabled_control_count' => $controlCount]
        );
    }

    private function adminResult(string $q): array
    {
        $users = (int)db_value('SELECT COUNT(*) FROM users');
        $roles = (int)db_value('SELECT COUNT(*) FROM roles');
        $logs = (int)db_value('SELECT COUNT(*) FROM audit_logs');
        $answer = "NexAud administration currently contains {$users} user(s), {$roles} role(s), and {$logs} audit-log record(s). The Users, Settings and Audit Logs pages are administrative areas protected by permissions.";
        return $this->result(
            $answer,
            'admin',
            ['users', 'roles', 'audit_logs'],
            [['label' => 'Users', 'url' => url('admin/users.php')], ['label' => 'Settings', 'url' => url('admin/settings.php')], ['label' => 'Audit Logs', 'url' => url('admin/audit-logs.php')]],
            ['How do permissions work?', 'What is recorded in Audit Logs?', 'What settings are available?'],
            ['users' => $users, 'roles' => $roles, 'audit_logs' => $logs]
        );
    }

    private function countListResult(string $q): ?array
    {
        if (str_contains($q, 'device')) {
            $count = (int)db_value('SELECT COUNT(*) FROM devices');
            $rows = db_all('SELECT id,device_name,vendor,device_type,status,management_ip FROM devices ORDER BY id DESC LIMIT 10');
            return $this->result("There are {$count} device(s) registered in NexAud.", 'devices', ['devices'], [['label' => 'Devices', 'url' => url('devices/index.php')]], ['Show the latest configuration.', 'Which devices have findings?'], ['count' => $count, 'devices' => $rows]);
        }
        if (str_contains($q, 'configuration')) {
            $count = (int)db_value('SELECT COUNT(*) FROM configurations');
            $rows = db_all('SELECT id,device_id,original_filename,detected_vendor,version,ingest_status,upload_time FROM configurations ORDER BY id DESC LIMIT 10');
            return $this->result("There are {$count} configuration record(s).", 'configurations', ['configurations'], [['label' => 'Configurations', 'url' => url('configurations/index.php')]], ['What is the latest configuration?', 'Explain SHA-256.'], ['count' => $count, 'configurations' => $rows]);
        }
        if (str_contains($q, 'finding')) {
            $count = (int)db_value('SELECT COUNT(*) FROM findings');
            $rows = db_all("SELECT f.finding_id,f.status,f.severity,c.control_code,d.device_name FROM findings f LEFT JOIN controls c ON c.control_id=f.control_id LEFT JOIN devices d ON CAST(d.id AS CHAR)=f.device_id ORDER BY f.finding_id DESC LIMIT 10");
            return $this->result("There are {$count} finding(s) recorded in NexAud.", 'findings', ['findings'], [['label' => 'Findings', 'url' => url('findings/index.php')]], ['Why did finding #23 fail?', 'What are the critical findings?'], ['count' => $count, 'findings' => $rows]);
        }
        if (str_contains($q, 'framework') || str_contains($q, 'control')) {
            return $this->frameworkResult($q);
        }
        if (str_contains($q, 'unknown') || str_contains($q, 'mapping')) {
            return $this->trainingResult();
        }
        if (str_contains($q, 'report')) {
            $count = (int)db_value('SELECT COUNT(*) FROM report_runs');
            $rows = db_all('SELECT * FROM report_runs ORDER BY generated_at DESC LIMIT 8');
            return $this->result("There are {$count} report run(s) recorded.", 'reports', ['report_runs'], [['label' => 'Reports', 'url' => url('reports/index.php')]], ['Generate a report for the latest audit.', 'What does a report contain?'], ['count' => $count, 'reports' => $rows]);
        }
        return null;
    }

    private function generalToolResult(string $q): array
    {
        foreach ($this->modules() as $module) {
            $score = $this->keywordScore($q, $module['keywords']);
            if ($score >= 2) {
                return $this->result(
                    $module['purpose'] . ' ' . $module['howto'],
                    'module:' . $module['key'],
                    ['NexAud module documentation'],
                    [['label' => 'Open ' . $module['name'], 'url' => url($module['url'])]],
                    $module['examples']
                );
            }
        }

        return $this->result(
            "I understand NexAud-specific questions, but I could not confidently identify the module or data you are asking about. Try naming a NexAud area such as Devices, Configurations, Audits, Findings, Compliance, Custom Policies, AI Training, Evidence Ledger, Reports, Users, Settings, or Audit Logs.",
            'unknown_question',
            ['NexAud module catalog'],
            [['label' => 'Dashboard', 'url' => url('dashboard.php')]],
            $this->suggestions()
        );
    }

    private function moduleKnowledgeResult(string $q): ?array
    {
        $entries = NexAudModuleKnowledge::allQuestions();
        $best = null;
        $bestScore = 0;
        foreach ($entries as $entry) {
            $hay = $this->normalize($entry['module'] . ' ' . $entry['question']);
            $score = 0;
            if (str_contains($q, $this->normalize($entry['module']))) {
                $score += 15;
            }
            $qTokens = array_values(array_filter(preg_split('/\W+/', $q) ?: [], static fn($t) => strlen((string)$t) >= 4));
            $tokens = array_values(array_filter(preg_split('/\W+/', $hay) ?: [], static fn($t) => strlen((string)$t) >= 4));
            foreach (array_unique($qTokens) as $qt) {
                foreach ($tokens as $token) {
                    if ($qt === $token || (strlen($qt) >= 6 && str_contains($token, $qt)) || (strlen($token) >= 6 && str_contains($qt, $token))) {
                        $score += 5;
                        break;
                    }
                }
            }
            if ($score > $bestScore) {
                $best = $entry;
                $bestScore = $score;
            }
        }
        if ($best === null || $bestScore < 15) {
            return null;
        }
        $suggestions = [
            'Show me more questions about ' . $best['module'] . '.',
            'How does ' . $best['module'] . ' connect to the audit workflow?',
            'Explain ' . $best['module'] . ' in simple terms.',
        ];
        return $this->result(
            $best['answer'],
            'module_knowledge_' . strtolower(preg_replace('/[^a-z0-9]+/i', '_', $best['module']) ?? 'nexaud'),
            ['NexAud module knowledge · ' . $best['module']],
            [['label'=>'Open ' . $best['module'], 'url'=>url($best['url'])]],
            $suggestions,
            ['question_type'=>'module_knowledge','module'=>$best['module'],'matched_question'=>$best['question']]
        );
    }

    private function moduleQuestion(string $q): ?array
    {
        if (str_contains($q, 'how many') || str_contains($q, 'latest') || str_contains($q, 'which') || str_contains($q, 'show') || str_contains($q, 'why')) {
            return null;
        }
        if (!(str_contains($q, 'how') || str_contains($q, 'what is') || str_contains($q, 'explain') || str_contains($q, 'where') || str_contains($q, 'open') || str_contains($q, 'work'))) {
            return null;
        }
        foreach ($this->modules() as $module) {
            if ($this->keywordScore($q, $module['keywords']) >= 2) {
                $answer = $module['purpose'] . ' ' . $module['howto'];
                return $this->result(
                    $answer,
                    'module:' . $module['key'],
                    ['NexAud module documentation'],
                    [['label' => 'Open ' . $module['name'], 'url' => url($module['url'])]],
                    $module['examples']
                );
            }
        }
        return null;
    }

    private function modules(): array
    {
        return [
            'dashboard' => ['key'=>'dashboard','name'=>'Dashboard','url'=>'dashboard.php','purpose'=>'The Dashboard summarizes the current NexAud security posture, device/configuration totals, finding counts and recent audit activity.','howto'=>'Use it as the entry point, then open the relevant operational module for details.','keywords'=>['dashboard','overview','posture','summary','status','metrics'],'examples'=>['What are the current findings?','How many devices are registered?']],
            'devices' => ['key'=>'devices','name'=>'Devices','url'=>'devices/index.php','purpose'=>'Devices stores the network endpoints NexAud audits, including vendor, model, OS, management host, type, environment, owner and status.','howto'=>'Add a demo or real inventory record in Devices, then associate configuration files with that device.','keywords'=>['device','devices','router','firewall','switch','inventory','host','management ip','vendor'],'examples'=>['How do I add a device?','Which vendors are registered?']],
            'configurations' => ['key'=>'configurations','name'=>'Configurations','url'=>'configurations/index.php','purpose'=>'Configurations manages uploaded configuration versions, SHA-256 hashes, vendor detection results and normalized configuration records.','howto'=>'Upload a text-based configuration for a registered device; NexAud stores a safe randomized copy, calculates SHA-256, detects the vendor, parses and normalizes the configuration.','keywords'=>['configuration','config','upload','sha','sha256','hash','ingest','ingestion','version'],'examples'=>['What is the latest configuration?','Explain SHA-256.']],
            'audits' => ['key'=>'audits','name'=>'Audits & Analysis','url'=>'analysis/index.php','purpose'=>'Audits & Analysis runs compliance evaluations against the normalized configuration and records audit runs and results.','howto'=>'Choose a configuration, run the audit, then inspect the resulting evaluation and findings.','keywords'=>['audit','audits','analysis','run audit','evaluate','compliance check','baseline','re audit'],'examples'=>['What happened in the latest audit?','How does re-audit work?']],
            'findings' => ['key'=>'findings','name'=>'Findings','url'=>'findings/index.php','purpose'=>'Findings contains control results, including PASS, FAIL and MANUAL_REVIEW records with severity, observed value, expected value, evidence and remediation.','howto'=>'Open a finding for the detailed evidence and use the Remediation workflow for What-If, approval and safe re-audit.','keywords'=>['finding','findings','issue','failed','fail','risk','severity','why failed'],'examples'=>['Why did finding #23 fail?','Show critical findings.']],
            'frameworks' => ['key'=>'frameworks','name'=>'Frameworks','url'=>'compliance/index.php','purpose'=>'Frameworks groups the enabled security controls used for compliance evaluation.','howto'=>'Review a framework, its version/status and control count, then open the Control Catalog for individual rules.','keywords'=>['framework','frameworks','cis','nist','stig','iso','iso27001','benchmark'],'examples'=>['Which frameworks are installed?','How many controls are enabled?']],
            'controls' => ['key'=>'controls','name'=>'Controls','url'=>'controls/index.php','purpose'=>'Controls are the individual security rules evaluated against the vendor-neutral normalized configuration.','howto'=>'Use the catalog to inspect the parameter, operator, expected value, severity, evidence requirement and remediation for a control.','keywords'=>['control','controls','rule','rules','parameter','operator','expected value'],'examples'=>['Explain control ORG-NET-001.','What is the expected value for this control?']],
            'policies' => ['key'=>'policies','name'=>'Custom Policies','url'=>'compliance/custom-policies.php','purpose'=>'Custom Policies defines organization-specific controls on top of the common NexAud baseline.','howto'=>'Open Policy Builder, choose or create a custom framework, define the control code, normalized parameter, operator and expected value, then save the policy.','keywords'=>['custom policy','custom policies','policy','policies','policy builder','organization control'],'examples'=>['How do I create a custom policy?','Will a custom policy be audited?']],
            'ai' => ['key'=>'ai','name'=>'AI Copilot','url'=>'ai/index.php','purpose'=>'AI Copilot answers NexAud-specific questions using application context and database data.','howto'=>'Ask about a module, device, configuration, finding, audit, policy, training item, evidence ledger or report. State a finding number or device name when you want a specific lookup.','keywords'=>['ai copilot','copilot','assistant','ask','question','ai'],'examples'=>['Explain finding #23.','What happened in the latest audit?']],
            'training' => ['key'=>'training','name'=>'AI Training','url'=>'training/index.php','purpose'=>'AI Training quarantines unknown configuration structures and records administrator-approved mappings for future recognition.','howto'=>'Review an unknown command, choose its normalized meaning and expected value, then approve the mapping for future configurations.','keywords'=>['training','unknown','unknown command','mapping','learned mapping','quarantine','ai training'],'examples'=>['How does unknown command training work?','How many mappings are approved?']],
            'evidence' => ['key'=>'evidence','name'=>'Evidence Ledger','url'=>'evidence/index.php','purpose'=>'Evidence Ledger is a hash-chained audit trail for important lifecycle events and configuration evidence metadata.','howto'=>'Open Evidence Ledger to inspect the chain, then use Verify Chain to recompute block hashes and previous-block links.','keywords'=>['evidence','ledger','hash chain','audit trail','genesis','block','tamper','integrity'],'examples'=>['Is the Evidence Ledger valid?','What is the latest evidence event?']],
            'reports' => ['key'=>'reports','name'=>'Reports','url'=>'reports/index.php','purpose'=>'Reports assembles audit findings, remediation lifecycle information, configuration hashes and evidence verification into an audit report.','howto'=>'Open a configuration report and use the downloadable report or Print/Save PDF action.','keywords'=>['report','reports','pdf','document','export'],'examples'=>['What does the latest report contain?','How do I generate a PDF?']],
            'users' => ['key'=>'users','name'=>'Users','url'=>'admin/users.php','purpose'=>'Users manages application accounts and role assignments.','howto'=>'Use the admin Users page to review the accounts available in the NexAud environment.','keywords'=>['user','users','account','accounts','role','roles','permission','permissions'],'examples'=>['How many users are there?','What roles exist?']],
            'settings' => ['key'=>'settings','name'=>'Settings','url'=>'admin/settings.php','purpose'=>'Settings exposes system-level configuration values and application administration options.','howto'=>'Open Settings only with the appropriate administrator permissions.','keywords'=>['settings','system settings','configuration settings','admin settings'],'examples'=>['Where are the NexAud settings?','What system settings exist?']],
            'logs' => ['key'=>'logs','name'=>'Audit Logs','url'=>'admin/audit-logs.php','purpose'=>'Audit Logs records security-relevant user and application actions for traceability.','howto'=>'Use Audit Logs to review who performed an action, its category/target metadata and timestamp.','keywords'=>['audit logs','audit log','logs','activity','history','who changed','traceability'],'examples'=>['What is recorded in Audit Logs?','Who performed the last action?']],
        ];
    }

    private function keywordScore(string $q, array $keywords): int
    {
        $score = 0;
        foreach ($keywords as $keyword) {
            if (str_contains($q, strtolower($keyword))) {
                $score += str_contains($keyword, ' ') ? 2 : 1;
            }
        }
        return $score;
    }

    private function countNormalizedParameters(array $value): int
    {
        $count = 0;
        $walk = function ($node) use (&$walk, &$count): void {
            if (!is_array($node)) {
                $count++;
                return;
            }
            if (array_key_exists('value', $node) && count(array_diff(array_keys($node), ['value', 'source', 'vendor'])) === 0) {
                $count++;
                return;
            }
            foreach ($node as $child) {
                $walk($child);
            }
        };
        $walk($value);
        return $count;
    }

    private function compactRow(array $row): array
    {
        $keep = ['finding_id','audit_run_id','device_id','configuration_id','control_code','title','framework_name','category','severity','status','parameter','operator','actual_value','expected_value','evidence','remediation','device_name','created_at'];
        $out = [];
        foreach ($keep as $key) {
            if (array_key_exists($key, $row)) $out[$key] = $row[$key];
        }
        return $out;
    }

    private function mentionsEvidenceVerification(string $q): bool
    {
        return (str_contains($q, 'verify') || str_contains($q, 'verified') || str_contains($q, 'valid')) && (str_contains($q, 'evidence') || str_contains($q, 'ledger') || str_contains($q, 'chain'));
    }

    private function mentionsEvidence(string $q): bool
    {
        return str_contains($q, 'evidence') || str_contains($q, 'ledger') || str_contains($q, 'hash chain');
    }

    private function mentionsRemediation(string $q): bool
    {
        return str_contains($q, 'remediation') || str_contains($q, 'what-if') || str_contains($q, 'what if') || str_contains($q, 'approval') || str_contains($q, 'approve') || str_contains($q, 're-audit') || str_contains($q, 'reaudit');
    }

    private function mentionsAudit(string $q): bool
    {
        return str_contains($q, 'audit') || str_contains($q, 'compliance result') || str_contains($q, 'compliance score');
    }

    private function mentionsConfiguration(string $q): bool
    {
        return str_contains($q, 'configuration') || str_contains($q, 'config file') || str_contains($q, 'uploaded config');
    }

    private function mentionsHash(string $q): bool
    {
        return str_contains($q, 'sha-256') || str_contains($q, 'sha256') || str_contains($q, 'hash');
    }

    private function mentionsNormalization(string $q): bool
    {
        return str_contains($q, 'normalization') || str_contains($q, 'normalized') || str_contains($q, 'common security model') || str_contains($q, 'vendor-neutral');
    }

    private function mentionsVendorOrParser(string $q): bool
    {
        return str_contains($q, 'vendor') || str_contains($q, 'parser') || str_contains($q, 'detect');
    }

    private function mentionsTraining(string $q): bool
    {
        return str_contains($q, 'training') || str_contains($q, 'unknown command') || str_contains($q, 'learned mapping') || str_contains($q, 'quarantine');
    }

    private function mentionsCustomPolicy(string $q): bool
    {
        return str_contains($q, 'custom policy') || str_contains($q, 'custom policies') || str_contains($q, 'policy builder');
    }

    private function mentionsFrameworksControls(string $q): bool
    {
        return str_contains($q, 'framework') || str_contains($q, 'control') || str_contains($q, 'cis') || str_contains($q, 'nist') || str_contains($q, 'stig') || str_contains($q, 'iso 27001') || str_contains($q, 'iso27001');
    }

    private function mentionsUsersOrAdmin(string $q): bool
    {
        return str_contains($q, 'user') || str_contains($q, 'admin') || str_contains($q, 'permission') || str_contains($q, 'role') || str_contains($q, 'settings') || str_contains($q, 'audit log');
    }

    private function looksLikeCountOrListQuestion(string $q): bool
    {
        return str_contains($q, 'how many') || str_contains($q, 'list') || str_contains($q, 'show me') || str_contains($q, 'what are') || str_contains($q, 'which') || str_contains($q, 'latest');
    }

    private function looksLikeHelp(string $q): bool
    {
        return str_contains($q, 'what can you ask') || str_contains($q, 'what can you do') || str_contains($q, 'help') || str_contains($q, 'what do you know') || str_contains($q, 'all modules') || str_contains($q, 'all features');
    }
}
