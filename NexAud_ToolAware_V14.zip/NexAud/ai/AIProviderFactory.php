<?php require_once __DIR__.'/LocalLLMProvider.php'; class AIProviderFactory{public static function create():AIProviderInterface{return new LocalLLMProvider();}}
