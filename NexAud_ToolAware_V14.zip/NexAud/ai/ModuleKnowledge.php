<?php
declare(strict_types=1);

final class NexAudModuleKnowledge
{
    public static function modules(): array
    {
        return [
            'Devices' => [
                'url' => 'devices/index.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I add a new device in NexAud?','a'=>'Open Devices → Add Device, enter the device identity and platform details, then save. Verify vendor, model and OS before attaching a configuration.'],
                    ['type'=>'HOW','q'=>'How do I update a device after its OS or IP changes?','a'=>'Open the device record, edit the changed metadata, save it, then confirm future configurations are associated with the updated device information.'],
                    ['type'=>'HOW','q'=>'How do I check whether a device is ready for an audit?','a'=>'Confirm the device is active, the vendor/OS details are correct, and an intended configuration snapshot is available under Configurations.'],
                    ['type'=>'PROBLEM','q'=>'What should I do if the wrong vendor is selected for a device?','a'=>'Correct the device vendor metadata before auditing. A wrong vendor can cause the wrong parser to be used and can produce unreliable normalization or findings.'],
                    ['type'=>'PROBLEM','q'=>'Is there a problem if a device has missing OS version information?','a'=>'It can be a problem because parser and control interpretation may depend on platform/version details. Complete the metadata before relying on audit results.'],
                    ['type'=>'PROBLEM','q'=>'What happens if I attach a Cisco configuration to a Fortinet device?','a'=>'Treat it as a device/configuration association problem. Stop the audit, verify the device identity and vendor detection, and associate the configuration with the correct device.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate incorrect device inventory data?','a'=>'Edit the device record, correct the metadata, save it, and then re-check the associated configuration and audit context so later reports reference the correct identity.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a device that should no longer be audited?','a'=>'Update its status to the appropriate inactive state and make sure new audit work is not started against that device. Preserve historical evidence and reports.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a device/parser mismatch?','a'=>'Correct the device vendor/model/OS metadata, re-check vendor detection on the configuration, and rerun the parsing/normalization and audit workflow.'],
                    ['type'=>'REPORT','q'=>'How do I report the devices currently registered in NexAud?','a'=>'Open Reports and use the available report context for device inventory, or ask the Copilot to summarize the registered devices and point to the relevant page.'],
                    ['type'=>'REPORT','q'=>'How do I report a device configuration problem to an auditor?','a'=>'Include the device identity, affected configuration snapshot, SHA-256 hash, issue description and the related audit/finding reference.'],
                    ['type'=>'REPORT','q'=>'How do I include device ownership or location in an audit report?','a'=>'Keep owner/location metadata current on the device record, then generate the report from the related audit/configuration context so the identity information can be traced.'],
                ],
            ],
            'Configurations' => [
                'url' => 'configurations/index.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I upload a configuration for a device?','a'=>'Open Configurations, select the target device, choose the configuration file and submit it through the ingestion workflow.'],
                    ['type'=>'HOW','q'=>'How do I verify that the uploaded configuration is the file I intended to audit?','a'=>'Check the device association, upload metadata and SHA-256 hash, then confirm the vendor detection and parser results before starting compliance evaluation.'],
                    ['type'=>'HOW','q'=>'How do I compare two configuration versions?','a'=>'Open the comparison/analysis workflow, select the two configuration snapshots and review the changed commands or normalized security parameters.'],
                    ['type'=>'PROBLEM','q'=>'What should I do if SHA-256 for a configuration does not match the expected evidence?','a'=>'Treat the snapshot as a different configuration until proven otherwise. Verify the source file, recalculate/confirm the hash and avoid using the unexpected snapshot for evidence-based conclusions.'],
                    ['type'=>'PROBLEM','q'=>'Is there a problem if vendor detection returns Unknown?','a'=>'Yes, it means the configuration was not confidently matched to a known parser. Send the unknown structure to the AI Training/review workflow rather than assuming a vendor mapping.'],
                    ['type'=>'PROBLEM','q'=>'What should I do if many configuration commands are unrecognized?','a'=>'Review the parser output and unknown commands. Check vendor/OS metadata and use AI Training for reviewed mappings when the syntax is genuinely unsupported.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate an ingestion or parser error?','a'=>'Confirm the file is valid, the device metadata is correct, then rerun ingestion/parsing. For unsupported syntax, create a reviewed training mapping instead of silently forcing a mapping.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate configuration drift found between two snapshots?','a'=>'Use the comparison result to identify the changed security parameters, validate which state is intended, then route required changes through the finding/remediation/approval workflow.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate an incorrect configuration-to-device association?','a'=>'Correct the device association, verify the configuration identity and hash, then rerun the audit so findings are generated against the correct device.'],
                    ['type'=>'REPORT','q'=>'How do I report the exact configuration that was audited?','a'=>'Use the report context that references the device, configuration version and SHA-256 hash so the report identifies the precise snapshot analyzed.'],
                    ['type'=>'REPORT','q'=>'How do I report configuration drift?','a'=>'Generate or export the comparison/audit result with the two snapshot identities, changed settings and related findings.'],
                    ['type'=>'REPORT','q'=>'How do I report unknown configuration commands?','a'=>'Include the unknown command, parser context, confidence/review state and any approved training mapping so the recipient can see what was known versus still under review.'],
                ],
            ],
            'Audits & Analysis' => [
                'url' => 'analysis/index.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I start an audit in NexAud?','a'=>'Select the intended configuration and compliance scope, start the audit, and review the resulting control evaluations and findings.'],
                    ['type'=>'HOW','q'=>'How do I investigate why an audit produced a low compliance result?','a'=>'Open the audit results, inspect failed controls and compare each observed value with its expected value and evidence. The Copilot can explain the finding chain.'],
                    ['type'=>'HOW','q'=>'How do I compare audit results before and after a change?','a'=>'Use the original audit as the baseline, complete the controlled remediation workflow, then run the re-audit and compare the resulting control states.'],
                    ['type'=>'PROBLEM','q'=>'What should I do if an audit fails many controls unexpectedly?','a'=>'Do not assume the device is simply insecure. First verify configuration integrity, vendor detection, parser output, normalized parameters and the selected control scope.'],
                    ['type'=>'PROBLEM','q'=>'Is there a problem if the same control keeps failing after remediation?','a'=>'Yes, it means the resulting state did not satisfy the control or the remediation did not affect the evaluated parameter. Inspect observed/expected values and re-audit evidence.'],
                    ['type'=>'PROBLEM','q'=>'What if the audit percentage looks correct but a critical finding exists?','a'=>'Use the detailed finding and evidence rather than relying only on the percentage. A summary score does not replace control-level investigation.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate an audit with failed controls?','a'=>'Open the related findings, review AI reasoning and vendor-aware remediation, run What-If validation, obtain required approval, then re-audit.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a suspicious audit result?','a'=>'Validate the configuration hash and vendor/parser/normalization stages first. Fix the input or mapping issue, then rerun the audit so the new result is traceable.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate repeated failures across multiple audit runs?','a'=>'Identify the recurring control and normalized parameter, determine whether the underlying configuration change was actually applied, then use the finding/remediation workflow and verify through re-audit.'],
                    ['type'=>'REPORT','q'=>'How do I generate a report for an audit run?','a'=>'Open Reports, select the relevant audit/configuration context and generate the available report output.'],
                    ['type'=>'REPORT','q'=>'How do I report audit findings with evidence?','a'=>'Use the audit report together with finding details, observed/expected values, configuration hash and evidence references.'],
                    ['type'=>'REPORT','q'=>'How do I report an audit that requires further investigation?','a'=>'State the audit run, affected controls, uncertain/unknown mappings and required review actions rather than presenting unresolved results as confirmed failures.'],
                ],
            ],
            'Findings' => [
                'url' => 'findings/index.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I investigate a failed finding?','a'=>'Open the finding, review the control, observed value, expected value, evidence and severity, then use the AI Copilot to explain the failure and remediation path.'],
                    ['type'=>'HOW','q'=>'How do I find out whether a finding is caused by a real configuration problem?','a'=>'Trace the finding back to the normalized parameter and evidence, then verify the source configuration line or structured value. The What-If workflow can test a proposed correction safely.'],
                    ['type'=>'HOW','q'=>'How do I start remediation from a finding?','a'=>'Open the finding remediation workflow, review the proposed change, run What-If, then submit it for the required human approval step.'],
                    ['type'=>'PROBLEM','q'=>'Is a failed finding always a real security problem?','a'=>'Not automatically. Confirm the control scope, expected value, observed value, parser/normalization correctness and evidence. Unknown or ambiguous inputs should remain reviewable.'],
                    ['type'=>'PROBLEM','q'=>'What should I do if the finding evidence does not match the configuration?','a'=>'Stop remediation, recheck the configuration snapshot/hash and parsing/normalization path, then rerun the audit against the correct evidence.'],
                    ['type'=>'PROBLEM','q'=>'What if remediation is approved but the finding still fails?','a'=>'Treat the re-audit result as the source of truth for the resulting state. Investigate whether the remediation changed the wrong parameter or was not reflected in the audited configuration.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a failed control?','a'=>'Review the AI analysis, apply the vendor-specific remediation in the controlled workflow, run What-If, obtain approval and re-audit the resulting configuration.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a Telnet-related finding?','a'=>'Confirm the control requires secure remote access, review the observed transport setting, propose an SSH-only configuration in What-If, then obtain approval and re-audit before treating it as resolved.'],
                    ['type'=>'REMEDIATION','q'=>'How do I handle a finding caused by an unknown command?','a'=>'Do not invent a remediation. Route the command through AI Training/review, establish the normalized meaning with human approval, and then rerun the audit.'],
                    ['type'=>'REPORT','q'=>'How do I report a finding to a security reviewer?','a'=>'Include finding ID, device, control, severity, observed/expected values, evidence, remediation status and audit/re-audit references.'],
                    ['type'=>'REPORT','q'=>'How do I report that a finding was remediated successfully?','a'=>'Show the original finding, approved remediation, re-audit result and resulting status so the closure can be traced to evidence rather than only a status change.'],
                    ['type'=>'REPORT','q'=>'How do I report an unresolved or rejected remediation?','a'=>'Record the finding status, proposed remediation, reason for rejection or non-closure and the next required review action.'],
                ],
            ],
            'Frameworks' => [
                'url' => 'compliance/index.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I select a compliance framework for an audit?','a'=>'Use the Compliance/Frameworks area to identify the available framework and version, then use the framework controls that match the audit scope.'],
                    ['type'=>'HOW','q'=>'How do I check which controls belong to a framework?','a'=>'Open the framework and review its mapped controls and versions before starting the evaluation.'],
                    ['type'=>'HOW','q'=>'How do I use more than one compliance framework?','a'=>'Keep each framework evaluation identifiable by its own control set and report the results separately so requirements are not mixed.'],
                    ['type'=>'PROBLEM','q'=>'What should I do if the required framework or version is missing?','a'=>'Do not substitute an unrelated version silently. Verify the intended requirement and use the available control/custom-policy workflow to represent the required scope.'],
                    ['type'=>'PROBLEM','q'=>'Is there a problem if a control is not mapped to the selected framework?','a'=>'Yes, the audit may not cover the intended requirement. Verify the framework/control mapping before relying on the compliance result.'],
                    ['type'=>'PROBLEM','q'=>'What if two frameworks require different settings for the same security parameter?','a'=>'Treat them as separate control requirements and document the observed value against each requirement. Escalate genuine conflicts for policy review rather than hiding the difference.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a missing framework/control mapping?','a'=>'Confirm the requirement, add or correct the control mapping through the supported administrative workflow, then rerun the affected audit.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a framework version mismatch?','a'=>'Confirm the target version, align the audit scope to that version, and rerun the evaluation so the report references the correct requirement set.'],
                    ['type'=>'REMEDIATION','q'=>'How do I handle a control conflict between frameworks?','a'=>'Document the conflicting requirements, determine the organizational policy/compensating control, and make the decision explicit in the compliance evidence.'],
                    ['type'=>'REPORT','q'=>'How do I report compliance against a specific framework?','a'=>'Generate the report for the audit scope and include the framework/version, evaluated controls, findings and evidence.'],
                    ['type'=>'REPORT','q'=>'How do I report framework coverage?','a'=>'Summarize the controls evaluated versus the intended framework scope and call out unmapped or review-required controls.'],
                    ['type'=>'REPORT','q'=>'How do I report a framework exception?','a'=>'Record the affected control, reason, owner/approval information and compensating evidence, then include that status in the report context.'],
                ],
            ],
            'Controls' => [
                'url' => 'controls/index.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I inspect a control before using it in an audit?','a'=>'Open Controls and review its parameter, operator, expected value, severity and framework mapping before relying on its evaluation.'],
                    ['type'=>'HOW','q'=>'How do I create or edit a control?','a'=>'Use the supported Controls workflow, enter the normalized parameter and expected condition, then save and verify the resulting control definition.'],
                    ['type'=>'HOW','q'=>'How do I troubleshoot a control that gives an unexpected result?','a'=>'Check the observed normalized value, expected value, operator, parser/normalization output and control definition before changing the control itself.'],
                    ['type'=>'PROBLEM','q'=>'Is there a problem if a control uses the wrong normalized parameter?','a'=>'Yes. The control can evaluate the wrong security property. Correct the control definition and rerun the affected audit.'],
                    ['type'=>'PROBLEM','q'=>'What if the operator or expected value is incorrect?','a'=>'The control result can be systematically wrong. Review the requirement and control definition with the appropriate administrator before re-evaluating affected audits.'],
                    ['type'=>'PROBLEM','q'=>'What if the same control produces inconsistent results across vendors?','a'=>'Compare each vendor parser/normalization mapping for the same security concept. The control should evaluate the common normalized parameter, not vendor-specific text directly.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate an incorrectly defined control?','a'=>'Correct the control parameter/operator/expected value, document the reason, and rerun affected audits. Existing findings should be reviewed because the evaluation logic changed.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a control that depends on unsupported vendor syntax?','a'=>'Add or correct the vendor-to-normalized mapping through the parser/AI Training workflow, then rerun the control evaluation.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a control that is too broad?','a'=>'Refine the parameter and expected condition so the control measures a specific security requirement and does not produce ambiguous findings.'],
                    ['type'=>'REPORT','q'=>'How do I report the control logic behind a finding?','a'=>'Include the control ID/name, parameter, operator, expected value and the observed result that caused the finding.'],
                    ['type'=>'REPORT','q'=>'How do I report a control change?','a'=>'Record the before/after definition and the affected audit period, then regenerate impacted reports so reviewers know which control logic was used.'],
                    ['type'=>'REPORT','q'=>'How do I report controls that require review?','a'=>'List the review-required controls separately from deterministic pass/fail results and explain the unresolved evidence or mapping reason.'],
                ],
            ],
            'Custom Policies' => [
                'url' => 'compliance/custom-policies.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I create a custom policy in NexAud?','a'=>'Open Custom Policies → Policy Builder, define the policy and control conditions using the normalized model, then save and verify the new policy.'],
                    ['type'=>'HOW','q'=>'How do I update a custom policy after requirements change?','a'=>'Open the policy, edit the affected control conditions, save the new version/state and rerun the relevant audits.'],
                    ['type'=>'HOW','q'=>'How do I use a custom policy for a specific audit requirement?','a'=>'Define the requirement using normalized parameters and explicit expected conditions, then include that policy in the intended audit scope.'],
                    ['type'=>'PROBLEM','q'=>'Is there a problem if a custom policy evaluates the wrong parameter?','a'=>'Yes. The policy can produce misleading findings. Check the parameter mapping and control logic before trusting its results.'],
                    ['type'=>'PROBLEM','q'=>'What if a custom policy creates too many false findings?','a'=>'Review its conditions, operator and expected value, and compare them with the source evidence and intended requirement before changing the policy.'],
                    ['type'=>'PROBLEM','q'=>'What if a custom policy was changed after an audit was already run?','a'=>'Keep the old audit evidence intact, record the policy change and rerun the audit so the new results clearly correspond to the updated policy.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a bad custom policy definition?','a'=>'Correct the policy definition, preserve the change history/audit trail and rerun affected audits to produce results under the corrected rule.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate an unsupported custom policy condition?','a'=>'Express the requirement using a supported normalized parameter or add the required reviewed mapping first, then rerun the policy.'],
                    ['type'=>'REMEDIATION','q'=>'How do I handle a custom policy that conflicts with a framework control?','a'=>'Keep both requirements explicit, document the policy intent and use the compliance workflow to show where the custom requirement differs.'],
                    ['type'=>'REPORT','q'=>'How do I report results from a custom policy?','a'=>'Generate the report for the audit using that policy and include the policy identity, evaluated controls, findings and evidence.'],
                    ['type'=>'REPORT','q'=>'How do I report a custom policy change?','a'=>'Include the policy change details and the audits affected so readers can distinguish results generated before and after the change.'],
                    ['type'=>'REPORT','q'=>'How do I report a custom exception?','a'=>'Document the affected control, business/security reason, approval state and evidence, then include it with the audit/report context.'],
                ],
            ],
            'AI Copilot' => [
                'url' => 'ai/index.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I ask NexAud AI Copilot about a failed control?','a'=>'Include the finding number, device name or audit context and ask why the control failed. The Copilot can connect the request to observed/expected values and available evidence.'],
                    ['type'=>'HOW','q'=>'How do I ask the Copilot for remediation?','a'=>'Ask for the remediation for a specific finding and include the vendor/device when possible. The response should identify the controlled remediation path and validation step.'],
                    ['type'=>'HOW','q'=>'How do I use What-If through the AI Copilot?','a'=>'Ask the Copilot to explain or prepare the validation path for a proposed remediation; the actual simulation remains in the protected What-If workflow.'],
                    ['type'=>'PROBLEM','q'=>'What should I do if the Copilot cannot identify the device or finding?','a'=>'Provide the exact device name, finding number, configuration or audit reference. If records are missing, open the relevant module and verify the underlying data.'],
                    ['type'=>'PROBLEM','q'=>'Is there a problem if the Copilot recommends a command that does not match the vendor?','a'=>'Do not apply it blindly. Vendor-specific remediation must be checked against the parsed platform/configuration context and routed through What-If and approval.'],
                    ['type'=>'PROBLEM','q'=>'What if the Copilot is uncertain about an unknown configuration command?','a'=>'Treat the answer as review-required. Use AI Training to create a proposed normalized mapping and require human approval before future compliance decisions rely on it.'],
                    ['type'=>'REMEDIATION','q'=>'How does the Copilot support remediation?','a'=>'It explains why the control failed, summarizes the evidence, identifies the vendor-aware remediation path, describes validation and points the user to the approval/re-audit workflow.'],
                    ['type'=>'REMEDIATION','q'=>'How should the Copilot handle a potentially dangerous remediation?','a'=>'It should remain read-only, describe impact and side effects, use What-If validation and require human approval before any protected state transition.'],
                    ['type'=>'REMEDIATION','q'=>'How does the Copilot help after remediation?','a'=>'Use it to interpret the re-audit result, compare the original and resulting findings, and identify any controls that remain unresolved.'],
                    ['type'=>'REPORT','q'=>'How do I use the Copilot to prepare an audit report summary?','a'=>'Ask it to summarize the audit, failed controls, remediation state and evidence, then use the Reports module for the formal report output.'],
                    ['type'=>'REPORT','q'=>'How do I report an AI-assisted remediation decision?','a'=>'Keep the finding, AI explanation/recommendation, human approval decision, What-If result and re-audit outcome linked so the report shows the complete decision path.'],
                    ['type'=>'REPORT','q'=>'How do I report AI uncertainty?','a'=>'Explicitly state the confidence/review status, affected evidence and whether human approval or training is still required.'],
                ],
            ],
            'AI Training' => [
                'url' => 'training/index.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I review an unknown configuration command?','a'=>'Open AI Training, inspect the unknown structure and proposed mapping, compare it with the vendor context, then approve or reject it through the review workflow.'],
                    ['type'=>'HOW','q'=>'How do I approve a training mapping?','a'=>'Review the proposed normalized meaning, evidence and confidence, then use the protected approval action if the mapping is supported.'],
                    ['type'=>'HOW','q'=>'How do I see whether an unknown command is still pending review?','a'=>'Open AI Training and review the pending mapping/status list for unresolved items.'],
                    ['type'=>'PROBLEM','q'=>'Is there a problem if an unknown command is mapped automatically without review?','a'=>'Yes. An uncertain mapping can change compliance outcomes. NexAud should keep uncertain interpretations reviewable instead of treating them as verified facts.'],
                    ['type'=>'PROBLEM','q'=>'What if the proposed training mapping is wrong?','a'=>'Reject it and correct the mapping rather than allowing the incorrect interpretation to become reusable audit knowledge.'],
                    ['type'=>'PROBLEM','q'=>'What if many unknown commands appear for one vendor?','a'=>'Check the vendor/OS identification and parser coverage first. If the syntax is genuinely unsupported, create reviewed mappings systematically.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate an unknown-command problem?','a'=>'Validate the command meaning, create a normalized mapping with evidence/confidence, obtain human approval, then rerun normalization and affected audits.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a bad training mapping already used in audits?','a'=>'Disable/reject or correct the mapping, identify affected audits, and rerun those audits so prior conclusions are not silently treated as valid.'],
                    ['type'=>'REMEDIATION','q'=>'How do I improve future recognition of a new vendor syntax?','a'=>'Use approved training mappings that connect the observed structure to the common security model, then reuse them only when the context matches.'],
                    ['type'=>'REPORT','q'=>'How do I report unknown-command coverage?','a'=>'Report the number and nature of unknown structures, their review status and approved mappings so the audit coverage is transparent.'],
                    ['type'=>'REPORT','q'=>'How do I report a training decision?','a'=>'Include the observed structure, proposed mapping, confidence, reviewer/approval state and affected audit scope.'],
                    ['type'=>'REPORT','q'=>'How do I report a rejected training mapping?','a'=>'Record the rejected interpretation, reason for rejection and any replacement mapping or follow-up action.'],
                ],
            ],
            'Evidence Ledger' => [
                'url' => 'evidence/index.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I verify the Evidence Ledger?','a'=>'Open Evidence Ledger and use Verify Chain to check sequence links, previous hashes and recomputed block hashes.'],
                    ['type'=>'HOW','q'=>'How do I trace an audit event in the Evidence Ledger?','a'=>'Search or inspect the ledger history for the event type and related reference, then follow the linked audit/finding/report context.'],
                    ['type'=>'HOW','q'=>'How do I use evidence history when closing a finding?','a'=>'Verify the relevant lifecycle events and retain the chain/evidence references alongside the finding and re-audit result.'],
                    ['type'=>'PROBLEM','q'=>'Is there a problem if Verify Chain reports a hash mismatch?','a'=>'Yes. Treat the affected chain as requiring investigation. Do not present the ledger as verified until the inconsistency is understood and resolved through the supported repair process.'],
                    ['type'=>'PROBLEM','q'=>'What if a report has no matching evidence event?','a'=>'Check whether the relevant workflow action was recorded, verify the audit/report identifiers and investigate the missing lifecycle event before claiming a complete audit trail.'],
                    ['type'=>'PROBLEM','q'=>'What if ledger entries appear out of order?','a'=>'Inspect sequence numbers and previous-hash links. Ordering and linkage must be internally consistent for verification to succeed.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate an Evidence Ledger verification failure?','a'=>'Capture the verification result, inspect the affected block/sequence and use the supported repair workflow only after understanding the integrity issue.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate missing evidence for a remediation action?','a'=>'Verify whether the action actually occurred in the supported workflow, restore the appropriate evidence record if the application provides that capability, and rerun verification.'],
                    ['type'=>'REMEDIATION','q'=>'How do I handle an evidence inconsistency discovered after a report was issued?','a'=>'Flag the report for review, preserve the original report/evidence references and generate an updated report only after the evidence issue is resolved and re-verified.'],
                    ['type'=>'REPORT','q'=>'How do I report that the Evidence Ledger is valid?','a'=>'Run Verify Chain and include the verification outcome, relevant chain context and report/audit reference.'],
                    ['type'=>'REPORT','q'=>'How do I report an evidence integrity problem?','a'=>'Include the affected block/sequence, verification error, related audit/report reference and current remediation/review status.'],
                    ['type'=>'REPORT','q'=>'How do I include evidence history in a compliance report?','a'=>'Generate the report from the audit context and include the evidence/ledger references that connect configuration, findings, remediation and re-audit events.'],
                ],
            ],
            'Reports' => [
                'url' => 'reports/index.php',
                'intro' => 'Action-oriented questions for this NexAud module: workflow, problems, remediation and reporting.',
                'questions' => [
                    ['type'=>'HOW','q'=>'How do I generate a report for the latest audit?','a'=>'Open Reports, select the relevant audit/configuration context and use the available generation/export action.'],
                    ['type'=>'HOW','q'=>'How do I generate a report for a specific device or finding?','a'=>'Use the relevant device/audit/finding context when selecting the report inputs, then generate the report for that scope.'],
                    ['type'=>'HOW','q'=>'How do I create a report that includes remediation and re-audit results?','a'=>'Generate the report from the completed audit context so the lifecycle includes findings, remediation state and the resulting re-audit outcome.'],
                    ['type'=>'PROBLEM','q'=>'Is there a problem if a report is missing findings or remediation status?','a'=>'Yes. Check that the report is tied to the correct audit/configuration and that the underlying finding/remediation records exist before issuing the report.'],
                    ['type'=>'PROBLEM','q'=>'What if the report shows a different configuration hash than the audited snapshot?','a'=>'Treat it as an evidence/report mismatch. Verify the source configuration and report context before distributing the report.'],
                    ['type'=>'PROBLEM','q'=>'What if PDF generation is unavailable?','a'=>'Use the available print-ready/export path in the environment and record the limitation rather than claiming a PDF was generated when it was not.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate an incomplete report?','a'=>'Correct the missing underlying audit/findings/evidence data, rerun the report generation and verify the report contents against the source records.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a wrong device or audit in a report?','a'=>'Select the correct audit/configuration context, regenerate the report and verify device name, configuration hash, findings and evidence before sharing it.'],
                    ['type'=>'REMEDIATION','q'=>'How do I remediate a report that omits evidence verification?','a'=>'Run ledger verification first and regenerate the report from the context that includes the verification result.'],
                    ['type'=>'REPORT','q'=>'How do I report a completed compliance assessment?','a'=>'Use the generated report to show scope, framework, evaluated controls, findings, remediation status, re-audit result and evidence references.'],
                    ['type'=>'REPORT','q'=>'How do I report unresolved risks separately from closed findings?','a'=>'Ensure the report distinguishes open/review-required findings from findings that were verified closed by re-audit.'],
                    ['type'=>'REPORT','q'=>'How do I prepare a mentor/demo report for NexAud?','a'=>'Use a traceable example showing configuration hash, vendor detection, compliance failure, AI remediation, What-If, approval, re-audit, ledger verification and final report output.'],
                ],
            ],
        ];
    }

    public static function allQuestions(): array
    {
        $out = [];
        foreach (self::modules() as $module => $data) {
            foreach ($data['questions'] as $item) {
                $out[] = ['module'=>$module, 'type'=>$item['type'] ?? 'HOW', 'question'=>$item['q'], 'answer'=>$item['a'], 'url'=>$data['url']];
            }
        }
        return $out;
    }
}
