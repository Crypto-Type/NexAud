<?php class PromptGuard{public static function allowed(string $q):bool{return trim($q)!=='';}}
