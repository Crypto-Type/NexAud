<?php interface AIProviderInterface{public function name():string;public function generate(string $prompt,array $context=[]):string;}
