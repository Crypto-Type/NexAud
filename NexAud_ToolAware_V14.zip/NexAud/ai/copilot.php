<?php

declare(strict_types=1);

require_once __DIR__ . '/CopilotService.php';

final class NexAudCopilot
{
    private NexAudCopilotService $service;

    public function __construct(?NexAudCopilotService $service = null)
    {
        $this->service = $service ?? new NexAudCopilotService();
    }

    public function ask(string $question): string
    {
        $result = $this->service->ask($question);
        return (string)$result['answer'];
    }
}
