<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
requirePermission('ai.use');
require_once __DIR__ . '/CopilotService.php';
require_once __DIR__ . '/BasicKnowledge.php';
require_once __DIR__ . '/ModuleKnowledge.php';

$q = '';
$result = null;
$started = microtime(true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) render_error(403);
    $q = trim((string)($_POST['question'] ?? ''));
    $service = new NexAudCopilotService();
    $result = $service->ask($q);
    $latency = (int)round((microtime(true) - $started) * 1000);
    try {
        getDB()->prepare('INSERT INTO ai_query_log(user_id,action,question,provider,success,latency_ms,created_at) VALUES(?,?,?,?,?,?,NOW())')
            ->execute([current_user_id(), 'COPILOT_QUESTION', $q, $result['mode'] ?? 'NexAud Tool-Aware Copilot', 1, $latency]);
    } catch (Throwable $e) {
        audit_log(current_user_id(), 'AI_QUERY', 'ai', null, ['question' => $q]);
    }
}

layout_header('AI Copilot', 'ai');
?>
<div class="page-head">
    <div>
        <h1 class="page-title">AI Copilot</h1>
        <p class="page-sub">Ask questions about the NexAud tool and its live audit data.</p>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="callout" style="margin-bottom:14px">
            <strong>Tool-aware:</strong> Ask about Devices, Configurations, Audits, Findings, Frameworks, Controls, Custom Policies, AI Training, Evidence Ledger, Reports, Users, Settings or Audit Logs. For a specific record, include its number or device name.
        </div>
        <form method="post">
            <div class="field">
                <label for="question">Your question</label>
                <textarea id="question" name="question" required placeholder="Ask a basic security question or a question about your NexAud data..."><?=e($q)?></textarea>
            </div>
            <?=csrf_field()?>
            <button class="btn btn-primary" type="submit">Ask Copilot</button>
        </form>

        <div style="margin-top:20px">
            <div class="small muted" style="margin-bottom:8px">NexAud action questions — built around real work, problems, remediation and reporting</div>
            <div class="callout" style="margin-bottom:14px">
                <strong>Ask by action:</strong> use <b>How</b> to complete a task, <b>Problem</b> when something goes wrong, <b>Remediation</b> to fix the issue, or <b>Report</b> to document the result.
            </div>
            <div class="actions" style="margin-bottom:14px">
                <button type="button" class="btn btn-primary question-filter" data-type="ALL" onclick="filterQuestionType('ALL')">All</button>
                <button type="button" class="btn question-filter" data-type="HOW" onclick="filterQuestionType('HOW')">How</button>
                <button type="button" class="btn question-filter" data-type="PROBLEM" onclick="filterQuestionType('PROBLEM')">Problem</button>
                <button type="button" class="btn question-filter" data-type="REMEDIATION" onclick="filterQuestionType('REMEDIATION')">Remediation</button>
                <button type="button" class="btn question-filter" data-type="REPORT" onclick="filterQuestionType('REPORT')">Report</button>
            </div>
            <div style="margin-bottom:14px">
                <input id="moduleSearch" class="input" type="search" placeholder="Search a device problem, configuration issue, remediation, report, audit failure..." oninput="filterModuleQuestions()" style="max-width:760px">
            </div>
            <div id="moduleQuestionCatalog">
                <?php foreach (NexAudModuleKnowledge::modules() as $moduleName => $module): ?>
                    <?php $counts = ['HOW'=>0,'PROBLEM'=>0,'REMEDIATION'=>0,'REPORT'=>0]; foreach ($module['questions'] as $item) { $counts[$item['type'] ?? 'HOW'] = ($counts[$item['type'] ?? 'HOW'] ?? 0) + 1; } ?>
                    <details class="card module-question-group" data-module-search="<?=e(strtolower($moduleName.' '.$module['intro']))?>" style="margin:0 0 12px 0">
                        <summary style="cursor:pointer;padding:14px;font-weight:700">
                            <?=e($moduleName)?>
                            <span class="muted" style="font-weight:400">— <?=e($module['intro'])?></span>
                            <span class="pill" style="float:right">H <?=$counts['HOW']?> · P <?=$counts['PROBLEM']?> · R <?=$counts['REMEDIATION']?> · Report <?=$counts['REPORT']?></span>
                        </summary>
                        <div class="card-body" style="padding-top:12px">
                            <?php foreach ($module['questions'] as $item): ?>
                                <div class="module-question-row" data-type="<?=e($item['type'] ?? 'HOW')?>" data-search="<?=e(strtolower($moduleName.' '.($item['type'] ?? '').' '.$item['q']))?>" style="display:flex;gap:10px;align-items:flex-start;margin:0 0 9px 0">
                                    <span class="pill" style="min-width:94px;text-align:center"><?=e($item['type'] ?? 'HOW')?></span>
                                    <button type="button" class="btn module-question" style="text-align:left;flex:1" onclick="askQuick(<?=json_encode($item['q'])?>)"><?=e($item['q'])?></button>
                                </div>
                            <?php endforeach; ?>
                            <div style="margin-top:10px"><a class="btn" href="<?=e(url($module['url']))?>">Open <?=e($moduleName)?></a></div>
                        </div>
                    </details>
                <?php endforeach; ?>
            </div>

            <div class="small muted" style="margin:18px 0 8px">Common audit scenarios</div>
            <div class="actions">
                <?php foreach ([
                    'Why did my latest compliance control fail?',
                    'How do I get the remediation for finding #1?',
                    'Is this failed finding a real configuration problem?',
                    'What should I check when vendor detection returns Unknown?',
                    'How do I validate a proposed remediation with What-If?',
                    'What should I do if re-audit still fails after remediation?',
                    'How do I verify the Evidence Ledger after an audit?',
                    'How do I generate a report with findings, remediation and re-audit?',
                    'How do I report an unresolved finding?',
                    'How do I report an unknown command and its review status?'
                ] as $example): ?>
                    <button type="button" class="btn" style="margin:0 8px 8px 0" onclick="askQuick(<?=json_encode($example)?>)"><?=e($example)?></button>
                <?php endforeach; ?>
            </div>
        </div>
        <script>
        let activeQuestionType = 'ALL';
        function askQuick(question){
            const box = document.getElementById('question');
            box.value = question;
            box.form.submit();
        }
        function filterQuestionType(type){
            activeQuestionType = type;
            document.querySelectorAll('.question-filter').forEach(btn=>{
                const on = (btn.dataset.type||'ALL') === type;
                btn.classList.toggle('btn-primary', on);
            });
            filterModuleQuestions();
        }
        function filterModuleQuestions(){
            const q=(document.getElementById('moduleSearch').value||'').toLowerCase().trim();
            document.querySelectorAll('.module-question-group').forEach(group=>{
                const groupHit=!q || (group.dataset.moduleSearch||'').includes(q);
                let visible=0;
                group.querySelectorAll('.module-question-row').forEach(row=>{
                    const typeHit=activeQuestionType==='ALL' || (row.dataset.type||'')===activeQuestionType;
                    const textHit=!q || (row.dataset.search||'').includes(q);
                    const hit=typeHit && textHit;
                    row.style.display=hit?'flex':'none';
                    if(hit) visible++;
                });
                group.style.display=(groupHit || visible>0)?'block':'none';
                if(q && visible>0) group.open=true;
            });
        }
        </script>
    </div>
</div>

<?php if ($result): ?>
    <div class="card" style="margin-top:16px">
        <div class="card-head">Copilot Answer</div>
        <div class="card-body">
            <div class="callout"><?=e($result['answer'] ?? '')?></div>

            <?php if (!empty($result['links'])): ?>
                <div style="margin-top:16px">
                    <div class="small muted" style="margin-bottom:7px">Related NexAud pages</div>
                    <div class="actions">
                        <?php foreach ($result['links'] as $link): ?>
                            <a class="btn" href="<?=e($link['url'])?>"><?=e($link['label'])?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($result['sources'])): ?>
                <div style="margin-top:16px">
                    <div class="small muted">Data/context used</div>
                    <div class="pill" style="display:inline-block;margin-top:6px"><?=e(implode(' · ', $result['sources']))?></div>
                </div>
            <?php endif; ?>

            <?php if (!empty($result['data'])): ?>
                <details style="margin-top:16px">
                    <summary>Show retrieved context</summary>
                    <pre class="mono codebox" style="margin-top:10px;min-height:100px"><?=e(json_encode($result['data'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES))?></pre>
                </details>
            <?php endif; ?>

            <?php if (!empty($result['suggestions'])): ?>
                <div style="margin-top:16px">
                    <div class="small muted" style="margin-bottom:7px">Try asking</div>
                    <?php foreach ($result['suggestions'] as $suggestion): ?>
                        <span class="pill" style="display:inline-block;margin:0 6px 6px 0"><?=e($suggestion)?></span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
<?php layout_footer(); ?>
