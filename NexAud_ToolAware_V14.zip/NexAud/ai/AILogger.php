<?php require_once __DIR__.'/../includes/bootstrap.php'; class AILogger{public static function log(string $action,array $meta=[]):void{audit_log(current_user_id(),$action,'ai',null,$meta);}}
