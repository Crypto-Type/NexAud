<?php
declare(strict_types=1);
require_once __DIR__.'/includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

$checks = [
    'application' => 'ok',
    'php_version' => PHP_VERSION,
    'pdo_mysql' => extension_loaded('pdo_mysql'),
    'database' => 'not_checked',
    'missing_tables' => [],
    'status' => 'setup_required',
];

if (!extension_loaded('pdo_mysql')) {
    $checks['message'] = 'PDO MySQL driver is not enabled in this PHP runtime. Enable pdo_mysql in XAMPP before using the MySQL database.';
    echo json_encode($checks, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $pdo = getDB();
    $checks['database'] = 'ok';
    $required = [
        'users','roles','permissions','role_permissions','devices','configurations',
        'normalized_configurations','frameworks','controls','findings','evidence_ledger',
        'ai_unknown_commands','ai_suggestions','ai_mappings','ai_query_log','ai_reports'
    ];
    $missing = [];
    foreach ($required as $table) {
        try {
            $pdo->query('SELECT 1 FROM `'.$table.'` LIMIT 1');
        } catch (Throwable $e) {
            $missing[] = $table;
        }
    }
    $checks['missing_tables'] = $missing;
    $checks['users'] = (int)db_value('SELECT COUNT(*) FROM users');
    $checks['devices'] = (int)db_value('SELECT COUNT(*) FROM devices');
    $checks['frameworks'] = (int)db_value('SELECT COUNT(*) FROM frameworks');
    $checks['status'] = empty($missing) ? 'ready' : 'incomplete';
    if ($missing) {
        $checks['message'] = 'Database connected, but the schema is incomplete. Import database/install.sql.';
    }
} catch (Throwable $e) {
    http_response_code(200);
    $checks['database'] = 'error';
    $checks['status'] = 'database_error';
    $checks['message'] = 'Could not connect to the NexAud database. Confirm MySQL is running and DB settings point to nexaud.';
}

echo json_encode($checks, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
