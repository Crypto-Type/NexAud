<?php require_once __DIR__.'/../includes/bootstrap.php'; destroy_session(); redirect_to('login.php');
