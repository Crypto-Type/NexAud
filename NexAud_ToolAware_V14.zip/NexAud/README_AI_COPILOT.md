# NexAud V13 - Action-Oriented AI Copilot

This version changes the Copilot question experience from definition-style questions to operational questions based on the NexAud navigation and audit lifecycle.

## Question model
Each supported NexAud module has 12 curated questions split evenly into:
- HOW: how to perform a task
- PROBLEM: what to do when something is wrong or whether a condition creates an audit problem
- REMEDIATION: how to fix the issue and validate the change
- REPORT: how to document/export the result for audit evidence

## Modules covered
Devices
Configurations
Audits & Analysis
Findings
Frameworks
Controls
Custom Policies
AI Copilot
AI Training
Evidence Ledger
Reports

Total: 132 action-oriented module questions (33 in each category).

## Copilot behavior
Curated module questions are matched before generic keyword handlers so that clicking a question in the Copilot returns the intended module-specific answer. Finding numbers still route to live finding data first.

The Copilot remains read-only with respect to live network configuration changes. Remediation follows What-If, approval and re-audit workflows.
