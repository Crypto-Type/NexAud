<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/ReportBuilder.php';
require_once __DIR__.'/PdfRenderer.php';
requirePermission('reports.generate');
$id=(int)($_GET['configuration_id']??0); if(!$id)render_error(422);
$report=(new ReportBuilder(getDB()))->build($id);
$outDir=__DIR__.'/generated'; if(!is_dir($outDir))mkdir($outDir,0770,true);
$rr=(new PdfRenderer())->render($report,$outDir);
$hash=is_file($rr['path'])?hash_file('sha256',$rr['path']):null;
getDB()->prepare('INSERT INTO report_runs(configuration_id,audit_run_id,format,file_path,report_hash,generated_by) VALUES(?,?,?,?,?,?)')
 ->execute([$id,$report['audit']['audit_run_id']??null,$rr['format']==='pdf'?'PDF':'HTML',str_replace(NEXAUD_ROOT.DIRECTORY_SEPARATOR,'',$rr['path']),$hash,current_user()['username']??'SYSTEM']);
if($hash){
 try{(new EvidenceLedger(getDB()))->append('REPORT_GENERATED',['configuration_id'=>$id,'audit_run_id'=>$report['audit']['audit_run_id']??null,'format'=>$rr['format'],'report_hash'=>$hash],$report['configuration']['sha256_hash']??null,(string)$report['configuration']['device_id'],(string)$id,null,current_user()['username']??'SYSTEM');}catch(Throwable $e){error_log('[NexAud ledger] '.$e->getMessage());}
}
if(strtolower($rr['format'])==='pdf'){
 header('Content-Type: application/pdf'); header('Content-Disposition: attachment; filename="nexaud_report_'.$id.'.pdf"'); readfile($rr['path']); exit;
}
header('Content-Type: text/html; charset=utf-8'); readfile($rr['path']); exit;
