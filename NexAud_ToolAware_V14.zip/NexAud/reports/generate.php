<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/../compliance/EvidenceLedger.php';
require_once __DIR__.'/ReportBuilder.php';
requirePermission('reports.generate');
$id=(int)($_GET['configuration_id']??0); $c=config_get($id); if(!$c)render_error(404);
$builder=new ReportBuilder(getDB()); $report=$builder->build($id); $audit=$report['audit']??null;
$by=current_user()['username']??'SYSTEM';
try{
  $ledger=new EvidenceLedger(getDB());$ledger->ensureGenesis($by);$ledger->append('REPORT_GENERATED',['configuration_id'=>$id,'audit_run_id'=>$audit['audit_run_id']??null,'report_type'=>'compliance','generated_by'=>$by],$c['sha256_hash'],(string)$c['device_id'],(string)$id,null,$by);
}catch(Throwable $e){error_log('[NexAud ledger] '.$e->getMessage());}
layout_header('Report · Configuration #'.$id,'reports');
$rows=$report['findings'];
?>
<div class="page-head"><div><h1 class="page-title">Compliance Report</h1><p class="page-sub"><?=e($report['device']['device_name']??'Device')?> · <?=e($c['detected_vendor']??'Unknown')?> · v<?=e($c['version'])?></p></div><div class="actions"><a class="btn btn-primary" href="<?=e(url('reports/pdf.php?configuration_id='.$id))?>">Generate Downloadable Report</a><button class="btn" onclick="window.print()">Print / Save PDF</button></div></div>
<div class="grid-4"><div class="metric"><div class="num"><?=e($report['stats']['total_findings'])?></div><div class="label">Evaluations</div></div><div class="metric"><div class="num"><?=e($report['stats']['pass'])?></div><div class="label">Passed</div></div><div class="metric"><div class="num"><?=e($report['stats']['fail'])?></div><div class="label">Failed</div></div><div class="metric"><div class="num"><?=e($report['stats']['compliance_rate'])?>%</div><div class="label">Compliance</div></div></div>
<div class="grid-2" style="margin-top:16px"><div class="card"><div class="card-head">Configuration Evidence</div><div class="card-body"><table><tr><th>SHA-256</th><td class="mono"><?=e($c['sha256_hash'])?></td></tr><tr><th>Audit Run</th><td><?=e($audit['audit_run_id']??'—')?></td></tr><tr><th>Audit Status</th><td><?=e($audit['status']??'—')?></td></tr><tr><th>Generated</th><td><?=e($report['generated_at'])?></td></tr></table></div></div><div class="card"><div class="card-head">Evidence Integrity</div><div class="card-body"><p><strong><?=e($report['ledger_verify']['result'])?></strong> · <?=e($report['ledger_verify']['blocks_checked'])?> block(s) checked.</p><?php foreach(array_slice($report['ledger_verify']['violations']??[],0,3) as $v): ?><p class="small"><?=e($v)?></p><?php endforeach; ?><p class="muted">The ledger stores hashes and audit metadata for the lifecycle.</p></div></div></div>
<div class="card" style="margin-top:16px"><div class="card-head">Detailed Findings</div><div class="card-body table-wrap"><table><tr><th>Control</th><th>Severity</th><th>Status</th><th>Actual</th><th>Expected</th><th>Remediation</th></tr><?php foreach($rows as $r): ?><tr><td><?=e($r['control_code'])?><div class="small muted"><?=e($r['title'])?></div></td><td><?=severity_badge($r['severity'])?></td><td><?=status_badge($r['status'])?></td><td><?=e($r['actual_value'])?></td><td><?=e($r['expected_value'])?></td><td><?=e($r['remediation'])?></td></tr><?php endforeach; ?></table></div></div>
<?php if($report['remediations']): ?><div class="card" style="margin-top:16px"><div class="card-head">Remediation Lifecycle</div><div class="card-body table-wrap"><table><tr><th>Request</th><th>Finding</th><th>Status</th><th>Created</th><th>Approved</th><th>Re-Audit</th></tr><?php foreach($report['remediations'] as $rr): ?><tr><td>#<?=e($rr['remediation_request_id'])?></td><td>#<?=e($rr['finding_id'])?></td><td><?=e($rr['status'])?></td><td><?=e($rr['created_by'])?></td><td><?=e($rr['approved_by']??'—')?></td><td><?=e($rr['re_audit_run_id']??'—')?></td></tr><?php endforeach; ?></table></div></div><?php endif; ?>
<?php layout_footer(); ?>
