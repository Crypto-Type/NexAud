<?php
/**
 * PdfRenderer
 * -----------
 * Renders a report array (from ReportBuilder::build()) to a file.
 *
 * PDF library policy: NexAud must not depend on a paid library. This
 * renderer uses TCPDF (open-source, MIT-compatible, pure PHP, no
 * external services) WHEN it is available via Composer
 * (vendor/autoload.php, package tecnickcom/tcpdf). If TCPDF is not
 * installed, it automatically falls back to generating a clean,
 * print-ready HTML report (the browser's own "Print to PDF" produces
 * an equivalent PDF with zero extra dependencies) so report
 * generation never hard-fails just because a library isn't installed
 * yet.
 *
 * To install TCPDF for real PDF output:
 *   composer require tecnickcom/tcpdf
 */
class PdfRenderer
{
    /** @return array{path:string, format:string} */
    public function render(array $report, string $outputDir): array
    {
        if (!is_dir($outputDir)) {
            @mkdir($outputDir, 0770, true);
        }

        $vendorAutoload = __DIR__ . '/../vendor/autoload.php';
        if (is_file($vendorAutoload)) {
            require_once $vendorAutoload;
        }

        $slug = $report['report_type'] . '_' . date('Ymd_His') . '_' . substr(sha1((string) mt_rand()), 0, 6);

        if (class_exists('TCPDF')) {
            $path = $outputDir . '/' . $slug . '.pdf';
            $this->renderWithTcpdf($report, $path);
            return ['path' => $path, 'format' => 'pdf'];
        }

        $path = $outputDir . '/' . $slug . '.html';
        file_put_contents($path, $this->renderHtml($report));
        return ['path' => $path, 'format' => 'html'];
    }

    private function renderWithTcpdf(array $report, string $path): void
    {
        $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
        $pdf->SetCreator('NexAud');
        $pdf->SetTitle('NexAud ' . ucfirst($report['report_type']) . ' Report');
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(true);
        $pdf->SetMargins(15, 15, 15);
        $pdf->AddPage();
        $pdf->SetFont('helvetica', '', 10);
        $pdf->writeHTML($this->reportBodyHtml($report), true, false, true, false, '');
        $pdf->Output($path, 'F');
    }

    /** Fallback: a self-contained, print-ready HTML document (File > Print > Save as PDF). */
    public function renderHtml(array $report): string
    {
        $body = $this->reportBodyHtml($report);
        return "<!DOCTYPE html><html><head><meta charset='utf-8'>
        <title>NexAud " . htmlspecialchars(ucfirst($report['report_type'])) . " Report</title>
        <style>
          body{font-family:Arial,Helvetica,sans-serif;color:#111;margin:32px;font-size:13px}
          h1{font-size:22px;border-bottom:2px solid #222;padding-bottom:6px}
          h2{font-size:16px;margin-top:26px;color:#1a1a2e}
          table{width:100%;border-collapse:collapse;margin-top:8px}
          th,td{border:1px solid #ccc;padding:6px 8px;font-size:12px;text-align:left;vertical-align:top}
          th{background:#f2f3f7}
          .pass{color:#0a7a2f;font-weight:bold}.fail{color:#b3261e;font-weight:bold}.manual{color:#8a6d00;font-weight:bold}
          .ai-tag{display:inline-block;background:#eef1ff;color:#334;border:1px solid #ccd;border-radius:4px;padding:1px 6px;font-size:11px;margin-bottom:4px}
          .note{color:#666;font-size:11px}
          @media print { body{margin:12mm} }
        </style></head><body>{$body}</body></html>";
    }

    private function reportBodyHtml(array $report): string
    {
        $h = static fn($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        $stats = $report['stats'] ?? [];
        $audit = $report['audit'] ?? null;

        $out = '<h1>NexAud — ' . $h(ucfirst($report['report_type'])) . ' Report</h1>';
        $out .= '<p class="note">Generated ' . $h($report['generated_at'] ?? date('c')) . '</p>';

        $out .= '<h2>Audit Information</h2><table>';
        $out .= '<tr><th>Audit ID</th><td>' . $h($audit['id'] ?? '—') . '</td></tr>';
        $out .= '<tr><th>Started</th><td>' . $h($audit['started_at'] ?? '—') . '</td></tr>';
        $out .= '<tr><th>Completed</th><td>' . $h($audit['completed_at'] ?? '—') . '</td></tr>';
        $out .= '</table>';

        if (!empty($report['executive_summary']) && is_array($report['executive_summary'])) {
            $s = $report['executive_summary'];
            $out .= '<h2>Executive Summary</h2>';
            $out .= '<div class="ai-tag">AI-Assisted Explanation</div>';
            $out .= '<p>' . $h($s['executive_summary'] ?? '') . '</p>';
            if (!empty($s['top_risks'])) {
                $out .= '<p><strong>Top risks:</strong></p><ul>';
                foreach ((array) $s['top_risks'] as $r) $out .= '<li>' . $h($r) . '</li>';
                $out .= '</ul>';
            }
            if (!empty($s['recommended_next_steps'])) {
                $out .= '<p><strong>Recommended next steps:</strong></p><ul>';
                foreach ((array) $s['recommended_next_steps'] as $r) $out .= '<li>' . $h($r) . '</li>';
                $out .= '</ul>';
            }
        }

        $out .= '<h2>Overall Compliance</h2><table>';
        $out .= '<tr><th>Total findings</th><td>' . $h($stats['total_findings'] ?? 0) . '</td></tr>';
        $out .= '<tr><th>Pass</th><td class="pass">' . $h($stats['pass'] ?? 0) . '</td></tr>';
        $out .= '<tr><th>Fail</th><td class="fail">' . $h($stats['fail'] ?? 0) . '</td></tr>';
        $out .= '<tr><th>Manual review</th><td class="manual">' . $h($stats['manual_review'] ?? 0) . '</td></tr>';
        $out .= '<tr><th>Compliance rate</th><td>' . $h(($stats['compliance_rate'] ?? '—')) . '%</td></tr>';
        $out .= '</table>';

        if (!empty($stats['failed_by_severity'])) {
            $out .= '<h2>Risk Distribution (failed findings)</h2><table><tr><th>Severity</th><th>Count</th></tr>';
            foreach ($stats['failed_by_severity'] as $sev => $cnt) {
                $out .= '<tr><td>' . $h(ucfirst($sev)) . '</td><td>' . $h($cnt) . '</td></tr>';
            }
            $out .= '</table>';
        }

        $out .= '<h2>Findings</h2>';
        foreach (($report['findings'] ?? []) as $f) {
            $statusClass = strtolower($f['status'] ?? '') === 'pass' ? 'pass' : (strtolower($f['status'] ?? '') === 'fail' ? 'fail' : 'manual');
            $out .= '<table>';
            $out .= '<tr><th>Control ID</th><td>' . $h($f['control_id'] ?? '') . '</td><th>Severity</th><td>' . $h($f['severity'] ?? '') . '</td></tr>';
            $out .= '<tr><th>Title</th><td colspan="3">' . $h($f['title'] ?? '') . '</td></tr>';
            $out .= '<tr><th>Status</th><td class="' . $statusClass . '">' . $h($f['status'] ?? '') . '</td><th>Device</th><td>' . $h($f['device_name'] ?? '') . '</td></tr>';
            $out .= '<tr><th>Actual</th><td colspan="3">' . $h($f['actual'] ?? '') . '</td></tr>';
            $out .= '<tr><th>Expected</th><td colspan="3">' . $h($f['expected'] ?? '') . '</td></tr>';
            $out .= '<tr><th>Evidence SHA-256</th><td colspan="3"><code>' . $h($f['evidence_sha256'] ?? 'n/a') . '</code></td></tr>';

            if (!empty($f['ai_explanation']) && is_array($f['ai_explanation'])) {
                $ai = $f['ai_explanation'];
                $out .= '<tr><td colspan="4"><div class="ai-tag">AI-Assisted Explanation</div>';
                $out .= '<p><strong>Why it matters:</strong> ' . $h($ai['why_it_matters'] ?? '') . '</p>';
                $out .= '<p><strong>Potential impact:</strong> ' . $h($ai['potential_impact'] ?? '') . '</p>';
                $out .= '<p><strong>Remediation:</strong> ' . $h($ai['remediation_summary'] ?? '') . '</p>';
                if (!empty($ai['vendor_specific_remediation'])) {
                    $out .= '<p><strong>Vendor-specific remediation:</strong> ' . $h($ai['vendor_specific_remediation']) . '</p>';
                }
                if (isset($ai['confidence_evidence_sufficient']) && !$ai['confidence_evidence_sufficient']) {
                    $out .= '<p class="note">Note: the AI flagged the supplied evidence as insufficient for a fully confident explanation.</p>';
                }
                $out .= '</td></tr>';
            }
            $out .= '</table><br>';
        }

        if (!empty($report['remediations'])) { $out .= '<h2>Remediation Lifecycle</h2><table><tr><th>Request</th><th>Finding</th><th>Status</th><th>Approved By</th><th>Re-Audit</th></tr>'; foreach ($report['remediations'] as $rr) { $out .= '<tr><td>'.$h($rr['remediation_request_id']??'').'</td><td>'.$h($rr['finding_id']??'').'</td><td>'.$h($rr['status']??'').'</td><td>'.$h($rr['approved_by']??'—').'</td><td>'.$h($rr['re_audit_run_id']??'—').'</td></tr>'; } $out .= '</table>'; }

        $lv = $report['ledger_verify'] ?? []; $out .= '<h2>Evidence Integrity</h2><p class="note">Ledger verification result: '.$h($lv['result'] ?? '—').' ('.($h($lv['blocks_checked'] ?? 0)).' blocks checked).</p>';

        return $out;
    }
}
