<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/../devices/functions.php';
require_once __DIR__.'/../configurations/ingest.php';
require_once __DIR__.'/../compliance/EvidenceLedger.php';

final class ReportBuilder {
    public function __construct(private PDO $pdo){}
    public function build(int $configurationId): array {
        $c=db_one('SELECT * FROM configurations WHERE id=?',[$configurationId]);
        if(!$c) throw new RuntimeException('Configuration not found.');
        $d=device_get((int)$c['device_id']);
        $audit=db_one('SELECT * FROM audit_runs WHERE configuration_id=? AND status=\'COMPLETED\' ORDER BY audit_run_id DESC LIMIT 1',[$configurationId]);
        $rows=db_all('SELECT f.*,c.control_code,c.title,c.description FROM findings f JOIN controls c ON c.control_id=f.control_id WHERE f.configuration_id=? AND f.audit_run_id <=> ? ORDER BY FIELD(f.severity,\'CRITICAL\',\'HIGH\',\'MEDIUM\',\'LOW\',\'INFO\'),f.finding_id DESC',[$configurationId,$audit['audit_run_id']??null]);
        if(!$rows){$rows=db_all('SELECT f.*,c.control_code,c.title,c.description FROM findings f JOIN controls c ON c.control_id=f.control_id WHERE f.configuration_id=? ORDER BY f.finding_id DESC',[$configurationId]);}
        $stats=['total_findings'=>count($rows),'pass'=>0,'fail'=>0,'manual_review'=>0,'compliance_rate'=>0,'failed_by_severity'=>[]];
        foreach($rows as $row){
            if($row['status']==='PASS')$stats['pass']++; elseif($row['status']==='FAIL')$stats['fail']++; else $stats['manual_review']++;
            if($row['status']==='FAIL'){$sev=$row['severity'];$stats['failed_by_severity'][$sev]=($stats['failed_by_severity'][$sev]??0)+1;}
        }
        $stats['compliance_rate']=$audit['compliance_pct']??($stats['total_findings']?round(($stats['pass']/$stats['total_findings'])*100,2):0);
        $rem=[];
        foreach($rows as $row){$rr=db_one('SELECT * FROM remediation_requests WHERE finding_id=? ORDER BY remediation_request_id DESC LIMIT 1',[(int)$row['finding_id']]);if($rr)$rem[]=$rr;}
        $ledgerRows=db_all('SELECT * FROM evidence_ledger WHERE configuration_id=? OR finding_id IN (SELECT finding_id FROM findings WHERE configuration_id=?) ORDER BY sequence_number ASC',[$configurationId,$configurationId]);
        $ledgerVerify=(new EvidenceLedger($this->pdo))->verify();
        return [
            'report_type'=>'compliance', 'generated_at'=>date('c'), 'device'=>$d, 'configuration'=>$c, 'audit'=>$audit,
            'stats'=>$stats, 'findings'=>$rows, 'remediations'=>$rem, 'ledger'=>$ledgerRows, 'ledger_verify'=>$ledgerVerify,
        ];
    }
}
