<?php
declare(strict_types=1);
if (!defined('APP_NAME')) define('APP_NAME','NexAud');
if (!defined('APP_FULL_NAME')) define('APP_FULL_NAME','AI-Driven Multi-Vendor Network Security Compliance Auditor');
if (!defined('APP_VERSION')) define('APP_VERSION','1.5.0-ai-audit-brain-v9');
if (!defined('APP_ENV')) define('APP_ENV', getenv('NEXAUD_ENV') ?: 'development');
if (!defined('NEXAUD_ROOT')) define('NEXAUD_ROOT', dirname(__DIR__));
if (!defined('APP_TIMEZONE')) define('APP_TIMEZONE','Asia/Kolkata');
date_default_timezone_set(APP_TIMEZONE);
if (!defined('SESSION_NAME')) define('SESSION_NAME','nexaud_session');
if (!defined('SESSION_IDLE_MINUTES')) define('SESSION_IDLE_MINUTES',60);
if (!defined('UPLOAD_DIR')) define('UPLOAD_DIR',NEXAUD_ROOT.'/uploads');
if (!defined('UPLOAD_LIMIT_BYTES')) define('UPLOAD_LIMIT_BYTES',5*1024*1024);

function app_base_url(): string {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = str_replace('\\','/', $_SERVER['SCRIPT_NAME'] ?? '/');
    $marker = '/NexAud/';
    $pos = stripos($script, $marker);
    if ($pos !== false) return $scheme.'://'.$host.substr($script,0,$pos+strlen('/NexAud'));
    $dir = rtrim(str_replace('\\','/', dirname($script)), '/');
    foreach(['/admin','/ai','/api','/auth','/analysis','/compliance','/configurations','/controls','/devices','/evidence','/findings','/reports','/training','/normalization','/parsers','/includes','/config'] as $sub){
        if (substr($dir,-strlen($sub))===$sub){ $dir=substr($dir,0,-strlen($sub)); break; }
    }
    return $scheme.'://'.$host.$dir;
}
if (!defined('BASE_URL')) define('BASE_URL', app_base_url());
