<?php
declare(strict_types=1);
if (!defined('DB_HOST')) define('DB_HOST',getenv('NEXAUD_DB_HOST') ?: '127.0.0.1');
if (!defined('DB_PORT')) define('DB_PORT',getenv('NEXAUD_DB_PORT') ?: '3306');
if (!defined('DB_NAME')) define('DB_NAME',getenv('NEXAUD_DB_NAME') ?: 'nexaud');
if (!defined('DB_USER')) define('DB_USER',getenv('NEXAUD_DB_USER') ?: 'root');
if (!defined('DB_PASS')) define('DB_PASS',getenv('NEXAUD_DB_PASS') ?: '');
function getDB(): PDO {
    static $pdo;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME.';charset=utf8mb4';
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
        return $pdo;
    } catch (Throwable $e) {
        error_log('[NexAud DB] '.$e->getMessage());
        throw new RuntimeException('Database connection failed. Check MySQL/MariaDB and NexAud database settings.');
    }
}
