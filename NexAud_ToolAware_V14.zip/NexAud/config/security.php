<?php
declare(strict_types=1);
if (!defined('ROLE_ADMIN')) define('ROLE_ADMIN','ADMIN');
if (!defined('ROLE_AUDITOR')) define('ROLE_AUDITOR','AUDITOR');
if (!defined('ROLE_SECURITY_ENGINEER')) define('ROLE_SECURITY_ENGINEER','SECURITY_ENGINEER');
if (!defined('ROLE_VIEWER')) define('ROLE_VIEWER','VIEWER');
if (!defined('CSRF_TOKEN_KEY')) define('CSRF_TOKEN_KEY','nexaud_csrf');
if (!defined('CSRF_FORM_FIELD')) define('CSRF_FORM_FIELD','csrf_token');
if (!defined('LOGIN_MAX_ATTEMPTS')) define('LOGIN_MAX_ATTEMPTS',5);
if (!defined('LOGIN_WINDOW_MINUTES')) define('LOGIN_WINDOW_MINUTES',15);
if (!defined('PASSWORD_MIN_LENGTH')) define('PASSWORD_MIN_LENGTH',10);
const NEXAUD_PERMISSIONS = [
 'dashboard.view','devices.view','devices.manage','configurations.view','configurations.manage',
 'audits.view','audits.run','findings.view','findings.manage','compliance.view','compliance.manage',
 'controls.view','controls.manage','policies.view','policies.manage','ai.use','training.view','training.manage',
 'evidence.view','evidence.verify','reports.view','reports.generate','users.manage','settings.manage','audit_logs.view'
];
const NEXAUD_ROLE_DEFAULTS = [
 'ADMIN'=>NEXAUD_PERMISSIONS,
 'AUDITOR'=>['dashboard.view','audits.view','audits.run','configurations.view','compliance.view','compliance.manage','controls.view','findings.view','reports.view','reports.generate','evidence.view','evidence.verify'],
 'SECURITY_ENGINEER'=>['dashboard.view','devices.view','devices.manage','configurations.view','configurations.manage','audits.view','audits.run','findings.view','findings.manage','ai.use','training.view','training.manage','evidence.view'],
 'VIEWER'=>['dashboard.view','reports.view','compliance.view','findings.view']
];
