<?php
require_once __DIR__.'/../includes/bootstrap.php';
if (!function_exists('nexaud_db')) { function nexaud_db(): PDO { return getDB(); } }
if (!function_exists('nexaud_ai_db')) { function nexaud_ai_db(): PDO { return getDB(); } }
