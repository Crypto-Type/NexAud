# NexAud XAMPP 500-safe build

This build intentionally does not use `.htaccess` files. The application uses PHP route guards, explicit `index.php` entry points, and a root redirect so it remains compatible with a standard XAMPP Apache installation even when per-directory Apache overrides are restricted.

Install at `C:\\xampp\\htdocs\\NexAud` and open `http://localhost/NexAud/`.
