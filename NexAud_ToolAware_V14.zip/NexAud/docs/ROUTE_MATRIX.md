# Route matrix

The rebuilt project includes dedicated pages for dashboard, devices, configurations, normalization, audits, compliance, controls, findings, AI training, evidence, reports, AI Copilot and administration. Legacy paths that previously returned 404s now resolve to implemented pages or compatibility wrappers.
