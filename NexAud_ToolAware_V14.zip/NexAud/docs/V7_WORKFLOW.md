# NexAud V7 – Closed-Loop Workflow

## What is now wired

1. **Remediation request** is persisted for a finding.
2. **What-If** clones the normalized model in memory, changes only the target parameter to the control's expected value, and runs the real compliance evaluator against that simulated model.
3. **Human approval** is a real database state transition (`PENDING_APPROVAL -> APPROVED`) protected by CSRF and permissions.
4. **Safe execution** is explicitly simulated; no network device is connected or modified.
5. **Re-Audit** runs the compliance engine against the approved simulated post-remediation model and stores a new `audit_runs` record and findings linked to that run.
6. **Evidence Ledger** records configuration ingestion, audit start/completion, findings, What-If, remediation creation/approval/rejection, re-audit and report generation.
7. **Verify Chain** validates sequence, previous-hash linkage and each block hash.
8. **Reports** include the audit run, findings, remediation lifecycle and ledger verification status. `reports/pdf.php` produces a PDF when TCPDF is installed; otherwise it produces a print-ready HTML report.

## Important safety boundary

The demo never SSHs/Telnets into a device and never changes a live network device. "Apply" means applying the proposed value to an in-memory normalized security model for the purpose of re-evaluation.

## Existing database upgrade

For an existing NexAud database, import `database/upgrade_v7.sql` once into the `nexaud` database.

If block 0 is the only ledger record and Verify Chain reports a legacy hash mismatch, open `/evidence/repair.php` as an administrator and run the one-time repair. Do not use it on a multi-block chain.
