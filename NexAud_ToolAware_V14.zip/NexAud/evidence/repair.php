<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/EvidenceLedger.php';
requireRole(ROLE_ADMIN);
$ledger=new EvidenceLedger(getDB());
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf())render_error(403);
 $rows=$ledger->chain();
 if(count($rows)!==1 || ($rows[0]['event_type']??'')!=='GENESIS') render_error(422,'Repair not allowed','Legacy genesis repair is only allowed when the ledger contains exactly one GENESIS block.');
 $b=$rows[0];
 $ref=new ReflectionClass($ledger); $m=$ref->getMethod('hashBlock'); $m->setAccessible(true); $b['sequence_number']=(int)$b['sequence_number']; $b['block_hash']=$m->invoke($ledger,$b);
 getDB()->prepare('UPDATE evidence_ledger SET block_hash=? WHERE block_id=?')->execute([$b['block_hash'],(int)$rows[0]['block_id']]);
 audit_log(current_user_id(),'LEDGER_GENESIS_REPAIRED','evidence_ledger',(int)$rows[0]['block_id'],['reason'=>'Legacy hash canonicalization repair']);
 flash('success','Genesis hash repaired using the V7 canonicalization rules.');
 redirect_to('evidence/verify.php');
}
layout_header('Evidence Ledger Repair','evidence');
?><div class="page-head"><div><h1 class="page-title">Legacy Genesis Repair</h1><p class="page-sub">One-time migration helper for a pre-V7 ledger created with the older hash representation.</p></div></div><div class="card"><div class="card-body"><div class="callout">Use this only when Evidence Verification reports a mismatch at block 0 and the ledger contains exactly one GENESIS block. This does not repair a multi-block tampered chain.</div><form method="post" style="margin-top:14px"><?=csrf_field()?><button class="btn btn-primary">Repair Genesis Hash</button></form></div></div><?php layout_footer(); ?>
