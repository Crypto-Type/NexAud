<?php
declare(strict_types=1);
$autoload=__DIR__.'/../compliance/Canonicalizer.php';require_once $autoload;
final class LedgerHashProbe {
  private function hashBlock(array $b):string{
    $x=$b; unset($x['block_hash']);
    $x['sequence_number']=(int)($x['sequence_number']??0);
    if(array_key_exists('finding_id',$x)&&$x['finding_id']!==null&&$x['finding_id']!=='') $x['finding_id']=(int)$x['finding_id'];
    ksort($x); return Canonicalizer::canonicalHash($x);
  }
  public function run():void{
    $block=['sequence_number'=>0,'event_type'=>'GENESIS','device_id'=>null,'configuration_id'=>null,'finding_id'=>null,'config_hash'=>null,'evidence_hash'=>Canonicalizer::canonicalHash(['label'=>'NEXAUD-GENESIS','message'=>'NexAud evidence ledger initialized.']),'previous_block_hash'=>str_repeat('0',64),'timestamp'=>'2026-09-29 00:00:00.123456','created_by'=>'admin'];
    $typed=$block; $stored=$block; $stored['sequence_number']='0';
    $typedHash=$this->hashBlock($typed); $storedHash=$this->hashBlock($stored);
    if($typedHash!==$storedHash) throw new RuntimeException('Ledger DB-type normalization failed');
    echo "LEDGER HASH NORMALIZATION PASSED\n";
  }
}
(new LedgerHashProbe())->run();
