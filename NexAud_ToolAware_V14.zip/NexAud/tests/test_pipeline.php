<?php
/**
 * NexAud Module 2 - tests/test_pipeline.php
 *
 * Standalone smoke test for detectVendor() / parseConfiguration() /
 * normalizeConfiguration() / calculateConfigHash() against the sample
 * configs. Deliberately does NOT touch devices/bootstrap.php (no DB, no
 * auth) so it can run in plain `php` with zero setup, per the required
 * test procedure.
 *
 * Run: php tests/test_pipeline.php
 */

require_once __DIR__ . '/../parsers/parser.php';
require_once __DIR__ . '/../normalization/engine.php';

$samples = [
    'Cisco'     => __DIR__ . '/../sample_configs/cisco_sample.txt',
    'Fortinet'  => __DIR__ . '/../sample_configs/fortinet_sample.txt',
    'Palo Alto' => __DIR__ . '/../sample_configs/paloalto_sample.txt',
    'Unknown'   => __DIR__ . '/../sample_configs/unknown_sample.txt',
];

$failures = 0;

foreach ($samples as $label => $path) {
    echo str_repeat('=', 70) . "\n";
    echo "SAMPLE: {$label}  ({$path})\n";
    echo str_repeat('=', 70) . "\n";

    $raw = file_get_contents($path);
    $hash = calculateConfigHash($raw);
    echo "SHA-256: {$hash}\n";

    $detection = detectVendor($raw);
    echo "Detected vendor: {$detection['vendor']}  confidence: {$detection['confidence']}  device_type: {$detection['device_type']}\n";
    echo "Evidence: " . implode(' | ', $detection['detection_evidence']) . "\n";

    if ($label !== 'Unknown' && $detection['vendor'] !== $label) {
        echo "!! FAIL: expected vendor {$label}, detected {$detection['vendor']}\n";
        $failures++;
    }
    if ($label === 'Unknown' && $detection['vendor'] !== 'Unknown') {
        echo "!! FAIL: expected Unknown classification for the unsupported sample, got {$detection['vendor']}\n";
        $failures++;
    }

    $ir = parseConfiguration($raw, $label === 'Unknown' ? 'Unknown' : $detection['vendor']);
    $normalized = normalizeConfiguration($ir['vendor'], $ir);

    if ($ir['vendor'] === 'Unknown') {
        $report = $normalized['unknown_report'];
        echo "Unrecognized command count: " . count($report['unrecognized_commands']) . "\n";
        echo "Possible security categories: " . implode(', ', $report['possible_security_categories']) . "\n";
        echo "Candidate mappings found: " . count($report['candidate_mappings']) . "\n";
        if (count($report['candidate_mappings']) === 0) {
            echo "!! FAIL: expected at least some candidate mappings from keyword heuristics\n";
            $failures++;
        }
    } else {
        $flat = nscs_flatten($normalized['normalized']);
        echo "Normalized parameter count: " . count($flat) . "\n";
        // Spot-check a handful of parameters with their evidence.
        $sampleParams = array_slice($flat, 0, 6);
        foreach ($sampleParams as $p) {
            $val = is_bool($p['value']) ? ($p['value'] ? 'true' : 'false') : (is_scalar($p['value']) ? $p['value'] : json_encode($p['value']));
            echo "  - {$p['parameter']} = {$val}   [line {$p['source']['line']}: \"{$p['source']['raw']}\"]\n";
        }
        if (count($flat) === 0) {
            echo "!! FAIL: expected normalized parameters, got zero\n";
            $failures++;
        }
    }
    echo "\n";
}

echo str_repeat('=', 70) . "\n";
if ($failures === 0) {
    echo "ALL CHECKS PASSED\n";
    exit(0);
} else {
    echo "{$failures} CHECK(S) FAILED\n";
    exit(1);
}
