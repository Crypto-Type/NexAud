<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/../compliance/engine.php';
requirePermission('audits.run');
$id=(int)($_GET['configuration_id']??$_POST['configuration_id']??0);
if(!$id) render_error(422);
try{
    $results=run_compliance($id);
    persist_findings($id,$results);
    $run=db_one('SELECT audit_run_id FROM audit_runs WHERE configuration_id=? AND mode=\'BASELINE\' ORDER BY audit_run_id DESC LIMIT 1',[(string)$id]);
    flash('success','Audit completed. '.count($results).' control evaluations recorded.'.($run?' Audit run #'.$run['audit_run_id'].'.':''));
    redirect_to('analysis/results.php?configuration_id='.$id);
}catch(Throwable $e){
    flash('error',$e->getMessage());
    redirect_to('analysis/index.php');
}
