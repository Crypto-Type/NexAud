<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';

requirePermission('controls.manage');
require_once __DIR__.'/../compliance/EvidenceLedger.php';

$id = (int)($_GET['id'] ?? 0);
$editing = $id > 0;

$control = $editing
    ? db_one('SELECT c.*, f.name framework_name, f.version framework_version FROM controls c JOIN frameworks f ON f.framework_id=c.framework_id WHERE c.control_id=?', [$id])
    : null;

if ($editing && !$control) {
    render_error(404);
}

$customFrameworks = db_all("SELECT framework_id, name, version FROM frameworks WHERE framework_type='CUSTOM' ORDER BY name, version");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        render_error(403);
    }

    $title = trim((string)($_POST['title'] ?? ''));
    $description = trim((string)($_POST['description'] ?? ''));
    $category = trim((string)($_POST['category'] ?? ''));
    $severity = strtoupper(trim((string)($_POST['severity'] ?? 'MEDIUM')));
    $vendor = trim((string)($_POST['vendor'] ?? 'ANY')) ?: 'ANY';
    $deviceType = trim((string)($_POST['device_type'] ?? 'ANY')) ?: 'ANY';
    $parameter = trim((string)($_POST['parameter'] ?? ''));
    $operator = trim((string)($_POST['operator'] ?? 'equals'));
    $expected = trim((string)($_POST['expected_value'] ?? ''));
    $evidence = trim((string)($_POST['evidence_requirement'] ?? ''));
    $remediation = trim((string)($_POST['remediation'] ?? ''));

    $allowedSeverity = ['CRITICAL','HIGH','MEDIUM','LOW','INFO'];
    $allowedOperators = ['equals','not_equals','contains','not_contains','greater_than','less_than','exists','not_exists','enabled','disabled'];

    if ($title === '' || $parameter === '') {
        flash('error', 'Title and normalized parameter are required.');
        redirect_to('controls/edit.php'.($editing ? '?id='.$id : '?new=1'));
    }
    if (!in_array($severity, $allowedSeverity, true) || !in_array($operator, $allowedOperators, true)) {
        flash('error', 'Invalid severity or operator.');
        redirect_to('controls/edit.php'.($editing ? '?id='.$id : '?new=1'));
    }

    $pdo = getDB();

    if ($editing) {
        $stmt = $pdo->prepare('UPDATE controls SET title=?,description=?,category=?,severity=?,vendor=?,device_type=?,parameter=?,operator=?,expected_value=?,evidence_requirement=?,remediation=?,updated_at=NOW() WHERE control_id=?');
        $stmt->execute([$title,$description,$category,$severity,$vendor,$deviceType,$parameter,$operator,$expected,$evidence,$remediation,$id]);
        flash('success', 'Control updated successfully.');
        try{(new EvidenceLedger($pdo))->ensureGenesis(current_user()['username']??'SYSTEM');(new EvidenceLedger($pdo))->append('POLICY_UPDATED',['control_id'=>$id,'title'=>$title,'framework_id'=>(int)$control['framework_id']],null,null,null,null,current_user()['username']??'SYSTEM');}catch(Throwable $e){error_log('[NexAud ledger] '.$e->getMessage());}
        redirect_to('controls/view.php?id='.$id);
    }

    $frameworkId = (int)($_POST['framework_id'] ?? 0);
    $frameworkName = trim((string)($_POST['framework_name'] ?? ''));
    $frameworkVersion = trim((string)($_POST['framework_version'] ?? '1.0')) ?: '1.0';

    if ($frameworkId > 0) {
        $framework = db_one("SELECT framework_id FROM frameworks WHERE framework_id=? AND framework_type='CUSTOM'", [$frameworkId]);
        if (!$framework) {
            flash('error', 'Select a valid custom framework.');
            redirect_to('controls/edit.php?new=1');
        }
        $frameworkId = (int)$framework['framework_id'];
    } else {
        if ($frameworkName === '') {
            flash('error', 'Choose a custom framework or enter a new framework name.');
            redirect_to('controls/edit.php?new=1');
        }

        $framework = db_one('SELECT framework_id FROM frameworks WHERE name=? AND version=? LIMIT 1', [$frameworkName, $frameworkVersion]);
        if ($framework) {
            $frameworkId = (int)$framework['framework_id'];
        } else {
            $stmt = $pdo->prepare("INSERT INTO frameworks (name,description,version,organization,framework_type,status,created_by) VALUES (?,?,?,?, 'CUSTOM','ACTIVE',?)");
            $stmt->execute([$frameworkName,'Organization-defined security policy framework.',$frameworkVersion,'NexAud Custom Policy',current_user()['username'] ?? 'SYSTEM']);
            $frameworkId = (int)$pdo->lastInsertId();
        }
    }

    $controlCode = trim((string)($_POST['control_code'] ?? ''));
    if ($controlCode === '') {
        $controlCode = 'ORG-NET-'.str_pad((string)((int)db_value("SELECT COUNT(*) FROM controls WHERE framework_id=?",[$frameworkId])+1), 3, '0', STR_PAD_LEFT);
    }

    try {
        $stmt = $pdo->prepare('INSERT INTO controls (framework_id,control_code,title,description,category,severity,vendor,device_type,parameter,operator,expected_value,evidence_requirement,remediation,enabled,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$frameworkId,$controlCode,$title,$description,$category,$severity,$vendor,$deviceType,$parameter,$operator,$expected,$evidence,$remediation,1,current_user()['username'] ?? 'SYSTEM']);
        $newId = (int)$pdo->lastInsertId();
        try{(new EvidenceLedger($pdo))->ensureGenesis(current_user()['username']??'SYSTEM');(new EvidenceLedger($pdo))->append('POLICY_CREATED',['control_id'=>$newId,'control_code'=>$controlCode,'title'=>$title,'framework_id'=>$frameworkId],null,null,null,null,null,current_user()['username']??'SYSTEM');}catch(Throwable $e){error_log('[NexAud ledger] '.$e->getMessage());}
        flash('success', 'Custom policy created successfully.');
        redirect_to('controls/view.php?id='.$newId);
    } catch (PDOException $e) {
        if ((int)$e->errorInfo[1] === 1062) {
            flash('error', 'That control code already exists in the selected framework.');
            redirect_to('controls/edit.php?new=1');
        }
        throw $e;
    }
}

layout_header($editing ? 'Edit Control' : 'Policy Builder', 'controls');
?>
<div class="page-head">
  <div>
    <h1 class="page-title"><?=e($editing ? 'Edit Control' : 'Policy Builder')?></h1>
    <p class="page-sub"><?=e($editing ? 'Update a normalized compliance control.' : 'Create an organization-specific control on top of the common security baseline.')?></p>
  </div>
  <a class="btn" href="<?=e(url('controls/index.php'))?>">Control Catalog</a>
</div>

<div class="card">
  <div class="card-body">
    <form method="post">
      <?php if (!$editing): ?>
      <h3>Framework</h3>
      <div class="form-grid">
        <div class="field">
          <label>Existing Custom Framework</label>
          <select name="framework_id">
            <option value="0">Create / use framework by name below</option>
            <?php foreach ($customFrameworks as $f): ?>
              <option value="<?=e($f['framework_id'])?>"><?=e($f['name'].' · v'.$f['version'])?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>New Framework Name</label><input name="framework_name" placeholder="e.g. Corporate Network Baseline"></div>
        <div class="field"><label>Framework Version</label><input name="framework_version" value="1.0"></div>
        <div class="field"><label>Control Code</label><input name="control_code" placeholder="ORG-NET-001"></div>
      </div>
      <?php endif; ?>

      <h3>Policy Rule</h3>
      <div class="form-grid">
        <div class="field"><label>Title</label><input name="title" value="<?=e($control['title'] ?? '')?>" required></div>
        <div class="field"><label>Category</label><input name="category" value="<?=e($control['category'] ?? 'Network Security')?>"></div>
        <div class="field"><label>Severity</label><select name="severity"><?php foreach(['CRITICAL','HIGH','MEDIUM','LOW','INFO'] as $s): ?><option value="<?=$s?>" <?=strtoupper((string)($control['severity'] ?? 'MEDIUM'))===$s?'selected':''?>><?=$s?></option><?php endforeach; ?></select></div>
        <div class="field"><label>Vendor</label><input name="vendor" value="<?=e($control['vendor'] ?? 'ANY')?>"></div>
        <div class="field"><label>Device Type</label><input name="device_type" value="<?=e($control['device_type'] ?? 'ANY')?>"></div>
        <div class="field"><label>Normalized Parameter</label><input name="parameter" value="<?=e($control['parameter'] ?? '')?>" placeholder="management.remote_access.telnet_enabled" required></div>
        <div class="field"><label>Operator</label><select name="operator"><?php foreach(['equals','not_equals','contains','not_contains','greater_than','less_than','exists','not_exists','enabled','disabled'] as $op): ?><option value="<?=$op?>" <?=($control['operator'] ?? 'equals')===$op?'selected':''?>><?=$op?></option><?php endforeach; ?></select></div>
        <div class="field"><label>Expected Value</label><input name="expected_value" value="<?=e($control['expected_value'] ?? '')?>"></div>
      </div>
      <div class="field"><label>Description</label><textarea name="description" rows="3"><?=e($control['description'] ?? '')?></textarea></div>
      <div class="field"><label>Evidence Requirement</label><textarea name="evidence_requirement" rows="3"><?=e($control['evidence_requirement'] ?? '')?></textarea></div>
      <div class="field"><label>Remediation</label><textarea name="remediation" rows="3"><?=e($control['remediation'] ?? '')?></textarea></div>
      <?=csrf_field()?>
      <div class="actions"><button class="btn btn-primary"><?=e($editing ? 'Save Control' : 'Create Policy')?></button><a class="btn" href="<?=e(url('controls/index.php'))?>">Cancel</a></div>
    </form>
  </div>
</div>
<?php layout_footer(); ?>
