<?php
/**
 * NexAud Module 2 - normalization/schema.php
 *
 * Defines the vendor-neutral "NexAud Security Configuration Schema" (NSCS).
 * This is the common target structure that every vendor parser's output is
 * normalized into. The Compliance Engine (owned by another developer) reads
 * ONLY this structure — it never sees vendor-specific syntax directly.
 *
 * SCHEMA VERSION: 1.0
 *
 * Each leaf parameter is represented as an object with:
 *   - value    : the normalized value (bool|string|int|array)
 *   - source   : [ 'line' => int, 'raw' => string ]  <-- REQUIRED for traceability
 *   - vendor   : which vendor config this came from
 *
 * This module deliberately does NOT decide whether a value is
 * "compliant" or "non-compliant" — that is the Compliance Engine's job.
 * Module 2 only answers "what is configured, and where did that fact
 * come from".
 */

const NEXAUD_SCHEMA_VERSION = '1.0';

/**
 * Returns an empty NSCS document skeleton. Every top-level category always
 * exists (even if empty), so downstream consumers never need to
 * isset()-guard the top level.
 */
function nscs_empty_schema(): array
{
    return [
        'schema_version'   => NEXAUD_SCHEMA_VERSION,
        'identity'         => [],
        'management'       => [],
        'authentication'   => [],
        'authorization'    => [],
        'logging'          => [],
        'time_sync'        => [],
        'network_services' => [],
        'remote_access'    => [],
        'crypto'           => [],
        'password_policy'  => [],
        'accounts'         => [],
        'interfaces'       => [],
        'firewall'         => [],
        'acl'              => [],
        'snmp'             => [],
        'routing'          => [],
        'vpn'              => [],
        'security_features'=> [],
    ];
}

/** The set of valid top-level category keys (used to validate mapping rules). */
function nscs_categories(): array
{
    return array_keys(nscs_empty_schema());
}

/**
 * Build one normalized-parameter leaf value with mandatory evidence.
 *
 * @param mixed $value
 * @param int   $line   1-based line number in the ORIGINAL raw config
 * @param string $raw   the exact raw line/snippet that justifies this value
 * @param string $vendor
 */
function nscs_leaf($value, int $line, string $raw, string $vendor): array
{
    return [
        'value'  => $value,
        'source' => [
            'line' => $line,
            'raw'  => rtrim($raw),
        ],
        'vendor' => $vendor,
    ];
}

/**
 * Set a dotted-path parameter (e.g. "remote_access.ssh.enabled") into an
 * NSCS document, creating intermediate arrays as needed. Leaf is built via
 * nscs_leaf() by the caller — this function just places it.
 */
function nscs_set(array &$schema, string $dottedPath, array $leaf): void
{
    $parts = explode('.', $dottedPath);
    $cursor = &$schema;
    foreach ($parts as $i => $part) {
        $isLast = ($i === count($parts) - 1);
        if ($isLast) {
            $cursor[$part] = $leaf;
        } else {
            if (!isset($cursor[$part]) || !is_array($cursor[$part])) {
                $cursor[$part] = [];
            }
            $cursor = &$cursor[$part];
        }
    }
}

/**
 * Append a leaf onto a list at a dotted path ending in "[]" (e.g.
 * "acl.numbered_101.entries[]"). Used for repeatable facts (multiple ACL
 * entries, multiple static routes) where each occurrence must keep its own
 * evidence rather than the last one silently overwriting the others.
 */
function nscs_append(array &$schema, string $dottedPathWithBrackets, array $leaf): void
{
    $path = rtrim($dottedPathWithBrackets);
    if (str_ends_with($path, '[]')) {
        $path = substr($path, 0, -2);
    }
    $parts = explode('.', $path);
    $cursor = &$schema;
    foreach ($parts as $part) {
        if (!isset($cursor[$part]) || !is_array($cursor[$part])) {
            $cursor[$part] = [];
        }
        $cursor = &$cursor[$part];
    }
    $cursor[] = $leaf;
}

/**
 * Flatten an NSCS document into a list of {parameter, value, source, vendor}
 * rows — the exact "raw evidence" shape required by the spec, and the most
 * convenient shape for the Compliance Engine to iterate over rule-by-rule.
 */
function nscs_flatten(array $schema): array
{
    $out = [];
    $walk = function (array $node, string $prefix) use (&$walk, &$out) {
        foreach ($node as $key => $val) {
            if ($key === 'schema_version') {
                continue;
            }
            $path = $prefix === '' ? (string)$key : $prefix . '.' . $key;
            if (is_array($val) && array_key_exists('value', $val) && array_key_exists('source', $val)) {
                // it's a leaf
                $out[] = [
                    'parameter' => $path,
                    'value'     => $val['value'],
                    'source'    => $val['source'],
                    'vendor'    => $val['vendor'] ?? null,
                ];
            } elseif (is_array($val)) {
                $walk($val, $path);
            }
        }
    };
    $walk($schema, '');
    return $out;
}
