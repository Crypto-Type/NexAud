<?php
/**
 * NexAud Module 2 - normalization/mappings.php
 *
 * Vendor-specific rule tables consumed by normalization/engine.php. Each
 * rule maps a recognizable piece of vendor syntax onto one or more dotted
 * paths in the NexAud Security Configuration Schema (see schema.php).
 *
 * THIS FILE MAKES NO COMPLIANCE JUDGMENTS. Rules only ever answer
 * "what is configured", never "is this good or bad". A rule that captures
 * `remote_access.telnet.enabled = true` is not saying that's wrong — the
 * separately-owned Compliance Engine decides that.
 *
 * Rule shapes (see normalization/engine.php for exact contract):
 *   line_rules[]      = ['pattern' => <regex>, 'handler' => fn($m,$lineInfo,$vendor): array]
 *   context_rules[type][] = ['handler' => fn($ctx,$vendor): array]   // must include line+raw
 *   directive_rules[] = ['match' => fn($directive): bool, 'handler' => fn($directive,$vendor): array]
 *
 * Handler return: list of ['path' => 'a.b.c', 'value' => mixed] (plus
 * 'line'/'raw' only required for context_rules).
 */

function nexaud_mappings_for(string $vendor): ?array
{
    return match ($vendor) {
        'Cisco'     => nexaud_mappings_cisco(),
        'Fortinet'  => nexaud_mappings_fortinet(),
        'Palo Alto' => nexaud_mappings_paloalto(),
        default     => null,
    };
}

// =====================================================================
// CISCO
// =====================================================================
function nexaud_mappings_cisco(): array
{
    $line_rules = [];

    $line_rules[] = ['pattern' => '/^hostname\s+(\S+)/i', 'handler' =>
        fn($m) => [['path' => 'identity.hostname', 'value' => $m[1]]]];

    $line_rules[] = ['pattern' => '/^ip domain[- ]name\s+(\S+)/i', 'handler' =>
        fn($m) => [['path' => 'identity.domain_name', 'value' => $m[1]]]];

    $line_rules[] = ['pattern' => '/^version\s+([\d.]+)/i', 'handler' =>
        fn($m) => [['path' => 'identity.os_version', 'value' => 'IOS ' . $m[1]]]];

    $line_rules[] = ['pattern' => '/^ip ssh version\s+(\d)/i', 'handler' =>
        fn($m) => [['path' => 'remote_access.ssh.version', 'value' => $m[1]]]];

    $line_rules[] = ['pattern' => '/^(no\s+)?service password-encryption/i', 'handler' =>
        fn($m) => [['path' => 'password_policy.service_password_encryption', 'value' => empty($m[1])]]];

    $line_rules[] = ['pattern' => '/^security passwords min-length\s+(\d+)/i', 'handler' =>
        fn($m) => [['path' => 'password_policy.min_length', 'value' => (int)$m[1]]]];

    $line_rules[] = ['pattern' => '/^login block-for\s+(\d+)\s+attempts\s+(\d+)\s+within\s+(\d+)/i', 'handler' =>
        fn($m) => [
            ['path' => 'password_policy.lockout.enabled', 'value' => true],
            ['path' => 'password_policy.lockout.block_seconds', 'value' => (int)$m[1]],
            ['path' => 'password_policy.lockout.max_attempts', 'value' => (int)$m[2]],
            ['path' => 'password_policy.lockout.window_seconds', 'value' => (int)$m[3]],
        ]];

    $line_rules[] = ['pattern' => '/^enable secret\s+(?:\d\s+)?(\S+)/i', 'handler' =>
        fn($m) => [
            ['path' => 'authentication.privileged_exec.type', 'value' => 'secret'],
            ['path' => 'authentication.privileged_exec.hashed', 'value' => true],
        ]];

    $line_rules[] = ['pattern' => '/^enable password\s+(?:\d\s+)?(\S+)/i', 'handler' =>
        fn($m) => [
            ['path' => 'authentication.privileged_exec.type', 'value' => 'password'],
            ['path' => 'authentication.privileged_exec.hashed', 'value' => false],
        ]];

    $line_rules[] = ['pattern' => '/^username\s+(\S+)\s+privilege\s+(\d+)\s+(secret|password)\s+(?:\d\s+)?(\S+)/i',
        'handler' => fn($m) => [
            ['path' => "accounts.local.{$m[1]}.privilege", 'value' => (int)$m[2]],
            ['path' => "accounts.local.{$m[1]}.auth_type", 'value' => $m[3]],
            ['path' => "accounts.local.{$m[1]}.hashed", 'value' => strtolower($m[3]) === 'secret'],
        ]];

    $line_rules[] = ['pattern' => '/^aaa new-model/i', 'handler' =>
        fn($m) => [['path' => 'authentication.aaa.enabled', 'value' => true]]];

    $line_rules[] = ['pattern' => '/^aaa authentication login (\S+) group (\S+)(?:\s+(\S+))?/i', 'handler' =>
        fn($m) => [
            ['path' => 'authentication.aaa.login_list', 'value' => $m[1]],
            ['path' => 'authentication.aaa.primary_method', 'value' => $m[2]],
            ['path' => 'authentication.aaa.fallback_method', 'value' => $m[3] ?? null],
        ]];

    $line_rules[] = ['pattern' => '/^logging host\s+(\S+)/i', 'handler' =>
        fn($m) => [
            ['path' => 'logging.remote.enabled', 'value' => true],
            ['path' => 'logging.remote.host', 'value' => $m[1]],
        ]];

    $line_rules[] = ['pattern' => '/^(no\s+)?logging console/i', 'handler' =>
        fn($m) => [['path' => 'logging.console.enabled', 'value' => empty($m[1])]]];

    $line_rules[] = ['pattern' => '/^logging buffered\s+(\d+)/i', 'handler' =>
        fn($m) => [
            ['path' => 'logging.buffered.enabled', 'value' => true],
            ['path' => 'logging.buffered.size_bytes', 'value' => (int)$m[1]],
        ]];

    $line_rules[] = ['pattern' => '/^ntp server\s+(\S+)/i', 'handler' =>
        fn($m) => [
            ['path' => 'time_sync.ntp.enabled', 'value' => true],
            ['path' => 'time_sync.ntp.server', 'value' => $m[1]],
        ]];

    $line_rules[] = ['pattern' => '/^clock timezone\s+(\S+)\s+(-?\d+)/i', 'handler' =>
        fn($m) => [['path' => 'time_sync.timezone', 'value' => $m[1] . ' UTC' . ($m[2] >= 0 ? '+' : '') . $m[2]]]];

    $line_rules[] = ['pattern' => '/^snmp-server community\s+(\S+)\s+(RO|RW)/i', 'handler' =>
        fn($m) => [
            ['path' => 'snmp.v2c.enabled', 'value' => true],
            ['path' => 'snmp.v2c.community', 'value' => $m[1]],
            ['path' => 'snmp.v2c.access', 'value' => strtoupper($m[2])],
        ]];

    $line_rules[] = ['pattern' => '/^snmp-server group\s+(\S+)\s+v3\s+(\S+)/i', 'handler' =>
        fn($m) => [
            ['path' => 'snmp.v3.enabled', 'value' => true],
            ['path' => 'snmp.v3.group', 'value' => $m[1]],
            ['path' => 'snmp.v3.security_level', 'value' => $m[2]],
        ]];

    $line_rules[] = ['pattern' => '/^(no\s+)?cdp run/i', 'handler' =>
        fn($m) => [['path' => 'network_services.cdp.enabled', 'value' => empty($m[1])]]];

    $line_rules[] = ['pattern' => '/^(no\s+)?ip http server/i', 'handler' =>
        fn($m) => [['path' => 'network_services.http.enabled', 'value' => empty($m[1])]]];

    $line_rules[] = ['pattern' => '/^(no\s+)?ip http secure-server/i', 'handler' =>
        fn($m) => [['path' => 'network_services.https.enabled', 'value' => empty($m[1])]]];

    $line_rules[] = ['pattern' => '/^(no\s+)?service tcp-small-servers/i', 'handler' =>
        fn($m) => [['path' => 'network_services.tcp_small_servers.enabled', 'value' => empty($m[1])]]];

    $line_rules[] = ['pattern' => '/^(no\s+)?service finger/i', 'handler' =>
        fn($m) => [['path' => 'network_services.finger.enabled', 'value' => empty($m[1])]]];

    $line_rules[] = ['pattern' => '/^(no\s+)?ip domain[- ]lookup/i', 'handler' =>
        fn($m) => [['path' => 'network_services.dns_lookup.enabled', 'value' => empty($m[1])]]];

    $line_rules[] = ['pattern' => '/^(no\s+)?ip bootp server/i', 'handler' =>
        fn($m) => [['path' => 'network_services.bootp.enabled', 'value' => empty($m[1])]]];

    $line_rules[] = ['pattern' => '/^banner (motd|login)\b/i', 'handler' =>
        fn($m) => [['path' => 'management.banner.set', 'value' => true]]];

    $line_rules[] = ['pattern' => '/^access-list\s+(\d+)\s+(permit|deny)\s+(.+)$/i', 'handler' =>
        fn($m) => [['path' => "acl.numbered_{$m[1]}.entries[]", 'value' => strtoupper($m[2]) . ' ' . $m[3]]]];

    $line_rules[] = ['pattern' => '/^router (ospf|bgp|eigrp)\s+(\S+)/i', 'handler' =>
        fn($m) => [
            ['path' => 'routing.' . strtolower($m[1]) . '.enabled', 'value' => true],
            ['path' => 'routing.' . strtolower($m[1]) . '.process_id', 'value' => $m[2]],
        ]];

    $line_rules[] = ['pattern' => '/^crypto isakmp policy\s+(\d+)/i', 'handler' =>
        fn($m) => [['path' => 'vpn.ike.policy_defined', 'value' => true]]];

    $line_rules[] = ['pattern' => '/^crypto ipsec transform-set\s+(\S+)/i', 'handler' =>
        fn($m) => [['path' => 'vpn.ipsec.transform_set', 'value' => $m[1]]]];

    // ---- context: line con / line vty ----------------------------------
    $vtyConHandler = function (array $ctx, string $vendor): array {
        $out = [];
        $isVty = $ctx['type'] === 'line_vty';
        // Per-range/per-context detail lives under its own key so multiple
        // vty ranges (e.g. "vty 0 4" vs "vty 5 15", which commonly carry
        // DIFFERENT transport settings on real routers) never collide by
        // overwriting a single flat path. The overall
        // remote_access.ssh.enabled / telnet.enabled summary is computed
        // separately below by nexaud_cisco_reduce_remote_access(), which
        // OR-reduces across every vty range (if ANY range allows telnet,
        // telnet is reachable on the device — that's the security-relevant
        // fact).
        $rangeKey = $isVty ? 'vty_' . preg_replace('/[^a-z0-9]+/i', '_', trim($ctx['name']) ?: $ctx['start_line']) : null;
        $prefix = $isVty ? "remote_access.vty_ranges.{$rangeKey}" : 'management.console';

        foreach ($ctx['lines'] as $lineInfo) {
            $raw = $lineInfo['raw'];

            if (preg_match('/^\s*transport input\s+(.+)$/i', $raw, $m)) {
                $protocols = strtolower(trim($m[1]));
                if ($protocols === 'none') {
                    $sshEnabled = false;
                    $telnetEnabled = false;
                } elseif ($protocols === 'all') {
                    $sshEnabled = true;
                    $telnetEnabled = true;
                } else {
                    $sshEnabled = (bool)preg_match('/\bssh\b/', $protocols);
                    $telnetEnabled = (bool)preg_match('/\btelnet\b/', $protocols);
                }
                $out[] = ['path' => "{$prefix}.ssh.enabled", 'value' => $sshEnabled, 'line' => $lineInfo['line'], 'raw' => $raw];
                $out[] = ['path' => "{$prefix}.telnet.enabled", 'value' => $telnetEnabled, 'line' => $lineInfo['line'], 'raw' => $raw];
            }

            if (preg_match('/^\s*login local\s*$/i', $raw)) {
                $out[] = ['path' => "{$prefix}.auth_mode", 'value' => 'local', 'line' => $lineInfo['line'], 'raw' => $raw];
            }
            if (preg_match('/^\s*login authentication\s+(\S+)/i', $raw, $m)) {
                $out[] = ['path' => "{$prefix}.auth_mode", 'value' => 'aaa:' . $m[1], 'line' => $lineInfo['line'], 'raw' => $raw];
            }
            if (preg_match('/^\s*password\s+(?:\d\s+)?(\S+)/i', $raw) && !preg_match('/^\s*login local/i', $raw)) {
                $out[] = ['path' => "{$prefix}.auth_mode", 'value' => 'line_password', 'line' => $lineInfo['line'], 'raw' => $raw];
            }
            if (preg_match('/^\s*exec-timeout\s+(\d+)\s+(\d+)/i', $raw, $m)) {
                $seconds = ((int)$m[1]) * 60 + (int)$m[2];
                $out[] = ['path' => "{$prefix}.exec_timeout_seconds", 'value' => $seconds, 'line' => $lineInfo['line'], 'raw' => $raw];
            }
        }
        return $out;
    };

    /**
     * OR-reduces remote_access.ssh/telnet.enabled across every "line vty"
     * range on the device. If ANY vty range permits a protocol, that
     * protocol is reachable on the box — this is the summary fact the
     * Compliance Engine actually wants to evaluate. Evidence prefers a line
     * that asserts "true" (the actual exposure) when one exists.
     */
    $reduceRemoteAccess = function (array $ir, string $vendor): array {
        $sshHits = [];   // each: ['line'=>,'raw'=>,'value'=>bool]
        $telnetHits = [];
        foreach ($ir['contexts'] ?? [] as $ctx) {
            if ($ctx['type'] !== 'line_vty') {
                continue;
            }
            foreach ($ctx['lines'] as $lineInfo) {
                if (preg_match('/^\s*transport input\s+(.+)$/i', $lineInfo['raw'], $m)) {
                    $protocols = strtolower(trim($m[1]));
                    $ssh = $protocols === 'all' || ($protocols !== 'none' && preg_match('/\bssh\b/', $protocols));
                    $telnet = $protocols === 'all' || ($protocols !== 'none' && preg_match('/\btelnet\b/', $protocols));
                    $sshHits[] = ['line' => $lineInfo['line'], 'raw' => $lineInfo['raw'], 'value' => $ssh];
                    $telnetHits[] = ['line' => $lineInfo['line'], 'raw' => $lineInfo['raw'], 'value' => $telnet];
                }
            }
        }
        $pick = function (array $hits) {
            if (!$hits) {
                return null;
            }
            foreach ($hits as $h) {
                if ($h['value'] === true) {
                    return $h; // prefer evidence that shows the exposure
                }
            }
            return $hits[0];
        };
        $out = [];
        if ($sshPick = $pick($sshHits)) {
            $out[] = ['path' => 'remote_access.ssh.enabled', 'value' => $sshPick['value'], 'line' => $sshPick['line'], 'raw' => $sshPick['raw']];
        }
        if ($telnetPick = $pick($telnetHits)) {
            $out[] = ['path' => 'remote_access.telnet.enabled', 'value' => $telnetPick['value'], 'line' => $telnetPick['line'], 'raw' => $telnetPick['raw']];
        }
        return $out;
    };

    $context_rules = [
        'line_vty' => [['handler' => $vtyConHandler]],
        'line_con' => [['handler' => $vtyConHandler]],
        'interface' => [['handler' => function (array $ctx, string $vendor): array {
            $out = [];
            $name = $ctx['name'];
            foreach ($ctx['lines'] as $lineInfo) {
                $raw = $lineInfo['raw'];
                if (preg_match('/^\s*ip address\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)/i', $raw, $m)) {
                    $out[] = ['path' => "interfaces.{$name}.ip_address", 'value' => $m[1], 'line' => $lineInfo['line'], 'raw' => $raw];
                    $out[] = ['path' => "interfaces.{$name}.subnet_mask", 'value' => $m[2], 'line' => $lineInfo['line'], 'raw' => $raw];
                }
                if (preg_match('/^\s*(no\s+)?shutdown\s*$/i', $raw, $m)) {
                    $out[] = ['path' => "interfaces.{$name}.admin_status", 'value' => empty($m[1]) ? 'down' : 'up', 'line' => $lineInfo['line'], 'raw' => $raw];
                }
                if (preg_match('/^\s*ip access-group\s+(\S+)\s+(in|out)/i', $raw, $m)) {
                    $out[] = ['path' => "interfaces.{$name}.acl_applied.{$m[2]}", 'value' => $m[1], 'line' => $lineInfo['line'], 'raw' => $raw];
                }
                if (preg_match('/^\s*(no\s+)?ip proxy-arp\s*$/i', $raw, $m)) {
                    $out[] = ['path' => "interfaces.{$name}.proxy_arp_enabled", 'value' => empty($m[1]), 'line' => $lineInfo['line'], 'raw' => $raw];
                }
                if (preg_match('/^\s*description\s+(.+)$/i', $raw, $m)) {
                    $out[] = ['path' => "interfaces.{$name}.description", 'value' => trim($m[1]), 'line' => $lineInfo['line'], 'raw' => $raw];
                }
            }
            return $out;
        }]],
    ];

    return [
        'line_rules' => $line_rules,
        'context_rules' => $context_rules,
        'directive_rules' => [],
        'reduce_rules' => [['handler' => $reduceRemoteAccess]],
    ];
}

// =====================================================================
// FORTINET
// =====================================================================
function nexaud_mappings_fortinet(): array
{
    $pathIs = fn(array $d, array $wanted) => $d['path'] === $wanted;

    $directive_rules = [];

    // config system global
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'global']) && $d['key'] === 'hostname',
        'handler' => fn($d) => [['path' => 'identity.hostname', 'value' => $d['value']]],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'global']) && $d['key'] === 'timezone',
        'handler' => fn($d) => [['path' => 'time_sync.timezone', 'value' => $d['value']]],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'global']) && $d['key'] === 'admin-lockout-threshold',
        'handler' => fn($d) => [
            ['path' => 'password_policy.lockout.enabled', 'value' => true],
            ['path' => 'password_policy.lockout.max_attempts', 'value' => (int)$d['value']],
        ],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'global']) && $d['key'] === 'admin-lockout-duration',
        'handler' => fn($d) => [['path' => 'password_policy.lockout.block_seconds', 'value' => (int)$d['value']]],
    ];

    // config system password-policy
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'password-policy']) && $d['key'] === 'minimum-length',
        'handler' => fn($d) => [['path' => 'password_policy.min_length', 'value' => (int)$d['value']]],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'password-policy']) && $d['key'] === 'status',
        'handler' => fn($d) => [['path' => 'password_policy.enforced', 'value' => strtolower($d['value']) === 'enable']],
    ];

    // config system interface > edit <port>  set allowaccess ...
    // NOTE: only the per-interface detail is written here (which management
    // protocols are allowed on THIS interface). The device-wide summary
    // (remote_access.ssh.enabled / telnet.enabled / etc — "is this protocol
    // reachable on ANY interface") is computed by nexaud_fortinet_reduce_allowaccess()
    // below and applied as a reduce_rule, so that a later-processed
    // interface with fewer allowed protocols can never silently overwrite
    // an earlier interface's more permissive (and more security-relevant)
    // setting.
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'interface']) && $d['edit'] !== null && $d['key'] === 'allowaccess',
        'handler' => function ($d) {
            return [['path' => "interfaces.{$d['edit']}.allowaccess", 'value' => $d['value']]];
        },
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'interface']) && $d['edit'] !== null && $d['key'] === 'ip',
        'handler' => fn($d) => [['path' => "interfaces.{$d['edit']}.ip_address", 'value' => $d['value']]],
    ];

    // config system admin > edit <user>
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'admin']) && $d['edit'] !== null && $d['key'] === 'accprofile',
        'handler' => fn($d) => [['path' => "accounts.local.{$d['edit']}.profile", 'value' => trim($d['value'], '"')]],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'admin']) && $d['edit'] !== null && $d['key'] === 'password',
        'handler' => fn($d) => [
            // Never store the actual secret material.
            ['path' => "accounts.local.{$d['edit']}.password_set", 'value' => true],
        ],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'admin']) && $d['edit'] !== null && $d['key'] === 'two-factor',
        'handler' => fn($d) => [['path' => "accounts.local.{$d['edit']}.two_factor", 'value' => strtolower($d['value']) !== 'disable']],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'admin']) && $d['edit'] !== null && $d['key'] === 'trusthost1',
        'handler' => fn($d) => [['path' => "accounts.local.{$d['edit']}.trusted_host_restricted", 'value' => trim($d['value'], '"') !== '0.0.0.0 0.0.0.0']],
    ];

    // config system ntp
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'ntp']) && $d['key'] === 'ntpsync',
        'handler' => fn($d) => [['path' => 'time_sync.ntp.enabled', 'value' => strtolower($d['value']) === 'enable']],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'ntp', 'ntpserver']) && $d['key'] === 'server',
        'handler' => fn($d) => [['path' => 'time_sync.ntp.server', 'value' => trim($d['value'], '"')]],
    ];

    // config log ... setting: status
    $directive_rules[] = [
        'match' => fn($d) => count($d['path']) >= 1 && $d['path'][0] === 'log' && $d['key'] === 'status',
        'handler' => function ($d) {
            $sub = $d['path'][1] ?? 'general';
            return [['path' => "logging.{$sub}.enabled", 'value' => strtolower($d['value']) === 'enable']];
        },
    ];
    $directive_rules[] = [
        'match' => fn($d) => count($d['path']) >= 1 && $d['path'][0] === 'log' && $d['key'] === 'server',
        'handler' => function ($d) {
            $sub = $d['path'][1] ?? 'general';
            return [
                ['path' => "logging.{$sub}.enabled", 'value' => true],
                ['path' => "logging.{$sub}.host", 'value' => trim($d['value'], '"')],
            ];
        },
    ];

    // config system snmp community > edit <id>
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'snmp', 'community']) && $d['edit'] !== null && $d['key'] === 'name',
        'handler' => fn($d) => [
            ['path' => 'snmp.v2c.enabled', 'value' => true],
            ['path' => 'snmp.v2c.community', 'value' => trim($d['value'], '"')],
        ],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'snmp', 'community']) && $d['edit'] !== null && in_array($d['key'], ['query-v1-status', 'query-v2c-status'], true),
        'handler' => fn($d) => [['path' => 'snmp.v2c.query_enabled', 'value' => strtolower($d['value']) === 'enable']],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['system', 'snmp', 'sysinfo']) && $d['key'] === 'status',
        'handler' => fn($d) => [['path' => 'snmp.enabled', 'value' => strtolower($d['value']) === 'enable']],
    ];

    // config firewall policy > edit <id>
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['firewall', 'policy']) && $d['edit'] !== null && $d['key'] === 'action',
        'handler' => fn($d) => [["path" => "firewall.policy_{$d['edit']}.action", 'value' => $d['value']]],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['firewall', 'policy']) && $d['edit'] !== null && $d['key'] === 'service',
        'handler' => fn($d) => [["path" => "firewall.policy_{$d['edit']}.service", 'value' => $d['value']]],
    ];
    $directive_rules[] = [
        'match' => fn($d) => $pathIs($d, ['firewall', 'policy']) && $d['edit'] !== null && $d['key'] === 'logtraffic',
        'handler' => fn($d) => [["path" => "firewall.policy_{$d['edit']}.log_traffic", 'value' => $d['value']]],
    ];

    // config vpn ipsec phase1-interface > edit <name>
    $directive_rules[] = [
        'match' => fn($d) => count($d['path']) >= 2 && $d['path'][0] === 'vpn' && $d['path'][1] === 'ipsec' && $d['edit'] !== null,
        'handler' => fn($d) => [['path' => 'vpn.ipsec.enabled', 'value' => true]],
    ];

    // config router ...
    $directive_rules[] = [
        'match' => fn($d) => count($d['path']) >= 1 && $d['path'][0] === 'router',
        'handler' => function ($d) {
            $proto = $d['path'][1] ?? 'unknown';
            return [['path' => "routing.{$proto}.enabled", 'value' => true]];
        },
    ];

    /**
     * OR-reduces remote_access/network_services exposure flags across every
     * "config system interface > edit <port>" block. If ANY interface's
     * allowaccess includes a protocol, that protocol is reachable on the
     * device — the security-relevant summary fact.
     */
    $reduceAllowaccess = function (array $ir, string $vendor): array {
        $flagsWanted = [
            'ssh'    => 'remote_access.ssh.enabled',
            'telnet' => 'remote_access.telnet.enabled',
            'http'   => 'network_services.http.enabled',
            'https'  => 'network_services.https.enabled',
            'ping'   => 'network_services.ping.enabled',
        ];
        $hits = array_fill_keys(array_keys($flagsWanted), []);
        foreach ($ir['directives'] ?? [] as $d) {
            if ($d['path'] === ['system', 'interface'] && $d['edit'] !== null && $d['key'] === 'allowaccess') {
                $val = strtolower($d['value']);
                foreach ($flagsWanted as $proto => $path) {
                    $hits[$proto][] = ['line' => $d['line'], 'raw' => $d['raw'], 'value' => (bool)preg_match('/\b' . $proto . '\b/', $val)];
                }
            }
        }
        $pick = function (array $arr) {
            if (!$arr) {
                return null;
            }
            foreach ($arr as $h) {
                if ($h['value'] === true) {
                    return $h;
                }
            }
            return $arr[0];
        };
        $out = [];
        foreach ($flagsWanted as $proto => $path) {
            if ($picked = $pick($hits[$proto])) {
                $out[] = ['path' => $path, 'value' => $picked['value'], 'line' => $picked['line'], 'raw' => $picked['raw']];
            }
        }
        return $out;
    };

    return [
        'line_rules' => [],
        'context_rules' => [],
        'directive_rules' => $directive_rules,
        'reduce_rules' => [['handler' => $reduceAllowaccess]],
    ];
}

// =====================================================================
// PALO ALTO (PAN-OS "set" format)
// =====================================================================
function nexaud_mappings_paloalto(): array
{
    $line_rules = [];

    $line_rules[] = ['pattern' => '/^set deviceconfig system hostname\s+(\S+)/i', 'handler' =>
        fn($m) => [['path' => 'identity.hostname', 'value' => $m[1]]]];

    $line_rules[] = ['pattern' => '/^set deviceconfig system domain\s+(\S+)/i', 'handler' =>
        fn($m) => [['path' => 'identity.domain_name', 'value' => $m[1]]]];

    $line_rules[] = ['pattern' => '/^set deviceconfig system timezone\s+(\S+)/i', 'handler' =>
        fn($m) => [['path' => 'time_sync.timezone', 'value' => $m[1]]]];

    $line_rules[] = ['pattern' => '/^set deviceconfig system ntp-servers primary-ntp-server ntp-server-address\s+(\S+)/i',
        'handler' => fn($m) => [
            ['path' => 'time_sync.ntp.enabled', 'value' => true],
            ['path' => 'time_sync.ntp.server', 'value' => $m[1]],
        ]];

    $line_rules[] = ['pattern' => '/^set deviceconfig system service disable-telnet\s+(yes|no)/i', 'handler' =>
        fn($m) => [['path' => 'remote_access.telnet.enabled', 'value' => strtolower($m[1]) === 'no']]];

    $line_rules[] = ['pattern' => '/^set deviceconfig system service disable-ssh\s+(yes|no)/i', 'handler' =>
        fn($m) => [['path' => 'remote_access.ssh.enabled', 'value' => strtolower($m[1]) === 'no']]];

    $line_rules[] = ['pattern' => '/^set deviceconfig system service disable-http\s+(yes|no)/i', 'handler' =>
        fn($m) => [['path' => 'network_services.http.enabled', 'value' => strtolower($m[1]) === 'no']]];

    $line_rules[] = ['pattern' => '/^set deviceconfig system service disable-https\s+(yes|no)/i', 'handler' =>
        fn($m) => [['path' => 'network_services.https.enabled', 'value' => strtolower($m[1]) === 'no']]];

    $line_rules[] = ['pattern' => '/^set deviceconfig setting management-interface ping\s+(yes|no)/i', 'handler' =>
        fn($m) => [['path' => 'network_services.ping.enabled', 'value' => strtolower($m[1]) === 'yes']]];

    $line_rules[] = ['pattern' => '/^set deviceconfig system snmp-setting community\s+(\S+)/i', 'handler' =>
        fn($m) => [
            ['path' => 'snmp.v2c.enabled', 'value' => true],
            ['path' => 'snmp.v2c.community', 'value' => trim($m[1], '"')],
        ]];

    $line_rules[] = ['pattern' => '/^set deviceconfig system snmp-setting access-setting version\s+(v2c|v3)/i', 'handler' =>
        fn($m) => [['path' => 'snmp.version', 'value' => $m[1]]]];

    $line_rules[] = ['pattern' => '/^set shared log-settings syslog\s+"?([^"\s]+)"?\s+server\s+"?([^"\s]+)"?/i',
        'handler' => fn($m) => [
            ['path' => 'logging.syslog.enabled', 'value' => true],
            ['path' => 'logging.syslog.host', 'value' => $m[2]],
        ]];

    $line_rules[] = ['pattern' => '/^set mgt-config users\s+(\S+)\s+phash\s+/i', 'handler' =>
        fn($m) => [['path' => "accounts.local.{$m[1]}.password_set", 'value' => true]]];

    $line_rules[] = ['pattern' => '/^set mgt-config users\s+(\S+)\s+permissions role-based\s+(\S+)\s+yes/i', 'handler' =>
        fn($m) => [['path' => "accounts.local.{$m[1]}.role", 'value' => $m[2]]]];

    $line_rules[] = ['pattern' => '/^set mgt-config password-complexity\s+enabled\s+(yes|no)/i', 'handler' =>
        fn($m) => [['path' => 'password_policy.enforced', 'value' => strtolower($m[1]) === 'yes']]];

    $line_rules[] = ['pattern' => '/^set mgt-config password-complexity minimum-length\s+(\d+)/i', 'handler' =>
        fn($m) => [['path' => 'password_policy.min_length', 'value' => (int)$m[1]]]];

    $line_rules[] = ['pattern' => '/^set network interface ethernet\s+(\S+)\s+layer3 ip\s+(\S+)/i', 'handler' =>
        fn($m) => [['path' => "interfaces.{$m[1]}.ip_address", 'value' => $m[2]]]];

    $line_rules[] = ['pattern' => '/^set zone\s+(\S+)\s+network layer3\s+(\S+)/i', 'handler' =>
        fn($m) => [['path' => "interfaces.{$m[2]}.zone", 'value' => $m[1]]]];

    $line_rules[] = ['pattern' => '/^set rulebase security rules\s+"?([^"]+?)"?\s+action\s+(\S+)/i', 'handler' =>
        fn($m) => [['path' => 'firewall.rule_' . preg_replace('/\W+/', '_', $m[1]) . '.action', 'value' => $m[2]]]];

    $line_rules[] = ['pattern' => '/^set rulebase security rules\s+"?([^"]+?)"?\s+log-end\s+(yes|no)/i', 'handler' =>
        fn($m) => [['path' => 'firewall.rule_' . preg_replace('/\W+/', '_', $m[1]) . '.log_end', 'value' => strtolower($m[2]) === 'yes']]];

    $line_rules[] = ['pattern' => '/^set network virtual-router\s+(\S+)\s+routing-table ip static-route\s+(\S+)/i',
        'handler' => fn($m) => [
            ['path' => 'routing.static.enabled', 'value' => true],
            ['path' => 'routing.static.route_names[]', 'value' => $m[2]],
        ]];

    $line_rules[] = ['pattern' => '/^set network ike gateway\s+"?([^"]+?)"?\s+/i', 'handler' =>
        fn($m) => [['path' => 'vpn.ike.enabled', 'value' => true]]];

    $line_rules[] = ['pattern' => '/^set network tunnel ipsec\s+"?([^"]+?)"?\s+/i', 'handler' =>
        fn($m) => [['path' => 'vpn.ipsec.enabled', 'value' => true]]];

    return ['line_rules' => $line_rules, 'context_rules' => [], 'directive_rules' => [], 'reduce_rules' => []];
}
