<?php
/**
 * NexAud Module 2 - normalization/engine.php
 *
 * Public API (contract):
 *   normalizeConfiguration(string $vendor, array $ir): array
 *
 * Applies the vendor's mapping rules (normalization/mappings.php) against
 * the parser's Intermediate Representation (parsers/*.php) to build a full
 * NexAud Security Configuration Schema (NSCS) document (normalization/schema.php).
 *
 * For vendor === 'Unknown', this function does NOT attempt schema
 * normalization — it passes through the unknown-parser's heuristic report
 * unchanged, per the "Unknown vendor should not simply fail" requirement.
 *
 * This engine makes NO compliance decisions — it only decides what facts
 * are true and where they came from.
 */

require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/mappings.php';

function normalizeConfiguration(string $vendor, array $ir): array
{
    if ($vendor === 'Unknown' || !empty($ir['unknown_report'])) {
        return [
            'schema_version' => NEXAUD_SCHEMA_VERSION,
            'vendor'         => 'Unknown',
            'normalized'     => null,
            'unknown_report' => $ir['unknown_report'] ?? null,
        ];
    }

    $mappings = nexaud_mappings_for($vendor);
    $schema = nscs_empty_schema();

    if ($mappings === null) {
        // No mapping table registered for this vendor yet. Do not fail —
        // return an empty-but-valid schema so downstream code never has to
        // special-case a missing vendor, and record why nothing populated.
        return [
            'schema_version' => NEXAUD_SCHEMA_VERSION,
            'vendor'         => $vendor,
            'normalized'     => $schema,
            'warning'        => "No normalization mapping table registered for vendor '{$vendor}'.",
        ];
    }

    // ---- Pass 1: line-based rules (Cisco, Palo Alto) ----------------------
    foreach ($ir['raw_lines'] ?? [] as $lineInfo) {
        $raw = $lineInfo['raw'];
        if (trim($raw) === '') {
            continue;
        }
        foreach ($mappings['line_rules'] ?? [] as $rule) {
            if (preg_match($rule['pattern'], trim($raw), $m)) {
                foreach (($rule['handler'])($m, $lineInfo, $vendor) as $r) {
                    if ($r['value'] === null) {
                        continue; // optional capture groups that didn't match
                    }
                    $leaf = nscs_leaf($r['value'], $lineInfo['line'], $raw, $vendor);
                    if (str_ends_with($r['path'], '[]')) {
                        nscs_append($schema, $r['path'], $leaf);
                    } else {
                        nscs_set($schema, $r['path'], $leaf);
                    }
                }
            }
        }
    }

    // ---- Pass 2: context-based rules (Cisco line vty/con, interfaces) ------
    foreach ($ir['contexts'] ?? [] as $ctx) {
        $rules = $mappings['context_rules'][$ctx['type']] ?? [];
        foreach ($rules as $rule) {
            foreach (($rule['handler'])($ctx, $vendor) as $r) {
                if ($r['value'] === null) {
                    continue;
                }
                $leaf = nscs_leaf($r['value'], $r['line'], $r['raw'], $vendor);
                if (str_ends_with($r['path'], '[]')) {
                    nscs_append($schema, $r['path'], $leaf);
                } else {
                    nscs_set($schema, $r['path'], $leaf);
                }
            }
        }
    }

    // ---- Pass 3: directive-based rules (Fortinet config/edit/set stack) ---
    foreach ($ir['directives'] ?? [] as $directive) {
        foreach ($mappings['directive_rules'] ?? [] as $rule) {
            if (($rule['match'])($directive)) {
                foreach (($rule['handler'])($directive, 'Fortinet') as $r) {
                    if ($r['value'] === null) {
                        continue;
                    }
                    $leaf = nscs_leaf($r['value'], $directive['line'], $directive['raw'], $vendor);
                    if (str_ends_with($r['path'], '[]')) {
                        nscs_append($schema, $r['path'], $leaf);
                    } else {
                        nscs_set($schema, $r['path'], $leaf);
                    }
                }
            }
        }
    }

    // ---- Pass 4: reduce/aggregation rules ----------------------------------
    // Run AFTER passes 1-3 so their results are authoritative. Used for
    // facts that must be OR-reduced across multiple repeatable blocks
    // (multiple vty ranges, multiple interfaces) rather than having the
    // last-processed block silently overwrite an earlier, more permissive
    // (and more security-relevant) one.
    foreach ($mappings['reduce_rules'] ?? [] as $rule) {
        foreach (($rule['handler'])($ir, $vendor) as $r) {
            if ($r['value'] === null) {
                continue;
            }
            $leaf = nscs_leaf($r['value'], $r['line'], $r['raw'], $vendor);
            if (str_ends_with($r['path'], '[]')) {
                nscs_append($schema, $r['path'], $leaf);
            } else {
                nscs_set($schema, $r['path'], $leaf);
            }
        }
    }

    return [
        'schema_version' => NEXAUD_SCHEMA_VERSION,
        'vendor'         => $vendor,
        'normalized'     => $schema,
        'flattened'      => nscs_flatten($schema), // convenience for the Compliance Engine
    ];
}
