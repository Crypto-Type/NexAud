<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
requirePermission('ai.use');
require_once __DIR__ . '/../ai/CopilotService.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'POST required']);
    exit;
}

$input = json_decode((string)file_get_contents('php://input'), true);
$input = is_array($input) ? $input : $_POST;

$token = (string)($input['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
$sessionToken = (string)($_SESSION[CSRF_TOKEN_KEY] ?? '');
if ($token === '' || $sessionToken === '' || !hash_equals($sessionToken, $token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
    exit;
}

$question = trim((string)($input['question'] ?? ''));
if ($question === '') {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'Question is required']);
    exit;
}

$started = microtime(true);
try {
    $service = new NexAudCopilotService();
    $result = $service->ask($question);
    $latency = (int)round((microtime(true) - $started) * 1000);
    try {
        getDB()->prepare('INSERT INTO ai_query_log(user_id,action,question,provider,success,latency_ms,created_at) VALUES(?,?,?,?,?,?,NOW())')
            ->execute([current_user_id(), 'COPILOT_API', $question, $result['mode'] ?? 'NexAud Tool-Aware Copilot', 1, $latency]);
    } catch (Throwable $ignored) {
        // Query logging failure must not prevent the Copilot response.
    }
    echo json_encode(['success' => true, 'latency_ms' => $latency] + $result, JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    try {
        getDB()->prepare('INSERT INTO ai_query_log(user_id,action,question,provider,success,latency_ms,created_at) VALUES(?,?,?,?,?,?,NOW())')
            ->execute([current_user_id(), 'COPILOT_API', $question, 'NexAud Tool-Aware Copilot', 0, (int)round((microtime(true) - $started) * 1000)]);
    } catch (Throwable $ignored) {}
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Copilot failed to read NexAud context safely.']);
}
