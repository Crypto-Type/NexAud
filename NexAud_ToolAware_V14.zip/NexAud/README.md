# NexAud V11 – Comprehensive AI Copilot

The Copilot now includes a large built-in basic cybersecurity knowledge layer plus the existing live NexAud database/tool-aware audit reasoning.

## Included

- 140 basic cybersecurity questions
- 14 topic categories
- Searchable question browser in the AI Copilot page
- Exact, alias and lightweight semantic matching for question variations
- Existing live NexAud questions for devices, configurations, findings, audits, policies, training, evidence, reports and administration
- Existing AI audit reasoning for failed findings
- Read-only knowledge and reasoning; state-changing workflows remain protected

## Basic categories

NexAud & AI; Network Basics; Network Security Fundamentals; Protocols & Services; Identity & Access; Cryptography & Secrets; Firewalls, ACLs & Routing; Logging, Monitoring & Detection; Compliance & Frameworks; Risk, Vulnerabilities & Configuration; Zero Trust & Incident Response; Application & Cloud Security; Network Device Hardening; Audit Evidence & Assurance.

## V12 Copilot Module Question Library
The AI Copilot now exposes a module-specific question library for the NexAud navigation areas: Devices, Configurations, Audits & Analysis, Findings, Frameworks, Controls, Custom Policies, AI Copilot, AI Training, Evidence Ledger, and Reports. Questions are grouped by module and submit directly into the Copilot.
