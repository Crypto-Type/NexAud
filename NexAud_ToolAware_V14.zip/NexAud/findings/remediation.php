<?php
declare(strict_types=1);
require_once __DIR__.'/FindingManager.php';
require_once __DIR__.'/../compliance/workflow.php';
requirePermission('findings.view');
$findingId=(int)($_GET['id']??0);
$r=(new FindingManager())->get($findingId); if(!$r)render_error(404);
$workflow=latest_remediation_for_finding($findingId);
$simResults=$workflow&&$workflow['simulated_result_json']?json_decode($workflow['simulated_result_json'],true):null;
$reRun=$workflow&&$workflow['re_audit_run_id']?db_one('SELECT * FROM audit_runs WHERE audit_run_id=?',[(int)$workflow['re_audit_run_id']]):null;
$baseRun=db_one('SELECT * FROM audit_runs WHERE configuration_id=? AND mode=\'BASELINE\' AND status=\'COMPLETED\' ORDER BY audit_run_id DESC LIMIT 1',[(string)$r['configuration_id']]);
layout_header('Remediation #'.$r['finding_id'],'findings');
$canManage=hasPermission('findings.manage');
?>
<div class="page-head"><div><h1 class="page-title">Remediation Workflow · Finding #<?=e($r['finding_id'])?></h1><p class="page-sub">What-If → Human Approval → Safe Re-Audit → Evidence Ledger.</p></div></div>
<div class="grid-2">
  <div class="card"><div class="card-head">Finding</div><div class="card-body"><table>
    <tr><th>Device</th><td><?=e($r['device_name']??$r['device_id'])?></td></tr>
    <tr><th>Control</th><td><?=e($r['control_code'])?></td></tr>
    <tr><th>Status</th><td><?=status_badge($r['status'])?></td></tr>
    <tr><th>Severity</th><td><?=severity_badge($r['severity'])?></td></tr>
    <tr><th>Observed</th><td class="mono"><?=e($r['actual_value'])?></td></tr>
    <tr><th>Expected</th><td class="mono"><?=e($r['expected_value'])?></td></tr>
  </table></div></div>
  <div class="card"><div class="card-head">Proposed Remediation</div><div class="card-body"><pre class="mono codebox"><?=e($r['remediation']??'No remediation text stored.')?></pre><div class="callout">No live device connection is used. Approval executes only the safe simulated re-audit workflow.</div></div></div>
</div>

<div class="card" style="margin-top:16px"><div class="card-head">1 · What-If Simulation</div><div class="card-body">
<?php if($baseRun): ?><p class="muted">Latest baseline audit: <strong>#<?=e($baseRun['audit_run_id'])?></strong> · <?=e($baseRun['compliance_pct'])?>% compliance.</p><?php else: ?><p class="muted">No baseline run is recorded yet. Run an audit first for the most useful comparison.</p><?php endif; ?>
<?php if($canManage && (!$workflow || !in_array($workflow['status'],['SIMULATED','PENDING_APPROVAL','APPROVED','RE_AUDITED'],true))): ?><form method="post" action="<?=e(url('findings/remediation_action.php'))?>"><?=csrf_field()?><input type="hidden" name="finding_id" value="<?=$findingId?>"><input type="hidden" name="action" value="simulate"><button class="btn btn-primary">Run What-If Simulation</button></form><?php endif; ?>
<?php if($workflow && $workflow['current_compliance']!==null): ?><div class="grid-4" style="margin-top:14px">
<div class="metric"><div class="num"><?=number_format((float)$workflow['current_compliance'],2)?>%</div><div class="label">Current</div></div>
<div class="metric"><div class="num"><?=number_format((float)$workflow['projected_compliance'],2)?>%</div><div class="label">Projected</div></div>
<div class="metric"><div class="num">NO</div><div class="label">Device Modified</div></div>
<div class="metric"><div class="num"><?=e($workflow['status'])?></div><div class="label">Workflow State</div></div>
</div><?php endif; ?>
<?php if($simResults): ?><div class="card" style="margin-top:14px"><div class="card-head">Simulated Control Evaluation</div><div class="card-body table-wrap"><table><tr><th>Control</th><th>Status</th><th>Actual (Simulated)</th><th>Expected</th></tr><?php foreach($simResults as $sr): $ctrl=$sr['control']??[]; ?><tr><td><?=e($ctrl['control_code']??'')?></td><td><?=status_badge($sr['status']??'')?></td><td class="mono"><?=e(is_scalar($sr['actual']??null)?(string)($sr['actual']??''):json_encode($sr['actual']??null))?></td><td class="mono"><?=e($ctrl['expected_value']??'')?></td></tr><?php endforeach; ?></table></div></div><?php endif; ?>
</div></div>

<div class="card" style="margin-top:16px"><div class="card-head">2 · Human Approval</div><div class="card-body">
<?php if($workflow): ?><p><strong>Status:</strong> <?=e($workflow['status'])?> <?php if($workflow['approved_by']): ?>· Approved by <?=e($workflow['approved_by'])?><?php endif; ?></p><?php endif; ?>
<?php if($canManage && $workflow && $workflow['status']==='SIMULATED'): ?>
<div class="actions"><form method="post" action="<?=e(url('findings/remediation_action.php'))?>"><?=csrf_field()?><input type="hidden" name="finding_id" value="<?=$findingId?>"><input type="hidden" name="action" value="request_approval"><button class="btn">Submit for Approval</button></form></div>
<?php elseif($canManage && $workflow && $workflow['status']==='PENDING_APPROVAL'): ?>
<div class="actions"><form method="post" action="<?=e(url('findings/remediation_action.php'))?>"><?=csrf_field()?><input type="hidden" name="finding_id" value="<?=$findingId?>"><input type="hidden" name="action" value="approve"><button class="btn btn-success">Approve & Run Safe Re-Audit</button></form>
<form method="post" action="<?=e(url('findings/remediation_action.php'))?>"><?=csrf_field()?><input type="hidden" name="finding_id" value="<?=$findingId?>"><input type="hidden" name="action" value="reject"><input type="hidden" name="reason" value="Reviewer rejected the proposed change."><button class="btn">Reject</button></form></div>
<?php endif; ?>
<p class="muted">Approval does not connect to a network device in this prototype. It applies the proposed value only to the in-memory simulation snapshot and then runs the compliance engine against that corrected model.</p>
</div></div>

<?php if($reRun): ?><div class="card" style="margin-top:16px"><div class="card-head">3 · Re-Audit Result</div><div class="card-body"><div class="grid-4"><div class="metric"><div class="num">#<?=e($reRun['audit_run_id'])?></div><div class="label">Re-Audit</div></div><div class="metric"><div class="num"><?=e($reRun['compliance_pct'])?>%</div><div class="label">Compliance</div></div><div class="metric"><div class="num"><?=e($reRun['pass_count'])?></div><div class="label">Passed</div></div><div class="metric"><div class="num"><?=e($reRun['fail_count'])?></div><div class="label">Failed</div></div></div><div class="callout" style="margin-top:14px">Re-audit completed in safe simulation mode. See Evidence Ledger for the linked approval and re-audit events.</div></div></div><?php endif; ?>
<?php layout_footer(); ?>
