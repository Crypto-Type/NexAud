<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/../compliance/workflow.php';
requirePermission('findings.manage');
if($_SERVER['REQUEST_METHOD']!=='POST') render_error(405);
if(!verify_csrf()) render_error(403);
$id=(int)($_POST['finding_id']??0); $action=(string)($_POST['action']??'');
try{
    if($action==='simulate'){
        $r=what_if_simulate($id);
        flash('success','What-If simulation completed. Current '.number_format((float)$r['current_compliance'],2).'%; projected '.number_format((float)$r['projected_compliance'],2).'%. No device changed.');
    }elseif($action==='request_approval'){
        $r=what_if_simulate($id);
        getDB()->prepare('UPDATE remediation_requests SET status=\'PENDING_APPROVAL\' WHERE remediation_request_id=?')->execute([(int)$r['remediation_request_id']]);
        flash('success','Remediation submitted for human approval.');
    }elseif($action==='approve'){
        $r=approve_and_reaudit($id);
        flash('success','Approved remediation workflow completed in safe simulation mode. Re-audit #'.$r['audit_run_id'].' finished at '.$r['stats']['compliance_pct'].'%.');
    }elseif($action==='reject'){
        reject_remediation($id,trim((string)($_POST['reason']??'Rejected by reviewer')));
        flash('success','Remediation request rejected.');
    }else{render_error(422,'Unknown action','Unsupported remediation workflow action.');}
    redirect_to('findings/remediation.php?id='.$id);
}catch(Throwable $e){flash('error',$e->getMessage());redirect_to('findings/remediation.php?id='.$id);}
