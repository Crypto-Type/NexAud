<?php
declare(strict_types=1);
require_once __DIR__.'/FindingManager.php';
require_once __DIR__.'/../ai/AuditAI.php';
requirePermission('findings.view');
$findingId=(int)($_GET['id']??0);
$r=(new FindingManager())->get($findingId);
if(!$r) render_error(404);
$ai=(new NexAudAuditAI())->analyzeFinding($findingId);
layout_header('Finding #'.$r['finding_id'],'findings');
?>
<div class="page-head">
  <div><h1 class="page-title">Finding #<?=e($r['finding_id'])?></h1><p class="page-sub"><?=e($r['control_code'])?> · <?=e($r['device_name']??'Device')?></p></div>
  <div class="actions"><a class="btn" href="<?=e(url('ai/index.php'))?>">Ask AI Copilot</a><a class="btn btn-primary" href="<?=e(url('findings/remediation.php?id='.$r['finding_id']))?>">Remediation</a></div>
</div>
<div class="grid-2">
  <div class="card"><div class="card-head">Finding Details</div><div class="card-body"><table>
    <tr><th>Status</th><td><?=status_badge($r['status'])?></td></tr>
    <tr><th>Severity</th><td><?=severity_badge($r['severity'])?></td></tr>
    <tr><th>Actual</th><td class="mono"><?=e($r['actual_value'])?></td></tr>
    <tr><th>Expected</th><td class="mono"><?=e($r['expected_value'])?></td></tr>
    <tr><th>Evidence</th><td><?=e($r['evidence'])?></td></tr>
  </table></div></div>
  <div class="card"><div class="card-head">Rule Explanation</div><div class="card-body"><p><?=e($r['description']??'The normalized parameter was evaluated against the control rule.')?></p><div class="small muted">Normalized parameter</div><div class="mono codebox"><?=e($r['parameter']??'')?></div><h3>Remediation</h3><pre class="mono codebox"><?=e($r['remediation'])?></pre></div></div>
</div>
<div class="card" style="margin-top:16px;border-left:4px solid currentColor">
  <div class="card-head">✦ AI Audit Analysis <span class="muted">Decision support based on live NexAud records</span></div>
  <div class="card-body">
    <?php if(!empty($ai['ok'])): ?>
      <div class="callout"><strong>AI assessment:</strong> <?=e($ai['answer'])?></div>
      <div class="grid-4" style="margin-top:14px">
        <div class="metric"><div class="num"><?=e((string)$ai['confidence'])?>%</div><div class="label">AI Confidence</div></div>
        <div class="metric"><div class="num"><?=e($ai['risk']['level']??$r['severity'])?></div><div class="label">Risk Level</div></div>
        <div class="metric"><div class="num">NO</div><div class="label">Live Device Changed</div></div>
        <div class="metric"><div class="num">RE-AUDIT</div><div class="label">Validation Path</div></div>
      </div>
      <div class="grid-2" style="margin-top:14px">
        <div><h3>Recommended Remediation</h3><p><?=e($ai['remediation']['summary']??'')?></p><div class="mono codebox">Before: <?=e($ai['remediation']['before']??'')?><br>After: <?=e($ai['remediation']['after']??'')?></div></div>
        <div><h3>AI Validation Plan</h3><p><?=e($ai['validation']['summary']??'')?></p><ol><?php foreach(($ai['validation']['steps']??[]) as $step): ?><li><?=e($step)?></li><?php endforeach; ?></ol></div>
      </div>
      <div style="margin-top:14px"><h3>Evidence Used</h3><p class="small muted">Configuration: <?=e($ai['evidence']['configuration']??'')?> · SHA-256: <span class="mono"><?=e($ai['evidence']['sha256']??'')?></span> · Source line: <?=e($ai['evidence']['source_line']??'')?></p></div>
    <?php else: ?><div class="callout">AI analysis could not be generated for this finding.</div><?php endif; ?>
  </div>
</div>
<?php layout_footer(); ?>
