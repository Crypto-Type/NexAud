-- NexAud V7 workflow upgrade: remediation approval, what-if, re-audit,
-- evidence lifecycle events and report history.
SET NAMES utf8mb4;

ALTER TABLE evidence_ledger
  MODIFY event_type ENUM(
    'GENESIS',
    'CONFIGURATION_INGESTED',
    'AUDIT_STARTED',
    'AUDIT_COMPLETED',
    'FINDING_RECORDED',
    'WHATIF_SIMULATED',
    'REMEDIATION_CREATED',
    'REMEDIATION_APPROVED',
    'REMEDIATION_REJECTED',
    'RE_AUDIT_COMPLETED',
    'REPORT_GENERATED',
    'FRAMEWORK_CREATED',
    'CONTROL_CREATED',
    'CONTROL_UPDATED',
    'POLICY_CREATED',
    'POLICY_UPDATED'
  ) NOT NULL;

CREATE TABLE IF NOT EXISTS audit_runs (
    audit_run_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    configuration_id INT UNSIGNED NOT NULL,
    mode ENUM('BASELINE','WHAT_IF','RE_AUDIT') NOT NULL DEFAULT 'BASELINE',
    remediation_request_id BIGINT UNSIGNED NULL,
    status ENUM('RUNNING','COMPLETED','FAILED') NOT NULL DEFAULT 'RUNNING',
    started_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    completed_at DATETIME(6) NULL,
    total_controls INT UNSIGNED NOT NULL DEFAULT 0,
    pass_count INT UNSIGNED NOT NULL DEFAULT 0,
    fail_count INT UNSIGNED NOT NULL DEFAULT 0,
    manual_count INT UNSIGNED NOT NULL DEFAULT 0,
    compliance_pct DECIMAL(6,2) NOT NULL DEFAULT 0,
    triggered_by VARCHAR(100) NOT NULL DEFAULT 'SYSTEM',
    error_message TEXT NULL,
    KEY idx_audit_runs_configuration (configuration_id),
    KEY idx_audit_runs_status (status),
    KEY idx_audit_runs_mode (mode),
    KEY idx_audit_runs_created (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE findings
  ADD COLUMN audit_run_id BIGINT UNSIGNED NULL,
  ADD KEY idx_finding_audit_run (audit_run_id);

CREATE TABLE IF NOT EXISTS remediation_requests (
    remediation_request_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    finding_id BIGINT UNSIGNED NOT NULL,
    device_id VARCHAR(64) NOT NULL,
    configuration_id VARCHAR(64) NOT NULL,
    proposed_value TEXT NULL,
    remediation_text TEXT NULL,
    status ENUM('DRAFT','SIMULATED','PENDING_APPROVAL','APPROVED','REJECTED','RE_AUDITED','FAILED') NOT NULL DEFAULT 'DRAFT',
    current_compliance DECIMAL(6,2) NULL,
    projected_compliance DECIMAL(6,2) NULL,
    simulated_result_json LONGTEXT NULL,
    simulated_normalized_json LONGTEXT NULL,
    simulation_notes TEXT NULL,
    created_by VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    approved_by VARCHAR(100) NULL,
    approved_at DATETIME(6) NULL,
    rejected_by VARCHAR(100) NULL,
    rejected_at DATETIME(6) NULL,
    applied_at DATETIME(6) NULL,
    reaudited_at DATETIME(6) NULL,
    re_audit_run_id BIGINT UNSIGNED NULL,
    KEY idx_remediation_finding (finding_id),
    KEY idx_remediation_status (status),
    KEY idx_remediation_created (created_at),
    CONSTRAINT fk_remediation_finding FOREIGN KEY (finding_id)
      REFERENCES findings(finding_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS report_runs (
    report_run_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    configuration_id INT UNSIGNED NOT NULL,
    audit_run_id BIGINT UNSIGNED NULL,
    format ENUM('HTML','PDF') NOT NULL DEFAULT 'HTML',
    file_path VARCHAR(500) NULL,
    report_hash CHAR(64) NULL,
    generated_by VARCHAR(100) NOT NULL,
    generated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    KEY idx_report_configuration (configuration_id),
    KEY idx_report_generated (generated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
