-- ============================================================================
-- NexAud - Built-in Framework Seed Data
--
-- IMPORTANT / COMPLIANCE DISCLAIMER:
-- These are "Prototype Representative Controls" only. They illustrate the
-- SHAPE of CIS, NIST, STIG, and ISO 27001-aligned network hardening checks
-- and are NOT a complete, certified, or authoritative implementation of any
-- of these standards. Do not represent a device or organization as
-- "CIS certified" or "STIG compliant" based solely on these prototype
-- controls. Extend coverage using the Custom Policy Builder or JSON import
-- before using this for real compliance attestation.
-- ============================================================================

INSERT IGNORE INTO frameworks (name, description, version, organization, framework_type, status, created_by) VALUES
('CIS Network Device Benchmark (Prototype Representative Controls)',
 'Representative subset of CIS-style network hardening checks. NOT a complete or certified CIS Benchmark implementation.',
 '1.0-prototype', 'NexAud', 'BUILTIN', 'ACTIVE', 'system_seed'),
('NIST SP 800-53 Network Controls (Prototype Representative Controls)',
 'Representative subset of NIST 800-53 control-family-aligned checks (AC, IA, SC families). NOT complete NIST 800-53 coverage.',
 '1.0-prototype', 'NexAud', 'BUILTIN', 'ACTIVE', 'system_seed'),
('DISA STIG Network Baseline (Prototype Representative Controls)',
 'Representative subset of DISA STIG-style network device findings. NOT a complete or certified STIG checklist.',
 '1.0-prototype', 'NexAud', 'BUILTIN', 'ACTIVE', 'system_seed'),
('ISO/IEC 27001 Annex A Network Controls (Prototype Representative Controls)',
 'Representative subset of ISO 27001 Annex A technical control checks relevant to network devices. NOT a complete ISMS or certification claim.',
 '1.0-prototype', 'NexAud', 'BUILTIN', 'ACTIVE', 'system_seed');

-- Fetch the framework_ids we just inserted for use below (portable approach:
-- use a session variable per framework via subselects on the unique name).

-- ---- CIS (prototype) ----
INSERT IGNORE INTO controls (framework_id, control_code, title, description, category, severity, vendor, device_type, parameter, operator, expected_value, evidence_requirement, remediation, enabled, created_by)
SELECT framework_id, 'CIS-1.1.1', 'Disable Telnet for remote management', 'Cleartext remote management protocols must not be used.', 'Remote Access', 'CRITICAL', 'ANY', 'ANY', 'remote_access.telnet.enabled', 'equals', 'false', 'Running-config VTY transport input line.', 'Disable Telnet; use SSH only.', 1, 'system_seed'
FROM frameworks WHERE name LIKE 'CIS Network Device Benchmark%' LIMIT 1;

INSERT IGNORE INTO controls (framework_id, control_code, title, description, category, severity, vendor, device_type, parameter, operator, expected_value, evidence_requirement, remediation, enabled, created_by)
SELECT framework_id, 'CIS-1.1.2', 'Enable SSH version 2', 'SSHv1 has known cryptographic weaknesses.', 'Remote Access', 'HIGH', 'ANY', 'ANY', 'remote_access.ssh.version', 'equals', '2', 'Running-config `ip ssh version 2` (or vendor equivalent).', 'Force SSH protocol version 2.', 1, 'system_seed'
FROM frameworks WHERE name LIKE 'CIS Network Device Benchmark%' LIMIT 1;

INSERT IGNORE INTO controls (framework_id, control_code, title, description, category, severity, vendor, device_type, parameter, operator, expected_value, evidence_requirement, remediation, enabled, created_by)
SELECT framework_id, 'CIS-2.1.1', 'Disable unused HTTP management service', 'Unencrypted web management interfaces expose credentials.', 'Services', 'HIGH', 'ANY', 'ANY', 'services.http.enabled', 'equals', 'false', 'Running-config `ip http server` state.', 'Disable HTTP; use HTTPS only if a GUI is required.', 1, 'system_seed'
FROM frameworks WHERE name LIKE 'CIS Network Device Benchmark%' LIMIT 1;

-- ---- NIST (prototype) ----
INSERT IGNORE INTO controls (framework_id, control_code, title, description, category, severity, vendor, device_type, parameter, operator, expected_value, evidence_requirement, remediation, enabled, created_by)
SELECT framework_id, 'NIST-IA-5', 'Minimum password length enforced', 'Aligned with NIST 800-53 IA-5 (Authenticator Management).', 'Authentication', 'MEDIUM', 'ANY', 'ANY', 'password_policy.min_length', 'greater_than', '11', 'Local/AAA password policy configuration.', 'Set minimum password length to 12+.', 1, 'system_seed'
FROM frameworks WHERE name LIKE 'NIST SP 800-53%' LIMIT 1;

INSERT IGNORE INTO controls (framework_id, control_code, title, description, category, severity, vendor, device_type, parameter, operator, expected_value, evidence_requirement, remediation, enabled, created_by)
SELECT framework_id, 'NIST-AC-17', 'Remote access requires encrypted session', 'Aligned with NIST 800-53 AC-17 (Remote Access).', 'Remote Access', 'CRITICAL', 'ANY', 'ANY', 'remote_access.telnet.enabled', 'disabled', '', 'VTY transport input configuration.', 'Disable cleartext remote access protocols.', 1, 'system_seed'
FROM frameworks WHERE name LIKE 'NIST SP 800-53%' LIMIT 1;

INSERT IGNORE INTO controls (framework_id, control_code, title, description, category, severity, vendor, device_type, parameter, operator, expected_value, evidence_requirement, remediation, enabled, created_by)
SELECT framework_id, 'NIST-SC-8', 'NTP time source configured for audit correlation', 'Aligned with NIST 800-53 SC-8 / AU-8 (time stamps depend on synchronized clocks).', 'Logging & Time Sync', 'LOW', 'ANY', 'ANY', 'ntp.server', 'exists', '', 'Running-config `ntp server` statement.', 'Configure an authoritative NTP source.', 1, 'system_seed'
FROM frameworks WHERE name LIKE 'NIST SP 800-53%' LIMIT 1;

-- ---- STIG (prototype) ----
INSERT IGNORE INTO controls (framework_id, control_code, title, description, category, severity, vendor, device_type, parameter, operator, expected_value, evidence_requirement, remediation, enabled, created_by)
SELECT framework_id, 'STIG-NET-0205', 'Login banner must display DoD/organizational warning', 'Representative of DISA STIG banner-of-the-day findings.', 'Governance', 'MEDIUM', 'ANY', 'ANY', 'banner.motd', 'contains', 'Authorized', 'Configured MOTD/login banner text.', 'Configure an approved legal warning banner.', 1, 'system_seed'
FROM frameworks WHERE name LIKE 'DISA STIG Network Baseline%' LIMIT 1;

INSERT IGNORE INTO controls (framework_id, control_code, title, description, category, severity, vendor, device_type, parameter, operator, expected_value, evidence_requirement, remediation, enabled, created_by)
SELECT framework_id, 'STIG-NET-0812', 'SNMP must not use default/public community strings', 'Representative of DISA STIG SNMP hardening findings.', 'Services', 'CRITICAL', 'ANY', 'ANY', 'snmp.community_string', 'not_equals', 'public', 'Running-config SNMP community configuration.', 'Remove default community strings; use SNMPv3.', 1, 'system_seed'
FROM frameworks WHERE name LIKE 'DISA STIG Network Baseline%' LIMIT 1;

-- ---- ISO 27001 (prototype) ----
INSERT IGNORE INTO controls (framework_id, control_code, title, description, category, severity, vendor, device_type, parameter, operator, expected_value, evidence_requirement, remediation, enabled, created_by)
SELECT framework_id, 'ISO-A.8.20', 'Network access control - unused services disabled', 'Aligned with ISO 27001 Annex A 8.20 (Networks security).', 'Services', 'HIGH', 'ANY', 'ANY', 'services.http.enabled', 'disabled', '', 'Running-config service state.', 'Disable unused network services.', 1, 'system_seed'
FROM frameworks WHERE name LIKE 'ISO/IEC 27001%' LIMIT 1;

INSERT IGNORE INTO controls (framework_id, control_code, title, description, category, severity, vendor, device_type, parameter, operator, expected_value, evidence_requirement, remediation, enabled, created_by)
SELECT framework_id, 'ISO-A.8.24', 'Cryptographic remote access in use', 'Aligned with ISO 27001 Annex A 8.24 (Use of cryptography).', 'Remote Access', 'CRITICAL', 'ANY', 'ANY', 'remote_access.ssh.enabled', 'enabled', '', 'Running-config SSH server status.', 'Enable SSH for all administrative access.', 1, 'system_seed'
FROM frameworks WHERE name LIKE 'ISO/IEC 27001%' LIMIT 1;
