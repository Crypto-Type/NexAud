USE `nexaud`;
SET FOREIGN_KEY_CHECKS=0;

-- NexAud canonical database schema
-- MySQL/MariaDB
-- Run this file first on a fresh `nexaud` database.


-- =====================================================================
-- NexAud - Next Gen Network Security Auditor
-- Database Schema (foundation)
-- Engine: InnoDB | Charset: utf8mb4
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- roles
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `roles` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(50)  NOT NULL,
  `description` VARCHAR(255) NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- permissions
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `permissions` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `permission_key` VARCHAR(100) NOT NULL,
  `description`    VARCHAR(255) NULL,
  `created_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_permissions_key` (`permission_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- role_permissions (many-to-many)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `role_permissions` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id`       BIGINT UNSIGNED NOT NULL,
  `permission_id` BIGINT UNSIGNED NOT NULL,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_permission` (`role_id`, `permission_id`),
  KEY `idx_role_permissions_role` (`role_id`),
  KEY `idx_role_permissions_permission` (`permission_id`),
  CONSTRAINT `fk_role_permissions_role`
    FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_role_permissions_permission`
    FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- users
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`       VARCHAR(64)  NOT NULL,
  `email`          VARCHAR(190) NOT NULL,
  `full_name`      VARCHAR(120) NOT NULL,
  `password_hash`  VARCHAR(255) NOT NULL,
  `role`           VARCHAR(50)  NOT NULL DEFAULT 'VIEWER',
  `status`         ENUM('active','disabled','pending') NOT NULL DEFAULT 'active',
  `last_login_at`  DATETIME NULL,
  `created_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `idx_users_role` (`role`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role`) REFERENCES `roles` (`name`)
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- user_preferences
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `user_preferences` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    BIGINT UNSIGNED NOT NULL,
  `pref_key`   VARCHAR(100) NOT NULL,
  `pref_value` VARCHAR(255) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_pref` (`user_id`, `pref_key`),
  CONSTRAINT `fk_user_preferences_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- system_settings
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `system_settings` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key`  VARCHAR(100) NOT NULL,
  `setting_value` TEXT NULL,
  `updated_by`   BIGINT UNSIGNED NULL,
  `created_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_system_settings_key` (`setting_key`),
  CONSTRAINT `fk_system_settings_user`
    FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- login_attempts (brute-force throttling)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `identifier`   VARCHAR(190) NOT NULL,
  `ip_address`   VARCHAR(45) NOT NULL,
  `success`      TINYINT(1) NOT NULL DEFAULT 0,
  `attempted_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_login_attempts_identifier_time` (`identifier`, `attempted_at`),
  KEY `idx_login_attempts_ip_time` (`ip_address`, `attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- audit_logs (foundation-level audit trail)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    BIGINT UNSIGNED NULL,
  `action`     VARCHAR(100) NOT NULL,
  `category`   VARCHAR(50)  NOT NULL,
  `target_id`  BIGINT UNSIGNED NULL,
  `metadata`   JSON NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` VARCHAR(255) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_logs_user` (`user_id`),
  KEY `idx_audit_logs_category` (`category`),
  KEY `idx_audit_logs_created` (`created_at`),
  CONSTRAINT `fk_audit_logs_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- NexAud Module 2 — Database schema
-- Engine: MySQL / MariaDB
-- These tables are additive only. They do not touch any table owned by
-- the foundation (users, sessions, roles, etc). Foreign keys to a `users`
-- table are deliberately soft (uploaded_by stored as VARCHAR username
-- snapshot + nullable user id) so this module does not need to know the
-- foundation's exact users schema to be installed.

CREATE TABLE IF NOT EXISTS devices (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_name     VARCHAR(128)  NOT NULL,
    vendor          VARCHAR(64)   NOT NULL,
    model           VARCHAR(128)  NULL,
    os_version      VARCHAR(128)  NULL,
    serial_number   VARCHAR(128)  NULL,
    management_ip   VARCHAR(64)   NOT NULL,
    device_type     VARCHAR(64)   NOT NULL,
    location        VARCHAR(128)  NULL,
    environment     VARCHAR(32)   NOT NULL DEFAULT 'production',
    owner           VARCHAR(128)  NULL,
    status          VARCHAR(32)   NOT NULL DEFAULT 'active',
    created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                                  ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_devices_vendor (vendor),
    INDEX idx_devices_type (device_type),
    INDEX idx_devices_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS configurations (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_id           INT UNSIGNED NOT NULL,
    original_filename   VARCHAR(255) NOT NULL,   -- untrusted, display-only, never used for storage/exec
    stored_filename     VARCHAR(128) NOT NULL,   -- randomized, safe on-disk name
    storage_path        VARCHAR(255) NOT NULL,   -- relative path under configurations/storage/
    detected_vendor     VARCHAR(64)  NULL,
    detected_confidence DECIMAL(4,3) NULL,
    detected_device_type VARCHAR(64) NULL,
    file_size_bytes     INT UNSIGNED NOT NULL,
    sha256_hash         CHAR(64)     NOT NULL,
    version             INT UNSIGNED NOT NULL DEFAULT 1,
    uploaded_by_id      INT UNSIGNED NULL,
    uploaded_by_name    VARCHAR(128) NOT NULL,
    upload_time         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ingest_status       ENUM('pending','parsed','failed') NOT NULL DEFAULT 'pending',
    ingest_error        TEXT NULL,
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE RESTRICT,
    INDEX idx_config_device (device_id),
    INDEX idx_config_hash (sha256_hash),
    UNIQUE KEY uq_device_version (device_id, version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One normalization result per configuration (1:1). Kept as a separate
-- table (rather than a column on `configurations`) so re-normalizing after
-- a mapping-rule update doesn't rewrite ingestion metadata, and so the
-- compliance engine can join cleanly.
CREATE TABLE IF NOT EXISTS normalized_configurations (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    configuration_id    INT UNSIGNED NOT NULL,
    schema_version      VARCHAR(16)  NOT NULL DEFAULT '1.0',
    normalized_json      LONGTEXT     NOT NULL,   -- full NexAud Security Configuration Schema document
    unrecognized_json    LONGTEXT     NULL,        -- only populated for Unknown vendor / partial parses
    created_at          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (configuration_id) REFERENCES configurations(id) ON DELETE CASCADE,
    UNIQUE KEY uq_config_normalized (configuration_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- ============================================================================
-- NexAud - Compliance & Evidence Subsystem
-- Database Schema
-- Engine: MySQL/MariaDB (InnoDB, utf8mb4)
-- Owned tables: frameworks, controls, findings, evidence_ledger
-- NOTE: `devices` and `configurations` tables are assumed to be owned by
-- other subsystems (device management / parsers). We reference their
-- primary keys (device_id, configuration_id) as opaque VARCHAR ids and do
-- NOT declare cross-module foreign keys here, to avoid coupling to schemas
-- we do not own.
-- ============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------------------------------------------------------
-- frameworks
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS frameworks (
    framework_id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name             VARCHAR(150)      NOT NULL,
    description      TEXT              NULL,
    version          VARCHAR(30)       NOT NULL DEFAULT '1.0',
    organization     VARCHAR(150)      NULL,
    -- BUILTIN = representative CIS/NIST/STIG/ISO27001 seed sets (protected).
    -- CUSTOM  = org-defined frameworks created through the Policy Builder.
    framework_type   ENUM('BUILTIN','CUSTOM') NOT NULL DEFAULT 'CUSTOM',
    status           ENUM('DRAFT','ACTIVE','DEPRECATED') NOT NULL DEFAULT 'DRAFT',
    created_by       VARCHAR(100)      NOT NULL,
    created_at       DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_framework_name_version (name, version),
    KEY idx_framework_status (status),
    KEY idx_framework_type (framework_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- controls
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS controls (
    control_id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    framework_id         INT UNSIGNED NOT NULL,
    control_code         VARCHAR(60)  NOT NULL,          -- e.g. ORG-NET-001
    title                VARCHAR(255) NOT NULL,
    description          TEXT NULL,
    category             VARCHAR(100) NULL,              -- e.g. Remote Access
    severity             ENUM('CRITICAL','HIGH','MEDIUM','LOW','INFO') NOT NULL DEFAULT 'MEDIUM',
    vendor               VARCHAR(60)  NOT NULL DEFAULT 'ANY',
    device_type          VARCHAR(60)  NOT NULL DEFAULT 'ANY',
    parameter            VARCHAR(255) NOT NULL,          -- dotted path into normalized config
    operator             ENUM(
                             'equals','not_equals','contains','not_contains',
                             'greater_than','less_than','exists','not_exists',
                             'enabled','disabled'
                         ) NOT NULL,
    expected_value       VARCHAR(500) NULL,
    evidence_requirement TEXT NULL,
    remediation          TEXT NULL,
    enabled              TINYINT(1) NOT NULL DEFAULT 1,
    created_by           VARCHAR(100) NOT NULL,
    created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_control_framework FOREIGN KEY (framework_id)
        REFERENCES frameworks(framework_id) ON DELETE CASCADE,
    UNIQUE KEY uq_framework_control_code (framework_id, control_code),
    KEY idx_control_enabled (enabled),
    KEY idx_control_severity (severity),
    KEY idx_control_vendor_devicetype (vendor, device_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- findings
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS findings (
    finding_id       BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_id        VARCHAR(64)  NOT NULL,   -- opaque FK into device-management module
    configuration_id VARCHAR(64)  NOT NULL,   -- opaque FK into parser/config module
    control_id       INT UNSIGNED NOT NULL,
    status           ENUM('PASS','FAIL','MANUAL_REVIEW','NOT_APPLICABLE') NOT NULL,
    severity         ENUM('CRITICAL','HIGH','MEDIUM','LOW','INFO') NOT NULL,
    actual_value     TEXT NULL,
    expected_value   TEXT NULL,
    evidence         TEXT NULL,
    raw_evidence     MEDIUMTEXT NULL,
    source_line      VARCHAR(255) NULL,
    remediation      TEXT NULL,
    created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_finding_control FOREIGN KEY (control_id)
        REFERENCES controls(control_id) ON DELETE RESTRICT,
    KEY idx_finding_device (device_id),
    KEY idx_finding_configuration (configuration_id),
    KEY idx_finding_status (status),
    KEY idx_finding_severity (severity),
    KEY idx_finding_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- evidence_ledger  (append-only, hash-chained)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS evidence_ledger (
    block_id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sequence_number      BIGINT UNSIGNED NOT NULL,
    event_type           ENUM('GENESIS','FINDING_RECORDED','FRAMEWORK_CREATED',
                               'CONTROL_CREATED','CONTROL_UPDATED') NOT NULL,
    device_id            VARCHAR(64) NULL,
    configuration_id     VARCHAR(64) NULL,
    finding_id           BIGINT UNSIGNED NULL,
    config_hash          CHAR(64) NULL,      -- SHA-256 of the raw configuration (hex)
    evidence_hash        CHAR(64) NOT NULL,  -- SHA-256 of canonicalized evidence payload (hex)
    previous_block_hash  CHAR(64) NOT NULL,  -- hex; genesis uses a fixed constant
    timestamp            DATETIME(6) NOT NULL,
    created_by           VARCHAR(100) NOT NULL,
    block_hash           CHAR(64) NOT NULL,  -- SHA-256 over canonicalized block incl. previous_block_hash
    UNIQUE KEY uq_sequence (sequence_number),
    UNIQUE KEY uq_block_hash (block_hash),
    KEY idx_ledger_finding (finding_id),
    KEY idx_ledger_device (device_id),
    KEY idx_ledger_event_type (event_type),
    CONSTRAINT fk_ledger_finding FOREIGN KEY (finding_id)
        REFERENCES findings(finding_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Enforce append-only at the DB privilege level in production (adjust user/host):
-- REVOKE UPDATE, DELETE ON nexaud.evidence_ledger FROM 'nexaud_app'@'localhost';
-- GRANT SELECT, INSERT ON nexaud.evidence_ledger TO 'nexaud_app'@'localhost';

-- NexAud AI Layer — database schema
-- Only tables owned by the AI/training/reports layer. Does not touch
-- existing devices/parsers/normalization/compliance/evidence tables —
-- those are referenced by ID only (device_id, audit_id, finding_id,
-- control_id) and are assumed to already exist.

CREATE TABLE IF NOT EXISTS ai_unknown_commands (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_id BIGINT UNSIGNED NULL,
    audit_id BIGINT UNSIGNED NULL,
    vendor_hint VARCHAR(100) NULL,
    raw_command TEXT NOT NULL,
    status ENUM('pending','analyzed','approved','rejected') NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_device (device_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ai_suggestions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    unknown_command_id BIGINT UNSIGNED NOT NULL,
    suggested_parameter VARCHAR(255) NOT NULL,
    suggested_value VARCHAR(255) NOT NULL,
    confidence DECIMAL(4,3) NOT NULL DEFAULT 0.000,
    reason TEXT NULL,
    affected_controls VARCHAR(500) NULL,
    provider VARCHAR(100) NULL,
    raw_model_output MEDIUMTEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (unknown_command_id) REFERENCES ai_unknown_commands(id) ON DELETE CASCADE,
    INDEX idx_uc (unknown_command_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ai_mappings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    vendor_hint VARCHAR(100) NULL,
    command_pattern TEXT NOT NULL,
    normalized_parameter VARCHAR(255) NOT NULL,
    normalized_value VARCHAR(255) NOT NULL,
    confidence DECIMAL(4,3) NOT NULL DEFAULT 0.000,
    source_suggestion_id BIGINT UNSIGNED NULL,
    status ENUM('pending_review','approved','rejected') NOT NULL DEFAULT 'pending_review',
    reviewed_by BIGINT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    review_notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_vendor (vendor_hint)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ai_query_log (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NULL,
    action VARCHAR(50) NOT NULL,
    question TEXT NULL,
    provider VARCHAR(100) NULL,
    success TINYINT(1) NOT NULL DEFAULT 0,
    latency_ms INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ai_reports (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    audit_id BIGINT UNSIGNED NULL,
    device_id BIGINT UNSIGNED NULL,
    framework_id BIGINT UNSIGNED NULL,
    report_type ENUM('executive','technical','device','framework','finding') NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    generated_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_type (report_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS=1;
