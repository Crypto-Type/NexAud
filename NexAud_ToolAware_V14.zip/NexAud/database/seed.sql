USE `nexaud`;
INSERT IGNORE INTO roles(name,description) VALUES
('ADMIN','Full system access'),('AUDITOR','Runs audits and reports'),('SECURITY_ENGINEER','Manages devices and remediation'),('VIEWER','Read-only access');
INSERT IGNORE INTO permissions(permission_key,description) VALUES
('dashboard.view','View dashboard'),('devices.view','View devices'),('devices.manage','Manage devices'),('configurations.view','View configurations'),('configurations.manage','Upload configurations'),('audits.view','View audits'),('audits.run','Run audits'),('findings.view','View findings'),('findings.manage','Manage findings'),('compliance.view','View frameworks'),('compliance.manage','Manage frameworks'),('controls.view','View controls'),('controls.manage','Manage controls'),('policies.view','View policies'),('policies.manage','Manage policies'),('ai.use','Use AI'),('training.view','View training'),('training.manage','Manage training'),('evidence.view','View evidence'),('evidence.verify','Verify evidence'),('reports.view','View reports'),('reports.generate','Generate reports'),('users.manage','Manage users'),('settings.manage','Manage settings'),('audit_logs.view','View audit logs');
INSERT IGNORE INTO role_permissions(role_id,permission_id) SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name='ADMIN';
INSERT IGNORE INTO role_permissions(role_id,permission_id) SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name='AUDITOR' AND p.permission_key IN('dashboard.view','audits.view','audits.run','configurations.view','compliance.view','compliance.manage','controls.view','findings.view','reports.view','reports.generate','evidence.view','evidence.verify');
INSERT IGNORE INTO role_permissions(role_id,permission_id) SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name='SECURITY_ENGINEER' AND p.permission_key IN('dashboard.view','devices.view','devices.manage','configurations.view','configurations.manage','audits.view','audits.run','findings.view','findings.manage','ai.use','training.view','training.manage','evidence.view');
INSERT IGNORE INTO role_permissions(role_id,permission_id) SELECT r.id,p.id FROM roles r JOIN permissions p WHERE r.name='VIEWER' AND p.permission_key IN('dashboard.view','reports.view','compliance.view','findings.view');
INSERT INTO users(username,email,full_name,password_hash,role,status) VALUES
('admin','admin@nexaud.local','System Administrator','$2y$12$O9y9gmSsSR2jsxAXtxWtNerJ2AB4IkeckJSeuwzAXC8lke7fLcBHO','ADMIN','active'),
('auditor','auditor@nexaud.local','Compliance Auditor','$2y$12$O9y9gmSsSR2jsxAXtxWtNerJ2AB4IkeckJSeuwzAXC8lke7fLcBHO','AUDITOR','active'),
('secengineer','secengineer@nexaud.local','Security Engineer','$2y$12$O9y9gmSsSR2jsxAXtxWtNerJ2AB4IkeckJSeuwzAXC8lke7fLcBHO','SECURITY_ENGINEER','active'),
('viewer','viewer@nexaud.local','Read Only Viewer','$2y$12$O9y9gmSsSR2jsxAXtxWtNerJ2AB4IkeckJSeuwzAXC8lke7fLcBHO','VIEWER','active')
ON DUPLICATE KEY UPDATE username=VALUES(username),full_name=VALUES(full_name),role=VALUES(role),status='active';
INSERT INTO system_settings(setting_key,setting_value) VALUES('app_theme_default','dark') ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);
INSERT INTO system_settings(setting_key,setting_value) VALUES('org_name','NexAud') ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);
