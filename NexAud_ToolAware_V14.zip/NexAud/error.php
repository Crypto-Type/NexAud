<?php declare(strict_types=1); require_once __DIR__.'/includes/bootstrap.php'; $code=(int)($_GET['code']??404); render_error($code);
