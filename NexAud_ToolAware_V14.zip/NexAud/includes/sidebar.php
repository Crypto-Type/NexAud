<?php $active=$GLOBALS['page_active']??''; $u=current_user(); function navc($key,$active){return $key===$active?' active':'';} ?>
<aside class="sidebar" id="sidebar"><div class="side-nav">
<a class="nav-link<?=navc('dashboard',$active)?>" href="<?=e(url('dashboard.php'))?>">▣ <span>Dashboard</span></a>
<div class="nav-section">Security Operations</div>
<a class="nav-link<?=navc('devices',$active)?>" href="<?=e(url('devices/index.php'))?>">◈ <span>Devices</span></a>
<a class="nav-link<?=navc('configurations',$active)?>" href="<?=e(url('configurations/index.php'))?>">⬒ <span>Configurations</span></a>
<a class="nav-link<?=navc('analysis',$active)?>" href="<?=e(url('analysis/index.php'))?>">⌕ <span>Audits & Analysis</span></a>
<a class="nav-link<?=navc('findings',$active)?>" href="<?=e(url('findings/index.php'))?>">⚠ <span>Findings</span></a>
<div class="nav-section">Compliance</div>
<a class="nav-link<?=navc('compliance',$active)?>" href="<?=e(url('compliance/index.php'))?>">◉ <span>Frameworks</span></a>
<a class="nav-link<?=navc('controls',$active)?>" href="<?=e(url('controls/index.php'))?>">☷ <span>Controls</span></a>
<a class="nav-link" href="<?=e(url('compliance/custom-policies.php'))?>">✎ <span>Custom Policies</span></a>
<div class="nav-section">Intelligence</div>
<a class="nav-link<?=navc('ai',$active)?>" href="<?=e(url('ai/index.php'))?>">✦ <span>AI Copilot</span></a>
<a class="nav-link<?=navc('training',$active)?>" href="<?=e(url('training/index.php'))?>">⌬ <span>AI Training</span></a>
<div class="nav-section">Evidence & Reporting</div>
<a class="nav-link<?=navc('evidence',$active)?>" href="<?=e(url('evidence/index.php'))?>">▤ <span>Evidence Ledger</span></a>
<a class="nav-link<?=navc('reports',$active)?>" href="<?=e(url('reports/index.php'))?>">▥ <span>Reports</span></a>
<div class="nav-section">Administration</div>
<a class="nav-link<?=navc('admin-users',$active)?>" href="<?=e(url('admin/users.php'))?>">♙ <span>Users</span></a>
<a class="nav-link<?=navc('admin-settings',$active)?>" href="<?=e(url('admin/settings.php'))?>">⚙ <span>Settings</span></a>
<a class="nav-link<?=navc('admin-logs',$active)?>" href="<?=e(url('admin/audit-logs.php'))?>">≡ <span>Audit Logs</span></a>
</div><div class="side-foot">NexAud <?=e(APP_VERSION)?><br><span>Local / Human-approved workflows</span></div></aside>
