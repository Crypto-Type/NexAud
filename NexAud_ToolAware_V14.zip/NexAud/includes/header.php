<?php declare(strict_types=1); $pageTitle=$pageTitle??APP_NAME; $active=$GLOBALS['page_active']??''; $u=current_user(); ?>
<!doctype html><html lang="en" data-theme="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title><?=e($pageTitle)?> | <?=e(APP_NAME)?></title><link rel="icon" href="<?=e(asset('images/nexaud-logo.svg'))?>"><link rel="stylesheet" href="<?=e(asset('css/nexaud.css'))?>"></head><body>
<div class="app-shell">
<?php require NEXAUD_ROOT.'/includes/navbar.php'; ?>
<div class="app-body">
<?php if($u) require NEXAUD_ROOT.'/includes/sidebar.php'; ?>
<main class="main-content"><div class="content-wrap">
<?php if($m=flash('success')): ?><div class="alert success"><?=e($m)?></div><?php endif; ?>
<?php if($m=flash('error')): ?><div class="alert error"><?=e($m)?></div><?php endif; ?>
