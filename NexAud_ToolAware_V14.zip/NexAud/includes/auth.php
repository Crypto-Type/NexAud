<?php
declare(strict_types=1);
function is_logged_in(): bool { return !empty($_SESSION['user_id']); }
function current_user(): ?array { return $_SESSION['user']??null; }
function current_user_id(): ?int { return isset($_SESSION['user_id'])?(int)$_SESSION['user_id']:null; }
function current_role(): ?string { return $_SESSION['user']['role']??null; }
function requireAuth(): void { if(!is_logged_in()){ $_SESSION['redirect_after_login']=$_SERVER['REQUEST_URI']??url('dashboard.php'); redirect_to('login.php'); } }
function permissions_for_role(string $role): array { try{ $rows=db_all('SELECT p.permission_key FROM role_permissions rp JOIN roles r ON r.id=rp.role_id JOIN permissions p ON p.id=rp.permission_id WHERE r.name=?',[$role]); if($rows) return array_column($rows,'permission_key'); }catch(Throwable $e){} return NEXAUD_ROLE_DEFAULTS[$role]??[]; }
function hasPermission(string $permission): bool { $role=current_role(); if(!$role) return false; if($role===ROLE_ADMIN) return true; return in_array($permission,permissions_for_role($role),true); }
function requirePermission(string $permission): void { requireAuth(); if(!hasPermission($permission)){ audit_log(current_user_id(),'ACCESS_DENIED','authorization',null,['permission'=>$permission,'uri'=>$_SERVER['REQUEST_URI']??'']); render_error(403); } }
function requireRole(array|string $roles): void { requireAuth(); $roles=is_array($roles)?$roles:[$roles]; if(!in_array(current_role(),$roles,true)) render_error(403); }
function attempt_login(string $identifier,string $password): array { $identifier=trim($identifier); if($identifier===''||$password==='') return ['ok'=>false,'reason'=>'invalid']; try{ $u=db_one('SELECT id,username,email,full_name,password_hash,role,status FROM users WHERE username=? OR email=? LIMIT 1',[$identifier,$identifier]); if(!$u||$u['status']!=='active'||!password_verify($password,$u['password_hash'])){ audit_log($u['id']??null,'LOGIN_FAILED','authentication',null,['identifier'=>$identifier]); return ['ok'=>false,'reason'=>'invalid']; } unset($u['password_hash']); return ['ok'=>true,'user'=>$u]; }catch(Throwable $e){ return ['ok'=>false,'reason'=>'db']; } }
function establish_session(array $u): void { session_regenerate_id(true); $_SESSION['user_id']=(int)$u['id']; $_SESSION['user']=$u; $_SESSION['last_activity']=time(); try{getDB()->prepare('UPDATE users SET last_login_at=NOW() WHERE id=?')->execute([(int)$u['id']]);}catch(Throwable $e){} audit_log((int)$u['id'],'LOGIN_SUCCESS','authentication',(int)$u['id'],['username'=>$u['username']]); }
function destroy_session(): void { if(current_user_id()) audit_log(current_user_id(),'LOGOUT','authentication',current_user_id(),[]); $_SESSION=[]; if(ini_get('session.use_cookies')){ $p=session_get_cookie_params(); setcookie(session_name(),'',time()-3600,$p['path'],$p['domain']??'',$p['secure']??false,$p['httponly']??true); } if(session_status()===PHP_SESSION_ACTIVE) session_destroy(); }
function nexaud_require_login(): array { requireAuth(); return current_user()??[]; }
function nexaud_current_user(): array { return current_user()??[]; }
function nexaud_require_role(array $roles): void { requireRole($roles); }
function nexaud_csrf_field(): string { return csrf_field(); }
function nexaud_csrf_verify(): bool { return verify_csrf(); }
function nexaud_audit_log(string $action,string $targetType,?int $targetId,array $details=[]): void { audit_log(current_user_id(),$action,$targetType,$targetId,$details); }
