</div></main></div><footer class="footer">© <?=date('Y')?> NexAud · <?=e(APP_VERSION)?></footer></div>
<script src="<?=e(asset('js/nexaud.js'))?>"></script></body></html>
