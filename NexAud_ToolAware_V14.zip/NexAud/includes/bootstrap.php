<?php
declare(strict_types=1);
require_once __DIR__.'/../config/app.php';
require_once __DIR__.'/../config/security.php';
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/functions.php';
if (session_status()===PHP_SESSION_NONE) { session_name(SESSION_NAME); session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','httponly'=>true,'samesite'=>'Lax']); session_start(); }
require_once __DIR__.'/auth.php';
if(isset($_SESSION['last_activity']) && (time()-(int)$_SESSION['last_activity'])>(SESSION_IDLE_MINUTES*60)){ $_SESSION=[]; if(session_status()===PHP_SESSION_ACTIVE) session_destroy(); session_start(); }
$_SESSION['last_activity']=time();
