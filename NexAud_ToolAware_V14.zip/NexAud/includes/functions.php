<?php
declare(strict_types=1);
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function url(string $path=''): string { return rtrim(BASE_URL,'/').($path!==''?'/'.ltrim($path,'/'):''); }
function asset(string $path): string { return url('assets/'.ltrim($path,'/')); }
function redirect_to(string $path): never { header('Location: '.(preg_match('#^https?://#i',$path)?$path:url($path))); exit; }
function flash(string $key, ?string $value=null): ?string { if($value!==null){$_SESSION['_flash'][$key]=$value;return null;} $v=$_SESSION['_flash'][$key]??null; unset($_SESSION['_flash'][$key]); return $v; }
function csrf_token(): string { if(empty($_SESSION[CSRF_TOKEN_KEY])) $_SESSION[CSRF_TOKEN_KEY]=bin2hex(random_bytes(32)); return $_SESSION[CSRF_TOKEN_KEY]; }
function csrf_field(): string { return '<input type="hidden" name="'.e(CSRF_FORM_FIELD).'" value="'.e(csrf_token()).'">'; }
function verify_csrf(): bool { $a=$_POST[CSRF_FORM_FIELD]??''; $b=$_SESSION[CSRF_TOKEN_KEY]??''; return is_string($a)&&is_string($b)&&$a!==''&&$b!==''&&hash_equals($b,$a); }
function client_ip(): string { return trim(explode(',',$_SERVER['HTTP_X_FORWARDED_FOR']??$_SERVER['REMOTE_ADDR']??'0.0.0.0')[0]); }
function audit_log(?int $userId,string $action,string $category,?int $targetId=null,array $meta=[]): void { try{ $p=getDB(); $s=$p->prepare('INSERT INTO audit_logs(user_id,action,category,target_id,metadata,ip_address,user_agent,created_at) VALUES(?,?,?,?,?,?,?,NOW())'); $s->execute([$userId,$action,$category,$targetId,json_encode($meta,JSON_UNESCAPED_SLASHES),client_ip(),substr($_SERVER['HTTP_USER_AGENT']??'',0,255)]);}catch(Throwable $e){ @file_put_contents(NEXAUD_ROOT.'/logs/audit_fallback.log','['.date('c').'] '.$action.' '.json_encode($meta).PHP_EOL,FILE_APPEND|LOCK_EX); } }
function db_one(string $sql,array $params=[]): ?array { $s=getDB()->prepare($sql); $s->execute($params); $r=$s->fetch(); return $r?:null; }
function db_all(string $sql,array $params=[]): array { $s=getDB()->prepare($sql); $s->execute($params); return $s->fetchAll(); }
function db_value(string $sql,array $params=[],$default=0){ $s=getDB()->prepare($sql);$s->execute($params);$v=$s->fetchColumn();return $v===false?$default:$v; }
function render_error(int $code,string $title='',string $message=''): never { http_response_code($code); $title=$title ?: ([403=>'Access denied',404=>'Page not found',405=>'Method not allowed',422=>'Validation error',500=>'Application error'][$code]??'Error'); $message=$message ?: ([403=>'You do not have permission to access this resource.',404=>'The requested page could not be found.',405=>'The requested HTTP method is not allowed.',422=>'The request could not be processed.',500=>'Something went wrong. Check the server log for details.'][$code]??'Unexpected error.'); ?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($code.' · '.$title)?> | <?=e(APP_NAME)?></title><link rel="stylesheet" href="<?=e(asset('css/nexaud.css'))?>"></head><body class="error-page"><div class="error-card"><div class="error-code"><?=e($code)?></div><h1><?=e($title)?></h1><p><?=e($message)?></p><a class="btn btn-primary" href="<?=e(url('dashboard.php'))?>">Back to Dashboard</a></div></body></html><?php exit; }
function status_badge(string $status): string { $s=strtoupper($status); return '<span class="badge badge-'.e($s).'">'.e(str_replace('_',' ',$s)).'</span>'; }
function severity_badge(string $sev): string { $s=strtoupper($sev); return '<span class="badge sev-'.e($s).'">'.e($s).'</span>'; }
function layout_header(string $title,string $active=''): void { global $pageTitle; $pageTitle=$title; $GLOBALS['page_active']=$active; require NEXAUD_ROOT.'/includes/header.php'; }
function layout_footer(): void { require NEXAUD_ROOT.'/includes/footer.php'; }
// Compatibility aliases used by older module pages.
function nexaud_header(string $title,string $active=''): void { layout_header($title,$active); }
function nexaud_footer(): void { layout_footer(); }
function nexaud_render_header(string $title): void { layout_header($title); }
function nexaud_render_footer(): void { layout_footer(); }
