(function () {
  "use strict";

  const root = document.documentElement;
  const body = document.body;
  const sidebar = document.getElementById("sidebar");
  const sidebarToggle = document.getElementById("sidebarToggle");
  const themeToggle = document.getElementById("themeToggle");
  const THEME_KEY = "nexaud-theme";

  function applyTheme(theme) {
    const isLight = theme === "light";
    root.dataset.theme = isLight ? "light" : "dark";
    root.classList.toggle("light", isLight);
    body.classList.toggle("light", isLight);

    if (themeToggle) {
      themeToggle.textContent = isLight ? "☀" : "☾";
      themeToggle.setAttribute("aria-label", isLight ? "Switch to dark mode" : "Switch to light mode");
      themeToggle.setAttribute("title", isLight ? "Switch to dark mode" : "Switch to light mode");
    }

    try {
      localStorage.setItem(THEME_KEY, isLight ? "light" : "dark");
    } catch (_) {}
  }

  function getInitialTheme() {
    try {
      const saved = localStorage.getItem(THEME_KEY);
      if (saved === "light" || saved === "dark") return saved;
    } catch (_) {}

    return window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches
      ? "light"
      : "dark";
  }

  // Apply immediately so every page has a consistent theme.
  applyTheme(getInitialTheme());

  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener("click", function () {
      sidebar.classList.toggle("open");
    });
  }

  if (themeToggle) {
    themeToggle.addEventListener("click", function () {
      applyTheme(root.dataset.theme === "light" ? "dark" : "light");
    });
  }
})();
