/**
 * NexAud — Dashboard page script.
 * Initializes the zero-state charts. Later modules can call
 * window.NexAudCharts.updateCompliance(data) / updateRisk(data)
 * once real metrics exist.
 */
(function () {
  'use strict';

  function themeColor(varName) {
    return getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
  }

  function buildComplianceChart() {
    var el = document.getElementById('complianceOverviewChart');
    if (!el || typeof Chart === 'undefined') return null;

    return new Chart(el, {
      type: 'doughnut',
      data: {
        labels: ['Compliant', 'Non-Compliant', 'Not Assessed'],
        datasets: [{
          data: [0, 0, 100],
          backgroundColor: [themeColor('--success'), themeColor('--danger'), themeColor('--border')],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom', labels: { color: themeColor('--text-secondary'), boxWidth: 10, font: { size: 11 } } } },
        cutout: '68%'
      }
    });
  }

  function buildRiskChart() {
    var el = document.getElementById('riskDistributionChart');
    if (!el || typeof Chart === 'undefined') return null;

    return new Chart(el, {
      type: 'bar',
      data: {
        labels: ['Critical', 'High', 'Medium', 'Low'],
        datasets: [{
          label: 'Findings',
          data: [0, 0, 0, 0],
          backgroundColor: [themeColor('--danger'), '#f0793a', themeColor('--warning'), themeColor('--info')],
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: themeColor('--text-secondary') }, grid: { display: false } },
          y: { beginAtZero: true, ticks: { color: themeColor('--text-secondary'), precision: 0 }, grid: { color: themeColor('--border') } }
        }
      }
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    window.NexAudCharts = window.NexAudCharts || {};
    window.NexAudCharts.compliance = buildComplianceChart();
    window.NexAudCharts.risk = buildRiskChart();
  });
})();
