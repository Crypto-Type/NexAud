/**
 * NexAud — Shared Chart.js defaults so every chart in the app matches
 * the current theme without repeating configuration per page.
 * Must be loaded AFTER the Chart.js library and BEFORE any page
 * script (e.g. dashboard.js) that creates charts.
 */
(function () {
  'use strict';

  if (typeof Chart === 'undefined') return;

  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  Chart.defaults.font.family = "'Segoe UI', Roboto, Arial, sans-serif";
  Chart.defaults.color = cssVar('--text-secondary');
  Chart.defaults.borderColor = cssVar('--border');

  // Re-apply defaults if the user switches theme, and rebuild any
  // registered charts so colors follow the new theme.
  document.addEventListener('DOMContentLoaded', function () {
    var themeToggle = document.getElementById('themeToggle');
    if (!themeToggle) return;

    themeToggle.addEventListener('click', function () {
      setTimeout(function () {
        Chart.defaults.color = cssVar('--text-secondary');
        Chart.defaults.borderColor = cssVar('--border');
        if (window.NexAudCharts) {
          Object.keys(window.NexAudCharts).forEach(function (key) {
            var chart = window.NexAudCharts[key];
            if (chart && typeof chart.update === 'function') {
              chart.update();
            }
          });
        }
      }, 50);
    });
  });

  window.NexAudChartHelpers = { cssVar: cssVar };
})();
